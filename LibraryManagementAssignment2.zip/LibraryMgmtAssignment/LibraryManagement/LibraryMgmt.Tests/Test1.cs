﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using LibraryManagement;
using System.Linq;

namespace LibraryManagement.Tests
{
    [TestClass]
    public class LibraryTests
    {
        private Library library;

        [TestInitialize]
        public void Setup()
        {
            library = new Library();
        }

        [TestMethod]
        public void AddBook_ShouldIncreaseBookCount()
        {
            var book = new Book { Title = "C#", Author = "John Doe", ISBN = "123" };

            library.AddBook(book);

            Assert.AreEqual(1, library.Books.Count);
        }

        [TestMethod]
        public void RegisterBorrower_ShouldIncreaseBorrowerCount()
        {
            var borrower = new Borrower { Name = "Alice", LibraryCardNumber = "B001" };

            library.RegisterBorrower(borrower);

            Assert.AreEqual(1, library.Borrowers.Count);
        }

        [TestMethod]
        public void BorrowBook_ShouldMarkBookAsBorrowed()
        {
            var book = new Book { Title = "C#", Author = "John Doe", ISBN = "123" };
            var borrower = new Borrower { Name = "Bob", LibraryCardNumber = "B002" };

            library.AddBook(book);
            library.RegisterBorrower(borrower);
            library.BorrowBook("123", "B002");

            Assert.IsTrue(book.IsBorrowed);
            Assert.AreEqual(1, borrower.BorrowedBooks.Count);
        }

        [TestMethod]
        public void ReturnBook_ShouldMarkBookAsAvailable()
        {
            var book = new Book { Title = "C#", Author = "John Doe", ISBN = "123" };
            var borrower = new Borrower { Name = "Bob", LibraryCardNumber = "B002" };

            library.AddBook(book);
            library.RegisterBorrower(borrower);
            library.BorrowBook("123", "B002");
            library.ReturnBook("123", "B002");

            Assert.IsFalse(book.IsBorrowed);
            Assert.AreEqual(0, borrower.BorrowedBooks.Count);
        }

        [TestMethod]
        public void ViewBooks_ShouldReturnAllBooks()
        {
            library.AddBook(new Book { Title = "Book A", Author = "Author A", ISBN = "001" });
            library.AddBook(new Book { Title = "Book B", Author = "Author B", ISBN = "002" });

            var books = library.ViewBooks();

            Assert.AreEqual(2, books.Count);
        }

        [TestMethod]
        public void ViewBorrowers_ShouldReturnAllBorrowers()
        {
            library.RegisterBorrower(new Borrower { Name = "User A", LibraryCardNumber = "A001" });
            library.RegisterBorrower(new Borrower { Name = "User B", LibraryCardNumber = "B002" });

            var borrowers = library.ViewBorrowers();

            Assert.AreEqual(2, borrowers.Count);
        }
    }
}
