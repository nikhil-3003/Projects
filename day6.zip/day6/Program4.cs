
// using System;
// using System.IO;

// class Program4
// {

//     static void Main()
//     {

//         using (StreamWriter writer = new StreamWriter("data.txt"))
//         {
//             writer.WriteLine("dfhhfj");
//             writer.WriteLine("dsgdg");

//         }

//         using (StreamReader reader = new StreamReader("data.txt"))
//         {
//             string line;
//             while ((line = reader.ReadLine()) != null)
//             {
//                 Console.WriteLine(line);
//             }
             
//         }

//     }

// }