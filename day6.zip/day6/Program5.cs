// class ExceptionExample
// {

//     static void Main()
//     {
//         string fpath = "datafile.txt";
//         try
//         {
//             // int a = 10;
//             // int b = 2;
//             // int result = a / b;
//             // Console.WriteLine("The result is : " + result);

//             // int[] arr = { 45, 67, 78 };
//             // Console.WriteLine("The value is :" + arr[5]);
//             // using (StreamReader reader = new StreamReader(fpath))
//             // {
//             //     string content = reader.ReadToEnd();
//             //     Console.WriteLine(content);

//             // }

//             int a = int.Parse("123"); 


//         // }

//         // catch (FileNotFoundException ex)
//         // {
//         //     Console.WriteLine("File does not exist " + ex.FileName);


//         // }

//         // catch (UnauthorizedAccessException ex)
//         // {
//         //     Console.WriteLine(ex.Message);

//         // }
//         // catch (IOException ex)
//         // {
//         //     Console.WriteLine(ex.Message);

//         // }
//         catch (FormatException ex)
//         {
//             Console.WriteLine(ex.Message);
//         }
      
//         // catch (DivideByZeroException e)
//         // {
//         //     Console.WriteLine("Cannot divide by Zero");
//         // }
//         // catch (IndexOutOfRangeException e)
//         // {
//         //     Console.WriteLine("Index out of range");
//         // }
//         //   catch (Exception ex)
//         // {
//         //     Console.WriteLine(ex);
//         // }
//         // finally
//         // {
//         //     Console.WriteLine("You have handled or unhandled exceptions:");
//         // }



//     }
// }