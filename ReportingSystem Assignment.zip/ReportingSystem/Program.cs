﻿using System;
using ReportingSystem.Formatters;
using ReportingSystem.Models;
using ReportingSystem.Services;
using ReportingSystem.Utils;

class Program
{
    static void Main(string[] args)
    {
        // Create Report
        var report = new PDFReport("Sales Report", "This is the content of the sales report.");

        // Choose Formatter (PDF or Excel)
        var formatter = new PDFFormatter(); // or new ExcelFormatter();

        // Get Singleton Logger
        var logger = Logger.Instance;

        // Generate and Save Report
        var generator = new ReportGenerator(report, formatter);
        var saver = new ReportSaver();
        var service = new ReportService(generator, saver, logger);

        service.ProcessReport("report_output.txt");
    }
}
