﻿// Please see documentation at https://learn.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.
const products = [
            { id: 1, name: 'iphone 17 air', price: 150000.000, image: 'https://cdn.mos.cms.futurecdn.net/tvufD98xHedyoDuiu2aHMJ-1200-80.jpg' },
            { id: 2, name: 'samsung galaxy 25', price: 145000.500, image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ0eJx8it8ptova1wG8DisDXBuadxYomf_oqA&s' },
            { id: 3, name: 'Vivo X200', price: 128000.75, image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSNHD1jXZzzV-Z2xMShjxp5e_JG-xz-bR8rWg&s' },
            { id: 4, name: 'Huawei', price: 30000.00, image: 'https://images.indianexpress.com/2024/09/huawei-mate-xt_db2855.jpg' }
        ];

        let cart = []; // The shopping cart
        let billingInfo = {};

        // Get all the elements we'll need
        const loginPage = document.getElementById('login-page');
        const productsPage = document.getElementById('products-page');
        const cartPage = document.getElementById('cart-page');
        const billingPage = document.getElementById('billing-page');
        const orderPage = document.getElementById('order-page');

        const usernameInput = document.getElementById('username-input');
        const passwordInput = document.getElementById('password-input');
        const loginMessage = document.getElementById('login-message');
        const loginButton = document.getElementById('login-button');
        const welcomeMessage = document.getElementById('welcome-message');
        const cartButton = document.getElementById('cart-button');
        const cartCountSpan = document.getElementById('cart-count');
        const productListContainer = document.getElementById('product-list-container');
        const cartItemsContainer = document.getElementById('cart-items-container');
        const cartTotalSpan = document.getElementById('cart-total');
        const checkoutButton = document.getElementById('checkout-button');
        const backToShopButton = document.getElementById('back-to-shop-button');
        const billingForm = document.getElementById('billing-form');
        const backToCartButton = document.getElementById('back-to-cart-button');
        const orderSummaryContainer = document.getElementById('order-summary-container');
        const startOverButton = document.getElementById('start-over-button');

        // Function to show a page and hide others
        function showPage(page) {
            loginPage.style.display = 'none';
            productsPage.style.display = 'none';
            cartPage.style.display = 'none';
            billingPage.style.display = 'none';
            orderPage.style.display = 'none';
            page.style.display = 'block';
        }

        // Render products on the products page
        function renderProducts() {
            productListContainer.innerHTML = '';
            products.forEach(product => {
                const productDiv = document.createElement('div');
                productDiv.className = 'product-item';
                productDiv.innerHTML = `
                    <img src="${product.image}" alt="${product.name}">
                    <h3>${product.name}</h3>
                    <p>$${product.price.toFixed(2)}</p>
                    <button class="add-to-cart-btn" data-id="${product.id}">Add to Cart</button>
                `;
                productListContainer.appendChild(productDiv);
            });
        }

        // Render items in the cart
        function renderCart() {
            cartItemsContainer.innerHTML = '';
            let total = 0;
            if (cart.length === 0) {
                cartItemsContainer.innerHTML = '<p style="text-align: center; color: #888;">Your cart is empty.</p>';
                checkoutButton.disabled = true;
                checkoutButton.style.opacity = '0.5';
            } else {
                checkoutButton.disabled = false;
                checkoutButton.style.opacity = '1';
                cart.forEach(item => {
                    const subtotal = item.price * item.quantity;
                    total += subtotal;
                    const itemDiv = document.createElement('div');
                    itemDiv.className = 'cart-item';
                    itemDiv.innerHTML = `
                        <span>${item.name} x ${item.quantity}</span>
                        <span>$${subtotal.toFixed(2)}</span>
                    `;
                    cartItemsContainer.appendChild(itemDiv);
                });
            }
            cartTotalSpan.textContent = `$${total.toFixed(2)}`;
        }

        // Render the final order summary
        function renderOrderSummary() {
            orderSummaryContainer.innerHTML = `
                <p><strong>Name:</strong> ${billingInfo.name}</p>
                <p><strong>Email:</strong> ${billingInfo.email}</p>
                <p><strong>Address:</strong> ${billingInfo.address}</p>
                <hr style="margin: 15px 0;">
                <p style="font-weight: bold;">Order Items:</p>
            `;
            let total = 0;
            cart.forEach(item => {
                const subtotal = item.price * item.quantity;
                total += subtotal;
                orderSummaryContainer.innerHTML += `
                    <p style="margin-bottom: 5px;">- ${item.name} x ${item.quantity} ($${subtotal.toFixed(2)})</p>
                `;
            });
            orderSummaryContainer.innerHTML += `<hr style="margin: 15px 0;">`;
            orderSummaryContainer.innerHTML += `<p style="font-weight: bold; text-align: right;">Final Total: $${total.toFixed(2)}</p>`;
        }

        // Update the cart count in the header
        function updateCartCount() {
            const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
            cartCountSpan.textContent = totalItems;
        }

        // --- Event Listeners ---

        // Login
       loginButton.addEventListener('click', () => {
            if (usernameInput.value && passwordInput.value) {
                loginMessage.textContent = '';
                renderProducts();
                showPage(productsPage);
            } else {
                loginMessage.textContent = 'Please enter a username and password.';
            }
        });

        // Add to cart (using event delegation)
        productListContainer.addEventListener('click', (event) => {
            if (event.target.classList.contains('add-to-cart-btn')) {
                const productId = parseInt(event.target.dataset.id);
                const product = products.find(p => p.id === productId);
                const existingItem = cart.find(item => item.id === productId);
                if (existingItem) {
                    existingItem.quantity++;
                } else {
                    cart.push({ ...product, quantity: 1 });
                }
                updateCartCount();
            }
        });

        cartItemsContainer.addEventListener('click', (event) => {
            if (event.target.classList.contains('update-quantity-btn')) {
                const productId = parseInt(event.target.dataset.id);
                const action = event.target.dataset.action;
                const existingItem = cart.find(item => item.id === productId);

                if (existingItem) {
                    if (action === 'increase') {
                        existingItem.quantity++;
                    } else if (action === 'decrease') {
                        existingItem.quantity--;
                        if (existingItem.quantity <= 0) {
                            cart = cart.filter(item => item.id !== productId);
                        }
                    }
                }
                renderCart();
                updateCartCount();
            }
        });

        // Show cart page
        cartButton.addEventListener('click', () => {
            renderCart();
            showPage(cartPage);
        });

        // Back to shop
        backToShopButton.addEventListener('click', () => {
            showPage(productsPage);
        });

        // Go to billing page
        checkoutButton.addEventListener('click', () => {
            showPage(billingPage);
        });

        // Back to cart
        backToCartButton.addEventListener('click', () => {
            showPage(cartPage);
        });

        // Submit billing form
        billingForm.addEventListener('submit', (event) => {
            event.preventDefault();
            billingInfo = {
                name: document.getElementById('full-name').value,
                email: document.getElementById('email').value,
                address: document.getElementById('address').value
            };
            renderOrderSummary();
            showPage(orderPage);
            cart = []; // Clear cart for new order
            updateCartCount();
        });

        // Start over
        startOverButton.addEventListener('click', () => {
            showPage(loginPage);
        });