using System.Data;
using Microsoft.Data.SqlClient;
using BookStore.Models;

namespace BookStore.Data
{
    public class BookRepositoryDisconnected
    {
        private readonly string connectionString = "Server=.;Database=BookStoreDB;Trusted_Connection=True;";

        // Get data in disconnected mode using DataSet
        public DataSet GetBooks()
        {
            using SqlConnection con = new(connectionString);
            SqlDataAdapter da = new("SELECT * FROM Books", con);
            DataSet ds = new();
            da.Fill(ds, "Books");
            return ds;
        }

        // Add a new book in disconnected mode
        public void AddBook(Book book)
        {
            using SqlConnection con = new(connectionString);
            SqlDataAdapter da = new("SELECT * FROM Books", con);
            DataSet ds = new();
            da.Fill(ds, "Books");

            DataTable dt = ds.Tables["Books"]!;
            DataRow newRow = dt.NewRow();
            newRow["Title"] = book.Title;
            newRow["Author"] = book.Author;
            newRow["Price"] = book.Price;
            newRow["PublishedYear"] = book.PublishedYear;

            dt.Rows.Add(newRow);

            SqlCommandBuilder cb = new(da);
            da.Update(ds, "Books");
        }

        // Update an existing book
        public void UpdateBook(Book book)
        {
            using SqlConnection con = new(connectionString);
            SqlDataAdapter da = new("SELECT * FROM Books", con);
            DataSet ds = new();
            da.Fill(ds, "Books");

            DataTable dt = ds.Tables["Books"]!;
            DataRow? row = dt.Rows.Find(book.BookId);

            if (row != null)
            {
                row["Title"] = book.Title;
                row["Author"] = book.Author;
                row["Price"] = book.Price;
                row["PublishedYear"] = book.PublishedYear;

                SqlCommandBuilder cb = new(da);
                da.Update(ds, "Books");
            }
        }

        // Delete a book
        public void DeleteBook(int id)
        {
            using SqlConnection con = new(connectionString);
            SqlDataAdapter da = new("SELECT * FROM Books", con);
            DataSet ds = new();
            da.Fill(ds, "Books");

            DataTable dt = ds.Tables["Books"]!;
            DataRow? row = dt.Rows.Find(id);

            if (row != null)
            {
                row.Delete();
                SqlCommandBuilder cb = new(da);
                da.Update(ds, "Books");
            }
        }
    }
}
