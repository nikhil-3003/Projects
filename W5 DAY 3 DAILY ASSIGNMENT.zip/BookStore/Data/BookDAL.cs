using System.Data;
using Microsoft.Data.SqlClient;
using BookStore.Models;

namespace BookStore.Data
{
    public class BookDAL
    {
        private readonly string connectionString = "Server=(localdb)\\MSSQLLocalDB.;Database=WiproTraining;Trusted_Connection=True;";

        public List<Book> GetAllBooks()
        {
            List<Book> books = new();
            using SqlConnection con = new(connectionString);
            SqlCommand cmd = new("SELECT * FROM Books", con);
            con.Open();
            using SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                books.Add(new Book
                {
                    BookId = (int)reader["BookId"],
                    Title = reader["Title"].ToString()!,
                    Author = reader["Author"].ToString()!,
                    Price = (decimal)reader["Price"],
                    PublishedYear = (int)reader["PublishedYear"]
                });
            }
            return books;
        }

        public void AddBook(Book book)
        {
            using SqlConnection con = new(connectionString);
            SqlCommand cmd = new("AddBook", con) { CommandType = CommandType.StoredProcedure };
            cmd.Parameters.AddWithValue("@Title", book.Title);
            cmd.Parameters.AddWithValue("@Author", book.Author);
            cmd.Parameters.AddWithValue("@Price", book.Price);
            cmd.Parameters.AddWithValue("@PublishedYear", book.PublishedYear);
            con.Open();
            cmd.ExecuteNonQuery();
        }

        public void UpdateBook(Book book)
        {
            using SqlConnection con = new(connectionString);
            SqlCommand cmd = new("UpdateBook", con) { CommandType = CommandType.StoredProcedure };
            cmd.Parameters.AddWithValue("@BookId", book.BookId);
            cmd.Parameters.AddWithValue("@Title", book.Title);
            cmd.Parameters.AddWithValue("@Author", book.Author);
            cmd.Parameters.AddWithValue("@Price", book.Price);
            cmd.Parameters.AddWithValue("@PublishedYear", book.PublishedYear);
            con.Open();
            cmd.ExecuteNonQuery();
        }

        public void DeleteBook(int id)
        {
            using SqlConnection con = new(connectionString);
            SqlCommand cmd = new("DeleteBook", con) { CommandType = CommandType.StoredProcedure };
            cmd.Parameters.AddWithValue("@BookId", id);
            con.Open();
            cmd.ExecuteNonQuery();
        }
    }
}
