using Microsoft.AspNetCore.Mvc;
using BookStore.Data;
using BookStore.Models;

namespace BookStore.Controllers
{
    public class BookController : Controller
    {
        private readonly BookDAL _dal = new();

        public IActionResult Index()
        {
            var books = _dal.GetAllBooks();
            return View(books);
        }

        [HttpGet]
        public IActionResult Create() => View();

        [HttpPost]
        public IActionResult Create(Book book)
        {
            if (ModelState.IsValid)
            {
                _dal.AddBook(book);
                return RedirectToAction("Index");
            }
            return View(book);
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            var book = _dal.GetAllBooks().FirstOrDefault(b => b.BookId == id);
            return View(book);
        }

        [HttpPost]
        public IActionResult Edit(Book book)
        {
            if (ModelState.IsValid)
            {
                _dal.UpdateBook(book);
                return RedirectToAction("Index");
            }
            return View(book);
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            var book = _dal.GetAllBooks().FirstOrDefault(b => b.BookId == id);
            return View(book);
        }

        [HttpPost, ActionName("Delete")]
        public IActionResult DeleteConfirmed(int id)
        {
            _dal.DeleteBook(id);
            return RedirectToAction("Index");
        }
    }
}
