using Microsoft.AspNetCore.Mvc;
using BookStore.Data;
using BookStore.Models;
using System.Data;

namespace BookStore.Controllers
{
    public class BookDisconnectedController : Controller
    {
        private readonly BookRepositoryDisconnected _repo = new();

        public IActionResult Index()
        {
            DataSet ds = _repo.GetBooks();
            var books = ds.Tables["Books"]!.AsEnumerable().Select(row => new Book
            {
                BookId = row.Field<int>("BookId"),
                Title = row.Field<string>("Title")!,
                Author = row.Field<string>("Author")!,
                Price = row.Field<decimal>("Price"),
                PublishedYear = row.Field<int>("PublishedYear")
            }).ToList();

            return View(books);
        }

        [HttpGet]
        public IActionResult Create() => View();

        [HttpPost]
        public IActionResult Create(Book book)
        {
            if (ModelState.IsValid)
            {
                _repo.AddBook(book);
                return RedirectToAction("Index");
            }
            return View(book);
        }
    }
}
