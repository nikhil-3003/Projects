using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Core_Web_Razor_WiproDemo.Pages
{
    public class Page2Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
