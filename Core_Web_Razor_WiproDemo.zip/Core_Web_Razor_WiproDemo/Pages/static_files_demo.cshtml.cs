using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Core_Web_Razor_WiproDemo.Pages
{
    public class static_files_demoModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
