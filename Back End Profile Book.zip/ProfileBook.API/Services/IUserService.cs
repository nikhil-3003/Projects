using ProfileBook.Models;

namespace ProfileBook.API.Services
{
    public interface IUserService
    {
        Task<IEnumerable<User>> GetAllUsersAsync();
        Task<User?> GetUserByIdAsync(int userId);
        Task<User?> GetUserByUsernameAsync(string username);
        Task<User?> UpdateUserAsync(int userId, User user);
        Task<bool> DeleteUserAsync(int userId);
        Task<IEnumerable<User>> SearchUsersAsync(string searchTerm);
        Task<bool> UpdateUserProfileAsync(int userId, string? profileImage);
    }
}








