using ProfileBook.Models;

namespace ProfileBook.API.Services
{
    public interface IPostService
    {
        Task<IEnumerable<Post>> GetAllPostsAsync();
        Task<IEnumerable<Post>> GetApprovedPostsAsync();
        Task<IEnumerable<Post>> GetPendingPostsAsync();
        Task<Post?> GetPostByIdAsync(int postId);
        Task<Post?> CreatePostAsync(Post post);
        Task<Post?> UpdatePostAsync(int postId, Post post);
        Task<bool> DeletePostAsync(int postId);
        Task<bool> ApprovePostAsync(int postId, int adminUserId);
        Task<bool> RejectPostAsync(int postId, int adminUserId);
        Task<IEnumerable<Post>> GetUserPostsAsync(int userId);
        Task<bool> LikePostAsync(int postId, int userId);
        Task<bool> UnlikePostAsync(int postId, int userId);
        Task<Comment?> AddCommentAsync(int postId, int userId, string content);
        Task<IEnumerable<Comment>> GetPostCommentsAsync(int postId);
        Task<IEnumerable<Post>> SearchPostsAsync(string query);
    }
}

