using Microsoft.EntityFrameworkCore;
using ProfileBook.Data;
using ProfileBook.Models;

namespace ProfileBook.API.Services
{
    public class FriendService : IFriendService
    {
        private readonly ApplicationDbContext _context;

        public FriendService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Friend>> GetUserFriendsAsync(int userId)
        {
            return await _context.Friends
                .Where(f => (f.UserId == userId || f.FriendUserId == userId) && f.Status == "Accepted")
                .Include(f => f.User)
                .Include(f => f.FriendUser)
                .ToListAsync();
        }

        public async Task<IEnumerable<Friend>> GetPendingFriendRequestsAsync(int userId)
        {
            return await _context.Friends
                .Where(f => f.FriendUserId == userId && f.Status == "Pending")
                .Include(f => f.User)
                .Include(f => f.FriendUser)
                .ToListAsync();
        }

        public async Task<IEnumerable<Friend>> GetSentFriendRequestsAsync(int userId)
        {
            return await _context.Friends
                .Where(f => f.UserId == userId && f.Status == "Pending")
                .Include(f => f.User)
                .Include(f => f.FriendUser)
                .ToListAsync();
        }

        public async Task<Friend?> SendFriendRequestAsync(int userId, int friendUserId)
        {
            if (userId == friendUserId)
                return null;

            // Check if friendship already exists
            var existingFriendship = await _context.Friends
                .FirstOrDefaultAsync(f => 
                    (f.UserId == userId && f.FriendUserId == friendUserId) ||
                    (f.UserId == friendUserId && f.FriendUserId == userId));

            if (existingFriendship != null)
                return null;

            var friendRequest = new Friend
            {
                UserId = userId,
                FriendUserId = friendUserId,
                Status = "Pending",
                CreatedAt = DateTime.UtcNow
            };

            _context.Friends.Add(friendRequest);
            await _context.SaveChangesAsync();

            return await _context.Friends
                .Include(f => f.User)
                .Include(f => f.FriendUser)
                .FirstOrDefaultAsync(f => f.FriendId == friendRequest.FriendId);
        }

        public async Task<bool> AcceptFriendRequestAsync(int friendId, int userId)
        {
            var friendRequest = await _context.Friends
                .FirstOrDefaultAsync(f => f.FriendId == friendId && f.FriendUserId == userId && f.Status == "Pending");

            if (friendRequest == null)
                return false;

            friendRequest.Status = "Accepted";
            friendRequest.UpdatedAt = DateTime.UtcNow;

            // Create reciprocal friendship
            var reciprocalFriendship = new Friend
            {
                UserId = friendRequest.FriendUserId,
                FriendUserId = friendRequest.UserId,
                Status = "Accepted",
                CreatedAt = DateTime.UtcNow
            };

            _context.Friends.Add(reciprocalFriendship);
            await _context.SaveChangesAsync();

            return true;
        }

        public async Task<bool> RejectFriendRequestAsync(int friendId, int userId)
        {
            var friendRequest = await _context.Friends
                .FirstOrDefaultAsync(f => f.FriendId == friendId && f.FriendUserId == userId && f.Status == "Pending");

            if (friendRequest == null)
                return false;

            _context.Friends.Remove(friendRequest);
            await _context.SaveChangesAsync();

            return true;
        }

        public async Task<bool> RemoveFriendAsync(int userId, int friendUserId)
        {
            var friendships = await _context.Friends
                .Where(f => 
                    (f.UserId == userId && f.FriendUserId == friendUserId) ||
                    (f.UserId == friendUserId && f.FriendUserId == userId))
                .ToListAsync();

            if (!friendships.Any())
                return false;

            _context.Friends.RemoveRange(friendships);
            await _context.SaveChangesAsync();

            return true;
        }

        public async Task<bool> BlockUserAsync(int userId, int blockedUserId)
        {
            // Remove any existing friendship
            await RemoveFriendAsync(userId, blockedUserId);

            var blockedUser = new Friend
            {
                UserId = userId,
                FriendUserId = blockedUserId,
                Status = "Blocked",
                CreatedAt = DateTime.UtcNow
            };

            _context.Friends.Add(blockedUser);
            await _context.SaveChangesAsync();

            return true;
        }

        public async Task<bool> UnblockUserAsync(int userId, int blockedUserId)
        {
            var blockedUser = await _context.Friends
                .FirstOrDefaultAsync(f => f.UserId == userId && f.FriendUserId == blockedUserId && f.Status == "Blocked");

            if (blockedUser == null)
                return false;

            _context.Friends.Remove(blockedUser);
            await _context.SaveChangesAsync();

            return true;
        }

        public async Task<bool> AreFriendsAsync(int userId1, int userId2)
        {
            return await _context.Friends
                .AnyAsync(f => 
                    (f.UserId == userId1 && f.FriendUserId == userId2) ||
                    (f.UserId == userId2 && f.FriendUserId == userId1) &&
                    f.Status == "Accepted");
        }

        public async Task<int> GetFriendCountAsync(int userId)
        {
            return await _context.Friends
                .CountAsync(f => (f.UserId == userId || f.FriendUserId == userId) && f.Status == "Accepted");
        }
    }
}

