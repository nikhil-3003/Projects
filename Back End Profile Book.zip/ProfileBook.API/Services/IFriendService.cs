using ProfileBook.Models;

namespace ProfileBook.API.Services
{
    public interface IFriendService
    {
        Task<IEnumerable<Friend>> GetUserFriendsAsync(int userId);
        Task<IEnumerable<Friend>> GetPendingFriendRequestsAsync(int userId);
        Task<IEnumerable<Friend>> GetSentFriendRequestsAsync(int userId);
        Task<Friend?> SendFriendRequestAsync(int userId, int friendUserId);
        Task<bool> AcceptFriendRequestAsync(int friendId, int userId);
        Task<bool> RejectFriendRequestAsync(int friendId, int userId);
        Task<bool> RemoveFriendAsync(int userId, int friendUserId);
        Task<bool> BlockUserAsync(int userId, int blockedUserId);
        Task<bool> UnblockUserAsync(int userId, int blockedUserId);
        Task<bool> AreFriendsAsync(int userId1, int userId2);
        Task<int> GetFriendCountAsync(int userId);
    }
}

