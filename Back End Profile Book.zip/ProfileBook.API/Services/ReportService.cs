using Microsoft.EntityFrameworkCore;
using ProfileBook.Data;
using ProfileBook.Models;

namespace ProfileBook.API.Services
{
    public class ReportService : IReportService
    {
        private readonly ApplicationDbContext _context;

        public ReportService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Report>> GetAllReportsAsync()
        {
            return await _context.Reports
                .Include(r => r.ReportedUser)
                .Include(r => r.ReportingUser)
                .Include(r => r.Reviewer)
                .OrderByDescending(r => r.TimeStamp)
                .ToListAsync();
        }

        public async Task<IEnumerable<Report>> GetPendingReportsAsync()
        {
            return await _context.Reports
                .Where(r => r.Status == "Pending")
                .Include(r => r.ReportedUser)
                .Include(r => r.ReportingUser)
                .OrderByDescending(r => r.TimeStamp)
                .ToListAsync();
        }

        public async Task<Report?> CreateReportAsync(int reportedUserId, int reportingUserId, string reason)
        {
            var report = new Report
            {
                ReportedUserId = reportedUserId,
                ReportingUserId = reportingUserId,
                Reason = reason,
                TimeStamp = DateTime.UtcNow,
                Status = "Pending"
            };

            _context.Reports.Add(report);
            await _context.SaveChangesAsync();

            return await _context.Reports
                .Include(r => r.ReportedUser)
                .Include(r => r.ReportingUser)
                .FirstOrDefaultAsync(r => r.ReportId == report.ReportId);
        }

        public async Task<Report?> GetReportByIdAsync(int reportId)
        {
            return await _context.Reports
                .Include(r => r.ReportedUser)
                .Include(r => r.ReportingUser)
                .Include(r => r.Reviewer)
                .FirstOrDefaultAsync(r => r.ReportId == reportId);
        }

        public async Task<bool> UpdateReportStatusAsync(int reportId, string status, int adminUserId, string? adminNotes = null)
        {
            var report = await _context.Reports.FindAsync(reportId);
            if (report == null) return false;

            report.Status = status;
            report.ReviewedBy = adminUserId;
            report.ReviewedAt = DateTime.UtcNow;
            report.AdminNotes = adminNotes;

            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<IEnumerable<Report>> GetReportsByUserAsync(int userId)
        {
            return await _context.Reports
                .Where(r => r.ReportedUserId == userId)
                .Include(r => r.ReportingUser)
                .Include(r => r.Reviewer)
                .OrderByDescending(r => r.TimeStamp)
                .ToListAsync();
        }
    }
}








