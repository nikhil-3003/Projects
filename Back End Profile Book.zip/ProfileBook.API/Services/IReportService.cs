using ProfileBook.Models;

namespace ProfileBook.API.Services
{
    public interface IReportService
    {
        Task<IEnumerable<Report>> GetAllReportsAsync();
        Task<IEnumerable<Report>> GetPendingReportsAsync();
        Task<Report?> CreateReportAsync(int reportedUserId, int reportingUserId, string reason);
        Task<Report?> GetReportByIdAsync(int reportId);
        Task<bool> UpdateReportStatusAsync(int reportId, string status, int adminUserId, string? adminNotes = null);
        Task<IEnumerable<Report>> GetReportsByUserAsync(int userId);
    }
}








