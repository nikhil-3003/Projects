using ProfileBook.Models;

namespace ProfileBook.API.Services
{
    public interface IMessageService
    {
        Task<IEnumerable<Message>> GetUserMessagesAsync(int userId);
        Task<IEnumerable<Message>> GetConversationAsync(int userId1, int userId2);
        Task<Message?> SendMessageAsync(int senderId, int receiverId, string content);
        Task<bool> MarkMessageAsReadAsync(int messageId);
        Task<bool> DeleteMessageAsync(int messageId);
        Task<int> GetUnreadMessageCountAsync(int userId);
    }
}








