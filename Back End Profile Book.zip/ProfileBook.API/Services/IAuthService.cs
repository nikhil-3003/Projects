using ProfileBook.Models;

namespace ProfileBook.API.Services
{
    public interface IAuthService
    {
        Task<string> GenerateJwtToken(User user);
        Task<User?> AuthenticateAsync(string username, string password);
        Task<User?> RegisterAsync(string username, string email, string password, string role = "User");
        Task<bool> ValidateTokenAsync(string token);
        Task<User?> GetUserFromTokenAsync(string token);
    }
}








