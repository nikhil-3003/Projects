using Microsoft.EntityFrameworkCore;
using ProfileBook.Data;
using ProfileBook.Models;

namespace ProfileBook.API.Services
{
    public class GroupService : IGroupService
    {
        private readonly ApplicationDbContext _context;

        public GroupService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Group>> GetAllGroupsAsync()
        {
            return await _context.Groups
                .Where(g => g.IsActive)
                .Include(g => g.Creator)
                .Include(g => g.GroupMembers)
                .ThenInclude(gm => gm.User)
                .ToListAsync();
        }

        public async Task<Group?> GetGroupByIdAsync(int groupId)
        {
            return await _context.Groups
                .Include(g => g.Creator)
                .Include(g => g.GroupMembers)
                .ThenInclude(gm => gm.User)
                .FirstOrDefaultAsync(g => g.GroupId == groupId && g.IsActive);
        }

        public async Task<Group?> CreateGroupAsync(Group group)
        {
            _context.Groups.Add(group);
            await _context.SaveChangesAsync();

            // Add creator as admin member
            var groupMember = new GroupMember
            {
                GroupId = group.GroupId,
                UserId = group.CreatedBy,
                Role = "Admin",
                JoinedAt = DateTime.UtcNow
            };

            _context.GroupMembers.Add(groupMember);
            await _context.SaveChangesAsync();

            return await GetGroupByIdAsync(group.GroupId);
        }

        public async Task<Group?> UpdateGroupAsync(int groupId, Group group)
        {
            var existingGroup = await _context.Groups.FindAsync(groupId);
            if (existingGroup == null) return null;

            existingGroup.GroupName = group.GroupName;
            existingGroup.Description = group.Description;

            await _context.SaveChangesAsync();
            return existingGroup;
        }

        public async Task<bool> DeleteGroupAsync(int groupId)
        {
            var group = await _context.Groups.FindAsync(groupId);
            if (group == null) return false;

            group.IsActive = false;
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> AddUserToGroupAsync(int groupId, int userId)
        {
            // Check if user is already in group
            var existingMember = await _context.GroupMembers
                .FirstOrDefaultAsync(gm => gm.GroupId == groupId && gm.UserId == userId);

            if (existingMember != null) return false;

            var groupMember = new GroupMember
            {
                GroupId = groupId,
                UserId = userId,
                Role = "Member",
                JoinedAt = DateTime.UtcNow
            };

            _context.GroupMembers.Add(groupMember);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> RemoveUserFromGroupAsync(int groupId, int userId)
        {
            var groupMember = await _context.GroupMembers
                .FirstOrDefaultAsync(gm => gm.GroupId == groupId && gm.UserId == userId);

            if (groupMember == null) return false;

            _context.GroupMembers.Remove(groupMember);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<IEnumerable<User>> GetGroupMembersAsync(int groupId)
        {
            return await _context.GroupMembers
                .Where(gm => gm.GroupId == groupId)
                .Include(gm => gm.User)
                .Select(gm => gm.User)
                .ToListAsync();
        }

        public async Task<IEnumerable<Group>> GetUserGroupsAsync(int userId)
        {
            return await _context.GroupMembers
                .Where(gm => gm.UserId == userId)
                .Include(gm => gm.Group)
                .ThenInclude(g => g.Creator)
                .Select(gm => gm.Group)
                .Where(g => g.IsActive)
                .ToListAsync();
        }
    }
}








