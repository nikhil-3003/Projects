using Microsoft.EntityFrameworkCore;
using ProfileBook.Data;
using ProfileBook.Models;

namespace ProfileBook.API.Services
{
    public class PostService : IPostService
    {
        private readonly ApplicationDbContext _context;

        public PostService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Post>> GetAllPostsAsync()
        {
            return await _context.Posts
                .Include(p => p.User)
                .Include(p => p.Likes)
                .Include(p => p.Comments)
                .OrderByDescending(p => p.CreatedAt)
                .ToListAsync();
        }

        public async Task<IEnumerable<Post>> GetApprovedPostsAsync()
        {
            return await _context.Posts
                .Where(p => p.Status == "Approved")
                .Include(p => p.User)
                .Include(p => p.Likes)
                .Include(p => p.Comments)
                .OrderByDescending(p => p.CreatedAt)
                .ToListAsync();
        }

        public async Task<IEnumerable<Post>> GetPendingPostsAsync()
        {
            return await _context.Posts
                .Where(p => p.Status == "Pending")
                .Include(p => p.User)
                .OrderByDescending(p => p.CreatedAt)
                .ToListAsync();
        }

        public async Task<Post?> GetPostByIdAsync(int postId)
        {
            return await _context.Posts
                .Include(p => p.User)
                .Include(p => p.Likes)
                .Include(p => p.Comments)
                .ThenInclude(c => c.User)
                .FirstOrDefaultAsync(p => p.PostId == postId);
        }

        public async Task<Post?> CreatePostAsync(Post post)
        {
            _context.Posts.Add(post);
            await _context.SaveChangesAsync();
            return post;
        }

        public async Task<Post?> UpdatePostAsync(int postId, Post post)
        {
            var existingPost = await _context.Posts.FindAsync(postId);
            if (existingPost == null) return null;

            existingPost.Content = post.Content;
            existingPost.PostImage = post.PostImage;

            await _context.SaveChangesAsync();
            return existingPost;
        }

        public async Task<bool> DeletePostAsync(int postId)
        {
            var post = await _context.Posts.FindAsync(postId);
            if (post == null) return false;

            _context.Posts.Remove(post);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> ApprovePostAsync(int postId, int adminUserId)
        {
            var post = await _context.Posts.FindAsync(postId);
            if (post == null) return false;

            post.Status = "Approved";
            post.ApprovedAt = DateTime.UtcNow;
            post.ApprovedBy = adminUserId;

            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> RejectPostAsync(int postId, int adminUserId)
        {
            var post = await _context.Posts.FindAsync(postId);
            if (post == null) return false;

            post.Status = "Rejected";
            post.ApprovedAt = DateTime.UtcNow;
            post.ApprovedBy = adminUserId;

            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<IEnumerable<Post>> GetUserPostsAsync(int userId)
        {
            return await _context.Posts
                .Where(p => p.UserId == userId)
                .Include(p => p.User)
                .Include(p => p.Likes)
                .Include(p => p.Comments)
                .OrderByDescending(p => p.CreatedAt)
                .ToListAsync();
        }

        public async Task<bool> LikePostAsync(int postId, int userId)
        {
            var existingLike = await _context.Likes
                .FirstOrDefaultAsync(l => l.PostId == postId && l.UserId == userId);

            if (existingLike != null) return false; // Already liked

            var like = new Like
            {
                PostId = postId,
                UserId = userId,
                CreatedAt = DateTime.UtcNow
            };

            _context.Likes.Add(like);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> UnlikePostAsync(int postId, int userId)
        {
            var like = await _context.Likes
                .FirstOrDefaultAsync(l => l.PostId == postId && l.UserId == userId);

            if (like == null) return false;

            _context.Likes.Remove(like);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<Comment?> AddCommentAsync(int postId, int userId, string content)
        {
            var comment = new Comment
            {
                PostId = postId,
                UserId = userId,
                Content = content,
                CreatedAt = DateTime.UtcNow
            };

            _context.Comments.Add(comment);
            await _context.SaveChangesAsync();

            return await _context.Comments
                .Include(c => c.User)
                .FirstOrDefaultAsync(c => c.CommentId == comment.CommentId);
        }

        public async Task<IEnumerable<Comment>> GetPostCommentsAsync(int postId)
        {
            return await _context.Comments
                .Where(c => c.PostId == postId)
                .Include(c => c.User)
                .OrderBy(c => c.CreatedAt)
                .ToListAsync();
        }

        public async Task<IEnumerable<Post>> SearchPostsAsync(string query)
        {
            return await _context.Posts
                .Where(p => p.Status == "Approved" && 
                           (p.Content.Contains(query) || p.User.Username.Contains(query)))
                .Include(p => p.User)
                .Include(p => p.Likes)
                .Include(p => p.Comments)
                .OrderByDescending(p => p.CreatedAt)
                .ToListAsync();
        }
    }
}

