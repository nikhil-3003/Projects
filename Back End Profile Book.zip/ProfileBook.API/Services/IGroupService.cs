using ProfileBook.Models;

namespace ProfileBook.API.Services
{
    public interface IGroupService
    {
        Task<IEnumerable<Group>> GetAllGroupsAsync();
        Task<Group?> GetGroupByIdAsync(int groupId);
        Task<Group?> CreateGroupAsync(Group group);
        Task<Group?> UpdateGroupAsync(int groupId, Group group);
        Task<bool> DeleteGroupAsync(int groupId);
        Task<bool> AddUserToGroupAsync(int groupId, int userId);
        Task<bool> RemoveUserFromGroupAsync(int groupId, int userId);
        Task<IEnumerable<User>> GetGroupMembersAsync(int groupId);
        Task<IEnumerable<Group>> GetUserGroupsAsync(int userId);
    }
}








