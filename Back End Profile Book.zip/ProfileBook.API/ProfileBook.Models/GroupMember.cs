using System.ComponentModel.DataAnnotations;

namespace ProfileBook.Models
{
    public class GroupMember
    {
        public int GroupMemberId { get; set; }
        
        [Required]
        public int GroupId { get; set; }
        
        [Required]
        public int UserId { get; set; }
        
        public DateTime JoinedAt { get; set; } = DateTime.UtcNow;
        
        [StringLength(20)]
        public string Role { get; set; } = "Member"; // Member, Moderator, Admin
        
        // Navigation properties
        public virtual Group Group { get; set; } = null!;
        public virtual User User { get; set; } = null!;
    }
}

