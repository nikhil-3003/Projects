using System.ComponentModel.DataAnnotations;

namespace ProfileBook.Models
{
    public class Message
    {
        public int MessageId { get; set; }
        
        [Required]
        public int SenderId { get; set; }
        
        [Required]
        public int ReceiverId { get; set; }
        
        [Required]
        [StringLength(1000)]
        public string MessageContent { get; set; } = string.Empty;
        
        public DateTime TimeStamp { get; set; } = DateTime.UtcNow;
        
        public bool IsRead { get; set; } = false;
        
        // Navigation properties
        public virtual User Sender { get; set; } = null!;
        public virtual User Receiver { get; set; } = null!;
    }
}

