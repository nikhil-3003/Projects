using System.ComponentModel.DataAnnotations;

namespace ProfileBook.Models
{
    public class Report
    {
        public int ReportId { get; set; }
        
        [Required]
        public int ReportedUserId { get; set; }
        
        [Required]
        public int ReportingUserId { get; set; }
        
        [Required]
        [StringLength(500)]
        public string Reason { get; set; } = string.Empty;
        
        public DateTime TimeStamp { get; set; } = DateTime.UtcNow;
        
        [StringLength(20)]
        public string Status { get; set; } = "Pending"; // Pending, Reviewed, Resolved
        
        public int? ReviewedBy { get; set; } // Admin UserId who reviewed
        
        public DateTime? ReviewedAt { get; set; }
        
        [StringLength(500)]
        public string? AdminNotes { get; set; }
        
        // Navigation properties
        public virtual User ReportedUser { get; set; } = null!;
        public virtual User ReportingUser { get; set; } = null!;
        public virtual User? Reviewer { get; set; }
    }
}

