using System.ComponentModel.DataAnnotations;

namespace ProfileBook.Models
{
    public class Group
    {
        public int GroupId { get; set; }
        
        [Required]
        [StringLength(100)]
        public string GroupName { get; set; } = string.Empty;
        
        [StringLength(500)]
        public string? Description { get; set; }
        
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        
        public int CreatedBy { get; set; } // Admin UserId who created the group
        
        public bool IsActive { get; set; } = true;
        
        // Navigation properties
        public virtual User Creator { get; set; } = null!;
        public virtual ICollection<GroupMember> GroupMembers { get; set; } = new List<GroupMember>();
    }
}

