using System.ComponentModel.DataAnnotations;

namespace ProfileBook.Models
{
    public class Friend
    {
        public int FriendId { get; set; }

        [Required]
        public int UserId { get; set; }

        [Required]
        public int FriendUserId { get; set; }

        [Required]
        [StringLength(20)]
        public string Status { get; set; } = "Pending"; // Pending, Accepted, Blocked

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public DateTime? UpdatedAt { get; set; }

        // Navigation properties
        public virtual User User { get; set; } = null!;
        public virtual User FriendUser { get; set; } = null!;
    }
}

