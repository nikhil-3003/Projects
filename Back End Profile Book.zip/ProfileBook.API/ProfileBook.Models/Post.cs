using System.ComponentModel.DataAnnotations;

namespace ProfileBook.Models
{
    public class Post
    {
        public int PostId { get; set; }
        
        [Required]
        public int UserId { get; set; }
        
        [Required]
        [StringLength(1000)]
        public string Content { get; set; } = string.Empty;
        
        [StringLength(200)]
        public string? PostImage { get; set; }
        
        [Required]
        [StringLength(20)]
        public string Status { get; set; } = "Pending"; // Pending, Approved, Rejected
        
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        
        public DateTime? ApprovedAt { get; set; }
        
        public int? ApprovedBy { get; set; } // Admin UserId who approved
        
        // Navigation properties
        public virtual User User { get; set; } = null!;
        public virtual User? Approver { get; set; }
        public virtual ICollection<Like> Likes { get; set; } = new List<Like>();
        public virtual ICollection<Comment> Comments { get; set; } = new List<Comment>();
    }
}

