using System.ComponentModel.DataAnnotations;

namespace ProfileBook.Models
{
    public class Notification
    {
        public int NotificationId { get; set; }

        [Required]
        public int UserId { get; set; }

        [Required]
        [StringLength(200)]
        public string Title { get; set; } = string.Empty;

        [Required]
        [StringLength(500)]
        public string Message { get; set; } = string.Empty;

        [Required]
        [StringLength(50)]
        public string Type { get; set; } = string.Empty; // Like, Comment, Message, PostApproval, etc.

        public bool IsRead { get; set; } = false;

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public int? RelatedId { get; set; } // ID of related post, message, etc.

        // Navigation properties
        public virtual User User { get; set; } = null!;
    }
}

