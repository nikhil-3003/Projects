using System.ComponentModel.DataAnnotations;

namespace ProfileBook.Models
{
    public class User
    {
        public int UserId { get; set; }
        
        [Required]
        [StringLength(50)]
        public string Username { get; set; } = string.Empty;
        
        [Required]
        [EmailAddress]
        [StringLength(100)]
        public string Email { get; set; } = string.Empty;
        
        [Required]
        [StringLength(100)]
        public string Password { get; set; } = string.Empty;
        
        [Required]
        [StringLength(20)]
        public string Role { get; set; } = "User"; // User or Admin
        
        [StringLength(200)]
        public string? ProfileImage { get; set; }
        
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        
        public bool IsActive { get; set; } = true;
        
        // Navigation properties
        public virtual ICollection<Post> Posts { get; set; } = new List<Post>();
        public virtual ICollection<Message> SentMessages { get; set; } = new List<Message>();
        public virtual ICollection<Message> ReceivedMessages { get; set; } = new List<Message>();
        public virtual ICollection<Report> ReportedBy { get; set; } = new List<Report>();
        public virtual ICollection<Report> ReportedUsers { get; set; } = new List<Report>();
        public virtual ICollection<GroupMember> GroupMemberships { get; set; } = new List<GroupMember>();
    }
}

