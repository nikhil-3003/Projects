using Microsoft.AspNetCore.SignalR;
using ProfileBook.API.Services;

namespace ProfileBook.API.Hubs
{
    public class ChatHub : Hub
    {
        private readonly IMessageService _messageService;

        public ChatHub(IMessageService messageService)
        {
            _messageService = messageService;
        }

        public async Task JoinGroup(string groupName)
        {
            await Groups.AddToGroupAsync(Context.ConnectionId, groupName);
        }

        public async Task LeaveGroup(string groupName)
        {
            await Groups.RemoveFromGroupAsync(Context.ConnectionId, groupName);
        }

        public async Task SendMessageToUser(int receiverId, string message)
        {
            var senderId = GetUserIdFromContext();
            if (senderId == null) return;

            var sentMessage = await _messageService.SendMessageAsync(senderId.Value, receiverId, message);
            if (sentMessage != null)
            {
                await Clients.User(receiverId.ToString()).SendAsync("ReceiveMessage", sentMessage);
                await Clients.Caller.SendAsync("MessageSent", sentMessage);
            }
        }

        public async Task SendMessageToGroup(string groupName, string message)
        {
            var senderId = GetUserIdFromContext();
            if (senderId == null) return;

            await Clients.Group(groupName).SendAsync("ReceiveGroupMessage", new
            {
                SenderId = senderId,
                Message = message,
                Timestamp = DateTime.UtcNow
            });
        }

        public async Task NotifyPostApproval(int userId, int postId, string status)
        {
            await Clients.User(userId.ToString()).SendAsync("PostStatusUpdate", new
            {
                PostId = postId,
                Status = status,
                Timestamp = DateTime.UtcNow
            });
        }

        private int? GetUserIdFromContext()
        {
            var userIdClaim = Context.User?.FindFirst("UserId");
            if (userIdClaim != null && int.TryParse(userIdClaim.Value, out int userId))
            {
                return userId;
            }
            return null;
        }
    }
}








