using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProfileBook.API.Services;
using System.Security.Claims;

namespace ProfileBook.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class ReportsController : ControllerBase
    {
        private readonly IReportService _reportService;

        public ReportsController(IReportService reportService)
        {
            _reportService = reportService;
        }

        [HttpGet]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetAllReports()
        {
            var reports = await _reportService.GetAllReportsAsync();
            return Ok(reports);
        }

        [HttpGet("pending")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetPendingReports()
        {
            var reports = await _reportService.GetPendingReportsAsync();
            return Ok(reports);
        }

        [HttpPost]
        public async Task<IActionResult> CreateReport([FromBody] CreateReportRequest request)
        {
            var reportingUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            var report = await _reportService.CreateReportAsync(request.ReportedUserId, reportingUserId, request.Reason);
            if (report == null)
            {
                return BadRequest(new { message = "Unable to create report" });
            }

            return Ok(report);
        }

        [HttpGet("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetReport(int id)
        {
            var report = await _reportService.GetReportByIdAsync(id);
            if (report == null)
            {
                return NotFound();
            }
            return Ok(report);
        }

        [HttpPut("{id}/status")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> UpdateReportStatus(int id, [FromBody] UpdateReportStatusRequest request)
        {
            var adminUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            var result = await _reportService.UpdateReportStatusAsync(id, request.Status, adminUserId, request.AdminNotes);
            if (!result)
            {
                return NotFound();
            }

            return Ok(new { message = "Report status updated successfully" });
        }

        [HttpGet("user/{userId}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetReportsByUser(int userId)
        {
            var reports = await _reportService.GetReportsByUserAsync(userId);
            return Ok(reports);
        }
    }

    public class CreateReportRequest
    {
        public int ReportedUserId { get; set; }
        public string Reason { get; set; } = string.Empty;
    }

    public class UpdateReportStatusRequest
    {
        public string Status { get; set; } = string.Empty;
        public string? AdminNotes { get; set; }
    }
}








