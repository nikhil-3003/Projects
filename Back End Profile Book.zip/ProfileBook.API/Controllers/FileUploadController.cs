using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace ProfileBook.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class FileUploadController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private readonly IWebHostEnvironment _environment;

        public FileUploadController(IConfiguration configuration, IWebHostEnvironment environment)
        {
            _configuration = configuration;
            _environment = environment;
        }

        [HttpPost("profile-image")]
        public async Task<IActionResult> UploadProfileImage(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                return BadRequest(new { message = "No file uploaded" });
            }

            var allowedExtensions = _configuration.GetSection("FileUpload:AllowedExtensions").Get<string[]>() ?? new[] { ".jpg", ".jpeg", ".png", ".gif" };
            var maxFileSize = _configuration.GetValue<long>("FileUpload:MaxFileSize", 5242880); // 5MB default
            var uploadPath = _configuration.GetValue<string>("FileUpload:UploadPath") ?? "wwwroot/uploads";

            // Validate file size
            if (file.Length > maxFileSize)
            {
                return BadRequest(new { message = "File size exceeds maximum allowed size" });
            }

            // Validate file extension
            var fileExtension = Path.GetExtension(file.FileName).ToLowerInvariant();
            if (!allowedExtensions.Contains(fileExtension))
            {
                return BadRequest(new { message = "Invalid file type. Allowed types: " + string.Join(", ", allowedExtensions) });
            }

            try
            {
                // Create upload directory if it doesn't exist
                var fullUploadPath = Path.Combine(_environment.ContentRootPath, uploadPath, "profiles");
                if (!Directory.Exists(fullUploadPath))
                {
                    Directory.CreateDirectory(fullUploadPath);
                }

                // Generate unique filename
                var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "unknown";
                var fileName = $"profile_{userId}_{DateTime.UtcNow:yyyyMMddHHmmss}{fileExtension}";
                var filePath = Path.Combine(fullUploadPath, fileName);

                // Save file
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await file.CopyToAsync(stream);
                }

                // Return relative path for database storage
                var relativePath = $"/uploads/profiles/{fileName}";
                return Ok(new { filePath = relativePath, message = "File uploaded successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error uploading file: " + ex.Message });
            }
        }

        [HttpPost("post-image")]
        public async Task<IActionResult> UploadPostImage(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                return BadRequest(new { message = "No file uploaded" });
            }

            var allowedExtensions = _configuration.GetSection("FileUpload:AllowedExtensions").Get<string[]>() ?? new[] { ".jpg", ".jpeg", ".png", ".gif" };
            var maxFileSize = _configuration.GetValue<long>("FileUpload:MaxFileSize", 5242880); // 5MB default
            var uploadPath = _configuration.GetValue<string>("FileUpload:UploadPath") ?? "wwwroot/uploads";

            // Validate file size
            if (file.Length > maxFileSize)
            {
                return BadRequest(new { message = "File size exceeds maximum allowed size" });
            }

            // Validate file extension
            var fileExtension = Path.GetExtension(file.FileName).ToLowerInvariant();
            if (!allowedExtensions.Contains(fileExtension))
            {
                return BadRequest(new { message = "Invalid file type. Allowed types: " + string.Join(", ", allowedExtensions) });
            }

            try
            {
                // Create upload directory if it doesn't exist
                var fullUploadPath = Path.Combine(_environment.ContentRootPath, uploadPath, "posts");
                if (!Directory.Exists(fullUploadPath))
                {
                    Directory.CreateDirectory(fullUploadPath);
                }

                // Generate unique filename
                var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "unknown";
                var fileName = $"post_{userId}_{DateTime.UtcNow:yyyyMMddHHmmss}{fileExtension}";
                var filePath = Path.Combine(fullUploadPath, fileName);

                // Save file
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await file.CopyToAsync(stream);
                }

                // Return relative path for database storage
                var relativePath = $"/uploads/posts/{fileName}";
                return Ok(new { filePath = relativePath, message = "File uploaded successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error uploading file: " + ex.Message });
            }
        }
    }
}





