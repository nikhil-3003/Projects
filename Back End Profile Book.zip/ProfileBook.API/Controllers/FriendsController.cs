using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProfileBook.API.Services;
using System.Security.Claims;

namespace ProfileBook.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class FriendsController : ControllerBase
    {
        private readonly IFriendService _friendService;

        public FriendsController(IFriendService friendService)
        {
            _friendService = friendService;
        }

        [HttpGet]
        public async Task<IActionResult> GetUserFriends()
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var friends = await _friendService.GetUserFriendsAsync(userId.Value);
            return Ok(friends);
        }

        [HttpGet("pending")]
        public async Task<IActionResult> GetPendingRequests()
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var pendingRequests = await _friendService.GetPendingFriendRequestsAsync(userId.Value);
            return Ok(pendingRequests);
        }

        [HttpGet("sent")]
        public async Task<IActionResult> GetSentRequests()
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var sentRequests = await _friendService.GetSentFriendRequestsAsync(userId.Value);
            return Ok(sentRequests);
        }

        [HttpPost("send/{friendUserId}")]
        public async Task<IActionResult> SendFriendRequest(int friendUserId)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var friendRequest = await _friendService.SendFriendRequestAsync(userId.Value, friendUserId);
            if (friendRequest == null)
            {
                return BadRequest("Friend request could not be sent");
            }

            return Ok(friendRequest);
        }

        [HttpPost("{friendId}/accept")]
        public async Task<IActionResult> AcceptFriendRequest(int friendId)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var result = await _friendService.AcceptFriendRequestAsync(friendId, userId.Value);
            if (!result)
            {
                return BadRequest("Friend request could not be accepted");
            }

            return Ok(new { message = "Friend request accepted" });
        }

        [HttpPost("{friendId}/reject")]
        public async Task<IActionResult> RejectFriendRequest(int friendId)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var result = await _friendService.RejectFriendRequestAsync(friendId, userId.Value);
            if (!result)
            {
                return BadRequest("Friend request could not be rejected");
            }

            return Ok(new { message = "Friend request rejected" });
        }

        [HttpDelete("{friendUserId}")]
        public async Task<IActionResult> RemoveFriend(int friendUserId)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var result = await _friendService.RemoveFriendAsync(userId.Value, friendUserId);
            if (!result)
            {
                return BadRequest("Friend could not be removed");
            }

            return Ok(new { message = "Friend removed" });
        }

        [HttpPost("block/{blockedUserId}")]
        public async Task<IActionResult> BlockUser(int blockedUserId)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var result = await _friendService.BlockUserAsync(userId.Value, blockedUserId);
            if (!result)
            {
                return BadRequest("User could not be blocked");
            }

            return Ok(new { message = "User blocked" });
        }

        [HttpDelete("block/{blockedUserId}")]
        public async Task<IActionResult> UnblockUser(int blockedUserId)
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var result = await _friendService.UnblockUserAsync(userId.Value, blockedUserId);
            if (!result)
            {
                return BadRequest("User could not be unblocked");
            }

            return Ok(new { message = "User unblocked" });
        }

        [HttpGet("count")]
        public async Task<IActionResult> GetFriendCount()
        {
            var userId = GetCurrentUserId();
            if (userId == null) return Unauthorized();

            var count = await _friendService.GetFriendCountAsync(userId.Value);
            return Ok(new { count });
        }

        private int? GetCurrentUserId()
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            return int.TryParse(userIdClaim, out var userId) ? userId : null;
        }
    }
}

