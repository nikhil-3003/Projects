using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProfileBook.API.Services;
using ProfileBook.Models;
using System.Security.Claims;

namespace ProfileBook.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class PostsController : ControllerBase
    {
        private readonly IPostService _postService;

        public PostsController(IPostService postService)
        {
            _postService = postService;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllPosts()
        {
            var posts = await _postService.GetAllPostsAsync();
            return Ok(posts);
        }

        [HttpGet("approved")]
        public async Task<IActionResult> GetApprovedPosts()
        {
            var posts = await _postService.GetApprovedPostsAsync();
            return Ok(posts);
        }

        [HttpGet("pending")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetPendingPosts()
        {
            var posts = await _postService.GetPendingPostsAsync();
            return Ok(posts);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetPost(int id)
        {
            var post = await _postService.GetPostByIdAsync(id);
            if (post == null)
            {
                return NotFound();
            }
            return Ok(post);
        }

        [HttpGet("search")]
        public async Task<IActionResult> SearchPosts([FromQuery] string query)
        {
            if (string.IsNullOrWhiteSpace(query))
                return BadRequest("Search query cannot be empty");

            var posts = await _postService.SearchPostsAsync(query);
            return Ok(posts);
        }

        [HttpPost]
        public async Task<IActionResult> CreatePost([FromBody] CreatePostRequest request)
        {
            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            
            var post = new Post
            {
                UserId = userId,
                Content = request.Content,
                PostImage = request.PostImage,
                Status = "Pending",
                CreatedAt = DateTime.UtcNow
            };

            var createdPost = await _postService.CreatePostAsync(post);
            return CreatedAtAction(nameof(GetPost), new { id = createdPost?.PostId }, createdPost);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatePost(int id, [FromBody] UpdatePostRequest request)
        {
            var post = new Post
            {
                PostId = id,
                Content = request.Content,
                PostImage = request.PostImage
            };

            var updatedPost = await _postService.UpdatePostAsync(id, post);
            if (updatedPost == null)
            {
                return NotFound();
            }

            return Ok(updatedPost);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeletePost(int id)
        {
            var result = await _postService.DeletePostAsync(id);
            if (!result)
            {
                return NotFound();
            }

            return NoContent();
        }

        [HttpPost("{id}/approve")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> ApprovePost(int id)
        {
            var adminUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            var result = await _postService.ApprovePostAsync(id, adminUserId);
            if (!result)
            {
                return NotFound();
            }

            return Ok(new { message = "Post approved successfully" });
        }

        [HttpPost("{id}/reject")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> RejectPost(int id)
        {
            var adminUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            var result = await _postService.RejectPostAsync(id, adminUserId);
            if (!result)
            {
                return NotFound();
            }

            return Ok(new { message = "Post rejected successfully" });
        }

        [HttpGet("user/{userId}")]
        public async Task<IActionResult> GetUserPosts(int userId)
        {
            var posts = await _postService.GetUserPostsAsync(userId);
            return Ok(posts);
        }

        [HttpPost("{id}/like")]
        public async Task<IActionResult> LikePost(int id)
        {
            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            var result = await _postService.LikePostAsync(id, userId);
            if (!result)
            {
                return BadRequest(new { message = "Unable to like post" });
            }

            return Ok(new { message = "Post liked successfully" });
        }

        [HttpDelete("{id}/like")]
        public async Task<IActionResult> UnlikePost(int id)
        {
            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            var result = await _postService.UnlikePostAsync(id, userId);
            if (!result)
            {
                return BadRequest(new { message = "Unable to unlike post" });
            }

            return Ok(new { message = "Post unliked successfully" });
        }

        [HttpPost("{id}/comment")]
        public async Task<IActionResult> AddComment(int id, [FromBody] AddCommentRequest request)
        {
            var userId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            var comment = await _postService.AddCommentAsync(id, userId, request.Content);
            if (comment == null)
            {
                return BadRequest(new { message = "Unable to add comment" });
            }

            return Ok(comment);
        }

        [HttpGet("{id}/comments")]
        public async Task<IActionResult> GetPostComments(int id)
        {
            var comments = await _postService.GetPostCommentsAsync(id);
            return Ok(comments);
        }
    }

    public class CreatePostRequest
    {
        public string Content { get; set; } = string.Empty;
        public string? PostImage { get; set; }
    }

    public class UpdatePostRequest
    {
        public string Content { get; set; } = string.Empty;
        public string? PostImage { get; set; }
    }

    public class AddCommentRequest
    {
        public string Content { get; set; } = string.Empty;
    }
}

