using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProfileBook.API.Services;
using ProfileBook.Models;
using System.Security.Claims;

namespace ProfileBook.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class GroupsController : ControllerBase
    {
        private readonly IGroupService _groupService;

        public GroupsController(IGroupService groupService)
        {
            _groupService = groupService;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllGroups()
        {
            var groups = await _groupService.GetAllGroupsAsync();
            return Ok(groups);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetGroup(int id)
        {
            var group = await _groupService.GetGroupByIdAsync(id);
            if (group == null)
            {
                return NotFound();
            }
            return Ok(group);
        }

        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> CreateGroup([FromBody] CreateGroupRequest request)
        {
            var adminUserId = int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "0");
            
            var group = new Group
            {
                GroupName = request.GroupName,
                Description = request.Description,
                CreatedBy = adminUserId,
                CreatedAt = DateTime.UtcNow,
                IsActive = true
            };

            var createdGroup = await _groupService.CreateGroupAsync(group);
            return CreatedAtAction(nameof(GetGroup), new { id = createdGroup?.GroupId }, createdGroup);
        }

        [HttpPut("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> UpdateGroup(int id, [FromBody] UpdateGroupRequest request)
        {
            var group = new Group
            {
                GroupId = id,
                GroupName = request.GroupName,
                Description = request.Description
            };

            var updatedGroup = await _groupService.UpdateGroupAsync(id, group);
            if (updatedGroup == null)
            {
                return NotFound();
            }

            return Ok(updatedGroup);
        }

        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteGroup(int id)
        {
            var result = await _groupService.DeleteGroupAsync(id);
            if (!result)
            {
                return NotFound();
            }

            return NoContent();
        }

        [HttpPost("{id}/members/{userId}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> AddUserToGroup(int id, int userId)
        {
            var result = await _groupService.AddUserToGroupAsync(id, userId);
            if (!result)
            {
                return BadRequest(new { message = "Unable to add user to group" });
            }

            return Ok(new { message = "User added to group successfully" });
        }

        [HttpDelete("{id}/members/{userId}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> RemoveUserFromGroup(int id, int userId)
        {
            var result = await _groupService.RemoveUserFromGroupAsync(id, userId);
            if (!result)
            {
                return BadRequest(new { message = "Unable to remove user from group" });
            }

            return Ok(new { message = "User removed from group successfully" });
        }

        [HttpGet("{id}/members")]
        public async Task<IActionResult> GetGroupMembers(int id)
        {
            var members = await _groupService.GetGroupMembersAsync(id);
            return Ok(members);
        }

        [HttpGet("user/{userId}")]
        public async Task<IActionResult> GetUserGroups(int userId)
        {
            var groups = await _groupService.GetUserGroupsAsync(userId);
            return Ok(groups);
        }
    }

    public class CreateGroupRequest
    {
        public string GroupName { get; set; } = string.Empty;
        public string? Description { get; set; }
    }

    public class UpdateGroupRequest
    {
        public string GroupName { get; set; } = string.Empty;
        public string? Description { get; set; }
    }
}








