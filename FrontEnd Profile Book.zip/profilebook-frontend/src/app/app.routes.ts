import { Routes } from '@angular/router';
import { AuthGuard } from './guards/auth.guard';
import { AdminGuard } from './guards/admin.guard';

export const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { 
    path: 'login', 
    loadComponent: () => import('./components/auth/login/login.component').then(m => m.LoginComponent)
  },
  { 
    path: 'register', 
    loadComponent: () => import('./components/auth/register/register.component').then(m => m.RegisterComponent)
  },
  { 
    path: 'dashboard', 
    loadComponent: () => import('./components/dashboard/dashboard.component').then(m => m.DashboardComponent),
    canActivate: [AuthGuard]
  },
  { 
    path: 'posts', 
    loadComponent: () => import('./components/posts/posts.component').then(m => m.PostsComponent),
    canActivate: [AuthGuard]
  },
  { 
    path: 'messages', 
    loadComponent: () => import('./components/messages/messages.component').then(m => m.MessagesComponent),
    canActivate: [AuthGuard]
  },
  { 
    path: 'profile', 
    loadComponent: () => import('./components/profile/profile.component').then(m => m.ProfileComponent),
    canActivate: [AuthGuard]
  },
  { 
    path: 'notifications', 
    loadComponent: () => import('./components/notifications/notifications.component').then(m => m.NotificationsComponent),
    canActivate: [AuthGuard]
  },
  { 
    path: 'search', 
    loadComponent: () => import('./components/search/search.component').then(m => m.SearchComponent),
    canActivate: [AuthGuard]
  },
  { 
    path: 'friends', 
    loadComponent: () => import('./components/friends/friends.component').then(m => m.FriendsComponent),
    canActivate: [AuthGuard]
  },
  { 
    path: 'admin', 
    loadComponent: () => import('./components/admin/admin-dashboard/admin-dashboard.component').then(m => m.AdminDashboardComponent),
    canActivate: [AuthGuard, AdminGuard]
  },
  { 
    path: 'admin/users', 
    loadComponent: () => import('./components/admin/user-management/user-management.component').then(m => m.UserManagementComponent),
    canActivate: [AuthGuard, AdminGuard]
  },
  { 
    path: 'admin/posts', 
    loadComponent: () => import('./components/admin/post-approval/post-approval.component').then(m => m.PostApprovalComponent),
    canActivate: [AuthGuard, AdminGuard]
  },
  { 
    path: 'admin/reports', 
    loadComponent: () => import('./components/admin/report-management/report-management.component').then(m => m.ReportManagementComponent),
    canActivate: [AuthGuard, AdminGuard]
  },
  { 
    path: 'admin/groups', 
    loadComponent: () => import('./components/admin/group-management/group-management.component').then(m => m.GroupManagementComponent),
    canActivate: [AuthGuard, AdminGuard]
  },
  { path: '**', redirectTo: '/login' }
];