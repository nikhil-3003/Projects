import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from '../models/user.model';
import { Post, CreatePostRequest, AddCommentRequest } from '../models/post.model';
import { Message, SendMessageRequest } from '../models/message.model';
import { Report, CreateReportRequest, UpdateReportStatusRequest } from '../models/report.model';
import { Group, CreateGroupRequest, UpdateGroupRequest } from '../models/group.model';
import { Notification } from '../models/notification.model';
import { Friend, FriendRequest } from '../models/friend.model';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private readonly API_URL = 'http://localhost:5000/api';

  constructor(private http: HttpClient) { }

  // User endpoints
  getUsers(): Observable<User[]> {
    return this.http.get<User[]>(`${this.API_URL}/users`);
  }

  getUser(id: number): Observable<User> {
    return this.http.get<User>(`${this.API_URL}/users/${id}`);
  }

  searchUsers(searchTerm: string): Observable<User[]> {
    return this.http.get<User[]>(`${this.API_URL}/users/search/${searchTerm}`);
  }

  updateUser(id: number, user: User): Observable<User> {
    return this.http.put<User>(`${this.API_URL}/users/${id}`, user);
  }

  deleteUser(id: number): Observable<void> {
    return this.http.delete<void>(`${this.API_URL}/users/${id}`);
  }

  updateProfile(id: number, profileImage: string): Observable<any> {
    return this.http.put(`${this.API_URL}/users/${id}/profile`, { profileImage });
  }

  // Post endpoints
  getPosts(): Observable<Post[]> {
    return this.http.get<Post[]>(`${this.API_URL}/posts`);
  }

  getApprovedPosts(): Observable<Post[]> {
    return this.http.get<Post[]>(`${this.API_URL}/posts/approved`);
  }

  getPendingPosts(): Observable<Post[]> {
    return this.http.get<Post[]>(`${this.API_URL}/posts/pending`);
  }

  getPost(id: number): Observable<Post> {
    return this.http.get<Post>(`${this.API_URL}/posts/${id}`);
  }

  createPost(post: CreatePostRequest): Observable<Post> {
    return this.http.post<Post>(`${this.API_URL}/posts`, post);
  }

  updatePost(id: number, post: CreatePostRequest): Observable<Post> {
    return this.http.put<Post>(`${this.API_URL}/posts/${id}`, post);
  }

  deletePost(id: number): Observable<void> {
    return this.http.delete<void>(`${this.API_URL}/posts/${id}`);
  }

  approvePost(id: number): Observable<any> {
    return this.http.post(`${this.API_URL}/posts/${id}/approve`, {});
  }

  rejectPost(id: number): Observable<any> {
    return this.http.post(`${this.API_URL}/posts/${id}/reject`, {});
  }

  getUserPosts(userId: number): Observable<Post[]> {
    return this.http.get<Post[]>(`${this.API_URL}/posts/user/${userId}`);
  }

  likePost(id: number): Observable<any> {
    return this.http.post(`${this.API_URL}/posts/${id}/like`, {});
  }

  unlikePost(id: number): Observable<any> {
    return this.http.delete(`${this.API_URL}/posts/${id}/like`);
  }

  addComment(id: number, comment: AddCommentRequest): Observable<any> {
    return this.http.post(`${this.API_URL}/posts/${id}/comment`, comment);
  }

  getPostComments(id: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.API_URL}/posts/${id}/comments`);
  }

  // Message endpoints
  getUserMessages(): Observable<Message[]> {
    return this.http.get<Message[]>(`${this.API_URL}/messages`);
  }

  getConversation(otherUserId: number): Observable<Message[]> {
    return this.http.get<Message[]>(`${this.API_URL}/messages/conversation/${otherUserId}`);
  }

  sendMessage(message: SendMessageRequest): Observable<Message> {
    return this.http.post<Message>(`${this.API_URL}/messages`, message);
  }

  markAsRead(id: number): Observable<any> {
    return this.http.put(`${this.API_URL}/messages/${id}/read`, {});
  }

  deleteMessage(id: number): Observable<void> {
    return this.http.delete<void>(`${this.API_URL}/messages/${id}`);
  }

  getUnreadCount(): Observable<{ count: number }> {
    return this.http.get<{ count: number }>(`${this.API_URL}/messages/unread-count`);
  }

  // Report endpoints
  getReports(): Observable<Report[]> {
    return this.http.get<Report[]>(`${this.API_URL}/reports`);
  }

  getPendingReports(): Observable<Report[]> {
    return this.http.get<Report[]>(`${this.API_URL}/reports/pending`);
  }

  createReport(report: CreateReportRequest): Observable<Report> {
    return this.http.post<Report>(`${this.API_URL}/reports`, report);
  }

  getReport(id: number): Observable<Report> {
    return this.http.get<Report>(`${this.API_URL}/reports/${id}`);
  }

  updateReportStatus(id: number, status: string): Observable<any> {
    return this.http.put(`${this.API_URL}/reports/${id}/status`, { status });
  }

  getReportsByUser(userId: number): Observable<Report[]> {
    return this.http.get<Report[]>(`${this.API_URL}/reports/user/${userId}`);
  }

  // Group endpoints
  getGroups(): Observable<Group[]> {
    return this.http.get<Group[]>(`${this.API_URL}/groups`);
  }

  getGroup(id: number): Observable<Group> {
    return this.http.get<Group>(`${this.API_URL}/groups/${id}`);
  }

  createGroup(group: CreateGroupRequest): Observable<Group> {
    return this.http.post<Group>(`${this.API_URL}/groups`, group);
  }

  updateGroup(id: number, group: UpdateGroupRequest): Observable<Group> {
    return this.http.put<Group>(`${this.API_URL}/groups/${id}`, group);
  }

  deleteGroup(id: number): Observable<void> {
    return this.http.delete<void>(`${this.API_URL}/groups/${id}`);
  }

  addUserToGroup(groupId: number, userId: number): Observable<any> {
    return this.http.post(`${this.API_URL}/groups/${groupId}/members/${userId}`, {});
  }

  removeUserFromGroup(groupId: number, userId: number): Observable<any> {
    return this.http.delete(`${this.API_URL}/groups/${groupId}/members/${userId}`);
  }

  getGroupMembers(groupId: number): Observable<User[]> {
    return this.http.get<User[]>(`${this.API_URL}/groups/${groupId}/members`);
  }

  getUserGroups(userId: number): Observable<Group[]> {
    return this.http.get<Group[]>(`${this.API_URL}/groups/user/${userId}`);
  }

  // File upload endpoints
  uploadProfileImage(file: File): Observable<{ filePath: string }> {
    const formData = new FormData();
    formData.append('file', file);
    return this.http.post<{ filePath: string }>(`${this.API_URL}/fileupload/profile-image`, formData);
  }

  uploadPostImage(file: File): Observable<{ filePath: string }> {
    const formData = new FormData();
    formData.append('file', file);
    return this.http.post<{ filePath: string }>(`${this.API_URL}/fileupload/post-image`, formData);
  }

  // Notification endpoints
  getNotifications(): Observable<Notification[]> {
    return this.http.get<Notification[]>(`${this.API_URL}/notifications`);
  }

  getNotificationUnreadCount(): Observable<{ count: number }> {
    return this.http.get<{ count: number }>(`${this.API_URL}/notifications/unread-count`);
  }

  markNotificationAsRead(notificationId: number): Observable<any> {
    return this.http.post(`${this.API_URL}/notifications/${notificationId}/mark-read`, {});
  }

  markAllAsRead(): Observable<any> {
    return this.http.post(`${this.API_URL}/notifications/mark-all-read`, {});
  }

  deleteNotification(notificationId: number): Observable<any> {
    return this.http.delete(`${this.API_URL}/notifications/${notificationId}`);
  }

  // Search endpoints

  searchPosts(query: string): Observable<Post[]> {
    return this.http.get<Post[]>(`${this.API_URL}/posts/search?query=${encodeURIComponent(query)}`);
  }

  // Friend endpoints
  getFriends(): Observable<Friend[]> {
    return this.http.get<Friend[]>(`${this.API_URL}/friends`);
  }

  getPendingRequests(): Observable<FriendRequest[]> {
    return this.http.get<FriendRequest[]>(`${this.API_URL}/friends/pending`);
  }

  getSentRequests(): Observable<FriendRequest[]> {
    return this.http.get<FriendRequest[]>(`${this.API_URL}/friends/sent`);
  }

  sendFriendRequest(friendUserId: number): Observable<Friend> {
    return this.http.post<Friend>(`${this.API_URL}/friends/send/${friendUserId}`, {});
  }

  acceptFriendRequest(friendId: number): Observable<any> {
    return this.http.post(`${this.API_URL}/friends/${friendId}/accept`, {});
  }

  rejectFriendRequest(friendId: number): Observable<any> {
    return this.http.post(`${this.API_URL}/friends/${friendId}/reject`, {});
  }

  removeFriend(friendUserId: number): Observable<any> {
    return this.http.delete(`${this.API_URL}/friends/${friendUserId}`);
  }

  blockUser(blockedUserId: number): Observable<any> {
    return this.http.post(`${this.API_URL}/friends/block/${blockedUserId}`, {});
  }

  unblockUser(blockedUserId: number): Observable<any> {
    return this.http.delete(`${this.API_URL}/friends/block/${blockedUserId}`);
  }

  getFriendCount(): Observable<{ count: number }> {
    return this.http.get<{ count: number }>(`${this.API_URL}/friends/count`);
  }
}

