import { User } from './user.model';

export interface Report {
  reportId: number;
  reportedUserId: number;
  reportingUserId: number;
  reason: string;
  timeStamp: string;
  status: string;
  reviewedBy?: number;
  reviewedAt?: string;
  adminNotes?: string;
  reportedUser?: User;
  reportingUser?: User;
  reviewer?: User;
}

export interface CreateReportRequest {
  reportedUserId: number;
  reason: string;
}

export interface UpdateReportStatusRequest {
  status: string;
  adminNotes?: string;
}








