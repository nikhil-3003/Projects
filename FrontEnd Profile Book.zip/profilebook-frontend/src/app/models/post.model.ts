import { User } from './user.model';

export interface Post {
  postId: number;
  userId: number;
  content: string;
  postImage?: string;
  status: string;
  createdAt: string;
  approvedAt?: string;
  approvedBy?: number;
  user?: User;
  approver?: User;
  likes: Like[];
  comments: Comment[];
  showComments?: boolean;
}

export interface Like {
  likeId: number;
  postId: number;
  userId: number;
  createdAt: string;
  user?: User;
}

export interface Comment {
  commentId: number;
  postId: number;
  userId: number;
  content: string;
  createdAt: string;
  user?: User;
}

export interface CreatePostRequest {
  content: string;
  postImage?: string;
}

export interface AddCommentRequest {
  content: string;
}



