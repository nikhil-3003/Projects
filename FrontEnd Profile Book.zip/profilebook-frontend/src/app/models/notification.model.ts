export interface Notification {
  notificationId: number;
  userId: number;
  title: string;
  message: string;
  type: string;
  isRead: boolean;
  createdAt: string;
  relatedId?: number;
}

export interface NotificationResponse {
  notifications: Notification[];
  unreadCount: number;
}

