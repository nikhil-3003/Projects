export interface Group {
  groupId: number;
  groupName: string;
  description?: string;
  createdAt: string;
  createdBy: number;
  isActive: boolean;
  creator?: User;
  groupMembers: GroupMember[];
}

export interface GroupMember {
  groupMemberId: number;
  groupId: number;
  userId: number;
  joinedAt: string;
  role: string;
  group?: Group;
  user?: User;
}

export interface User {
  userId: number;
  username: string;
  email: string;
  profileImage?: string;
}

export interface CreateGroupRequest {
  groupName: string;
  description?: string;
}

export interface UpdateGroupRequest {
  groupName: string;
  description?: string;
}








