export interface Friend {
  friendId: number;
  userId: number;
  friendUserId: number;
  status: string;
  createdAt: string;
  updatedAt?: string;
  user?: User;
  friendUser?: User;
}

export interface User {
  userId: number;
  username: string;
  email: string;
  profileImage?: string;
  role: string;
  createdAt: string;
  isActive: boolean;
}

export interface FriendRequest {
  friendId: number;
  user: User;
  friendUser: User;
  status: string;
  createdAt: string;
}

export interface SendFriendRequestRequest {
  friendUserId: number;
}

