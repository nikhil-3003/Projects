export interface Message {
  messageId: number;
  senderId: number;
  receiverId: number;
  messageContent: string;
  timeStamp: string;
  isRead: boolean;
  sender?: User;
  receiver?: User;
}

export interface User {
  userId: number;
  username: string;
  email: string;
  profileImage?: string;
}

export interface SendMessageRequest {
  receiverId: number;
  content: string;
}








