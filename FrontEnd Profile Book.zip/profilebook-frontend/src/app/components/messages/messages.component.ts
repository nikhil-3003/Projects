import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatChipsModule } from '@angular/material/chips';
import { FormsModule } from '@angular/forms';
import { MatTooltipModule } from '@angular/material/tooltip';
import { AuthService } from '../../services/auth.service';
import { ApiService } from '../../services/api.service';
import { User } from '../../models/user.model';
import { Message, SendMessageRequest } from '../../models/message.model';

@Component({
  selector: 'app-messages',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatToolbarModule,
    MatSidenavModule,
    MatListModule,
    MatSnackBarModule,
    MatFormFieldModule,
    MatInputModule,
    MatProgressSpinnerModule,
    MatChipsModule,
    FormsModule,
    MatTooltipModule
  ],
  template: `
    <mat-sidenav-container class="sidenav-container">
      <mat-sidenav #drawer class="sidenav" fixedInViewport
          [attr.role]="'navigation'"
          [mode]="'over'"
          [opened]="false">
        <mat-toolbar>ProfileBook</mat-toolbar>
        <mat-nav-list>
          <a mat-list-item routerLink="/dashboard" routerLinkActive="active">
            <mat-icon matListItemIcon>dashboard</mat-icon>
            <span matListItemTitle>Dashboard</span>
          </a>
          <a mat-list-item routerLink="/posts" routerLinkActive="active">
            <mat-icon matListItemIcon>article</mat-icon>
            <span matListItemTitle>Posts</span>
          </a>
          <a mat-list-item routerLink="/messages" routerLinkActive="active">
            <mat-icon matListItemIcon>message</mat-icon>
            <span matListItemTitle>Messages</span>
          </a>
          <a mat-list-item routerLink="/profile" routerLinkActive="active">
            <mat-icon matListItemIcon>person</mat-icon>
            <span matListItemTitle>Profile</span>
          </a>
        </mat-nav-list>
      </mat-sidenav>
      <mat-sidenav-content>
        <mat-toolbar color="primary">
          <button
            type="button"
            aria-label="Toggle sidenav"
            mat-icon-button
            (click)="drawer.toggle()">
            <mat-icon aria-label="Side nav toggle icon">menu</mat-icon>
          </button>
          <span>Messages</span>
          <span class="spacer"></span>
          <button mat-icon-button (click)="logout()" matTooltip="Logout">
            <mat-icon>logout</mat-icon>
          </button>
        </mat-toolbar>
        
        <div class="content">
          <div class="messages-layout">
            <!-- Users List -->
            <div class="users-panel">
              <h3>Conversations</h3>
              <div *ngIf="isLoadingUsers" class="loading">
                <mat-spinner diameter="30"></mat-spinner>
              </div>
              <div *ngIf="!isLoadingUsers && users.length === 0" class="no-users">
                <p>No conversations yet</p>
              </div>
              <mat-list *ngIf="!isLoadingUsers && users.length > 0">
                <mat-list-item *ngFor="let user of users" 
                               (click)="selectUser(user)"
                               [class.selected]="selectedUser?.userId === user.userId"
                               class="user-item">
                  <div mat-list-avatar class="user-avatar">
                    <img [src]="user.profileImage || '/assets/default-avatar.png'" 
                         [alt]="user.username" 
                         *ngIf="user.profileImage; else defaultAvatar">
                    <ng-template #defaultAvatar>
                      <mat-icon>person</mat-icon>
                    </ng-template>
                  </div>
                  <div mat-line>{{ user.username }}</div>
                  <div mat-line class="last-message">{{ getLastMessage(user) }}</div>
                  <mat-chip *ngIf="getUnreadCount(user) > 0" color="warn" class="unread-count">
                    {{ getUnreadCount(user) }}
                  </mat-chip>
                </mat-list-item>
              </mat-list>
            </div>

            <!-- Messages Panel -->
            <div class="messages-panel">
              <div *ngIf="!selectedUser" class="no-selection">
                <mat-icon>message</mat-icon>
                <h3>Select a conversation</h3>
                <p>Choose a user from the list to start messaging</p>
              </div>

              <div *ngIf="selectedUser" class="conversation">
                <!-- Conversation Header -->
                <div class="conversation-header">
                  <div class="user-info">
                    <div class="user-avatar">
                      <img [src]="selectedUser.profileImage || '/assets/default-avatar.png'" 
                           [alt]="selectedUser.username" 
                           *ngIf="selectedUser.profileImage; else defaultAvatar">
                      <ng-template #defaultAvatar>
                        <mat-icon>person</mat-icon>
                      </ng-template>
                    </div>
                    <div>
                      <h4>{{ selectedUser.username }}</h4>
                      <p>Online</p>
                    </div>
                  </div>
                </div>

                <!-- Messages -->
                <div class="messages-container" #messagesContainer>
                  <div *ngIf="isLoadingMessages" class="loading">
                    <mat-spinner diameter="30"></mat-spinner>
                  </div>
                  <div *ngIf="!isLoadingMessages && messages.length === 0" class="no-messages">
                    <p>No messages yet. Start the conversation!</p>
                  </div>
                  <div *ngFor="let message of messages" 
                       class="message"
                       [class.sent]="message.senderId === currentUser?.userId"
                       [class.received]="message.senderId !== currentUser?.userId">
                    <div class="message-content">
                      <p>{{ message.messageContent }}</p>
                      <span class="message-time">{{ formatTime(message.timeStamp) }}</span>
                    </div>
                  </div>
                </div>

                <!-- Message Input -->
                <div class="message-input">
                  <mat-form-field appearance="outline" class="message-field">
                    <mat-label>Type a message...</mat-label>
                    <input matInput [(ngModel)]="newMessage" 
                           (keyup.enter)="sendMessage()"
                           placeholder="Type your message here">
                  </mat-form-field>
                  <button mat-raised-button color="primary" 
                          (click)="sendMessage()"
                          [disabled]="!newMessage.trim()">
                    <mat-icon>send</mat-icon>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </mat-sidenav-content>
    </mat-sidenav-container>
  `,
  styles: [`
    .sidenav-container {
      height: 100vh;
    }

    .sidenav {
      width: 250px;
    }

    .sidenav .mat-toolbar {
      background: inherit;
    }

    .mat-toolbar.mat-primary {
      position: sticky;
      top: 0;
      z-index: 1;
    }

    .spacer {
      flex: 1 1 auto;
    }

    .content {
      height: calc(100vh - 64px);
      padding: 0;
    }

    .messages-layout {
      display: flex;
      height: 100%;
    }

    .users-panel {
      width: 300px;
      border-right: 1px solid #e0e0e0;
      background-color: #fafafa;
      overflow-y: auto;
    }

    .users-panel h3 {
      padding: 1rem;
      margin: 0;
      background-color: white;
      border-bottom: 1px solid #e0e0e0;
    }

    .user-item {
      cursor: pointer;
      border-bottom: 1px solid #e0e0e0;
    }

    .user-item:hover {
      background-color: #f5f5f5;
    }

    .user-item.selected {
      background-color: #e3f2fd;
    }

    .user-avatar {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      overflow: hidden;
    }

    .user-avatar img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .last-message {
      font-size: 0.8rem;
      color: #666;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .unread-count {
      position: absolute;
      right: 8px;
      top: 8px;
    }

    .messages-panel {
      flex: 1;
      display: flex;
      flex-direction: column;
    }

    .no-selection {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      height: 100%;
      color: #666;
    }

    .no-selection mat-icon {
      font-size: 4rem;
      width: 4rem;
      height: 4rem;
      margin-bottom: 1rem;
    }

    .conversation {
      display: flex;
      flex-direction: column;
      height: 100%;
    }

    .conversation-header {
      padding: 1rem;
      background-color: white;
      border-bottom: 1px solid #e0e0e0;
    }

    .user-info {
      display: flex;
      align-items: center;
      gap: 1rem;
    }

    .user-info .user-avatar {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      overflow: hidden;
    }

    .user-info .user-avatar img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .user-info h4 {
      margin: 0;
      font-size: 1.1rem;
    }

    .user-info p {
      margin: 0;
      color: #666;
      font-size: 0.9rem;
    }

    .messages-container {
      flex: 1;
      padding: 1rem;
      overflow-y: auto;
      background-color: #f5f5f5;
    }

    .message {
      margin-bottom: 1rem;
      display: flex;
    }

    .message.sent {
      justify-content: flex-end;
    }

    .message.received {
      justify-content: flex-start;
    }

    .message-content {
      max-width: 70%;
      padding: 0.75rem 1rem;
      border-radius: 18px;
      position: relative;
    }

    .message.sent .message-content {
      background-color: #1976d2;
      color: white;
    }

    .message.received .message-content {
      background-color: white;
      color: #333;
      border: 1px solid #e0e0e0;
    }

    .message-time {
      font-size: 0.7rem;
      opacity: 0.7;
      display: block;
      margin-top: 0.25rem;
    }

    .message-input {
      padding: 1rem;
      background-color: white;
      border-top: 1px solid #e0e0e0;
      display: flex;
      gap: 1rem;
      align-items: center;
    }

    .message-field {
      flex: 1;
    }

    .loading {
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 2rem;
    }

    .no-users, .no-messages {
      text-align: center;
      padding: 2rem;
      color: #666;
    }

    .active {
      background-color: rgba(25, 118, 210, 0.1);
    }
  `]
})
export class MessagesComponent implements OnInit {
  users: User[] = [];
  messages: Message[] = [];
  selectedUser: User | null = null;
  currentUser: User | null = null;
  isLoadingUsers = true;
  isLoadingMessages = false;
  newMessage = '';

  constructor(
    private authService: AuthService,
    private apiService: ApiService,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
    
    this.loadUsers();
  }

  loadUsers() {
    this.isLoadingUsers = true;
    this.apiService.getUsers().subscribe({
      next: (users) => {
        // Filter out current user
        this.users = users.filter(user => user.userId !== this.currentUser?.userId);
        this.isLoadingUsers = false;
      },
      error: () => {
        this.isLoadingUsers = false;
        this.snackBar.open('Failed to load users', 'Close', { duration: 3000 });
      }
    });
  }

  selectUser(user: User) {
    this.selectedUser = user;
    this.loadMessages();
  }

  loadMessages() {
    if (!this.selectedUser) return;

    this.isLoadingMessages = true;
    this.apiService.getConversation(this.selectedUser.userId).subscribe({
      next: (messages) => {
        this.messages = messages;
        this.isLoadingMessages = false;
        // Mark messages as read
        this.markMessagesAsRead();
      },
      error: () => {
        this.isLoadingMessages = false;
        this.snackBar.open('Failed to load messages', 'Close', { duration: 3000 });
      }
    });
  }

  sendMessage() {
    if (!this.newMessage.trim() || !this.selectedUser) return;

    const messageRequest: SendMessageRequest = {
      receiverId: this.selectedUser.userId,
      content: this.newMessage.trim()
    };

    this.apiService.sendMessage(messageRequest).subscribe({
      next: (message) => {
        this.messages.push(message);
        this.newMessage = '';
        // Scroll to bottom
        setTimeout(() => {
          const container = document.querySelector('.messages-container');
          if (container) {
            container.scrollTop = container.scrollHeight;
          }
        }, 100);
      },
      error: () => {
        this.snackBar.open('Failed to send message', 'Close', { duration: 3000 });
      }
    });
  }

  markMessagesAsRead() {
    this.messages.forEach(message => {
      if (message.receiverId === this.currentUser?.userId && !message.isRead) {
        this.apiService.markAsRead(message.messageId).subscribe();
      }
    });
  }

  getLastMessage(user: User): string {
    // This would need to be implemented based on your data structure
    return 'Last message...';
  }

  getUnreadCount(user: User): number {
    // This would need to be implemented based on your data structure
    return 0;
  }

  formatTime(dateString: string): string {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / 60000);
    
    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    if (minutes < 1440) return `${Math.floor(minutes / 60)}h ago`;
    return date.toLocaleDateString();
  }

  logout() {
    this.authService.logout();
    this.snackBar.open('Logged out successfully', 'Close', { duration: 3000 });
  }
}

