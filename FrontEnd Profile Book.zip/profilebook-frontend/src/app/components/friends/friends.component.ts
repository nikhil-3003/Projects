import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatChipsModule } from '@angular/material/chips';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatTabsModule } from '@angular/material/tabs';
import { MatBadgeModule } from '@angular/material/badge';
import { AuthService } from '../../services/auth.service';
import { ApiService } from '../../services/api.service';
import { Friend, FriendRequest } from '../../models/friend.model';
import { User } from '../../models/user.model';

@Component({
  selector: 'app-friends',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatToolbarModule,
    MatSidenavModule,
    MatListModule,
    MatSnackBarModule,
    MatProgressSpinnerModule,
    MatChipsModule,
    MatTooltipModule,
    MatTabsModule,
    MatBadgeModule
  ],
  template: `
    <mat-sidenav-container class="sidenav-container">
      <mat-sidenav #drawer class="sidenav" fixedInViewport
          [attr.role]="'navigation'"
          [mode]="'over'"
          [opened]="false">
        <mat-toolbar>ProfileBook</mat-toolbar>
        <mat-nav-list>
          <a mat-list-item routerLink="/dashboard" routerLinkActive="active">
            <mat-icon matListItemIcon>dashboard</mat-icon>
            <span matListItemTitle>Dashboard</span>
          </a>
          <a mat-list-item routerLink="/posts" routerLinkActive="active">
            <mat-icon matListItemIcon>article</mat-icon>
            <span matListItemTitle>Posts</span>
          </a>
          <a mat-list-item routerLink="/messages" routerLinkActive="active">
            <mat-icon matListItemIcon>message</mat-icon>
            <span matListItemTitle>Messages</span>
          </a>
          <a mat-list-item routerLink="/profile" routerLinkActive="active">
            <mat-icon matListItemIcon>person</mat-icon>
            <span matListItemTitle>Profile</span>
          </a>
          <a mat-list-item routerLink="/notifications" routerLinkActive="active">
            <mat-icon matListItemIcon>notifications</mat-icon>
            <span matListItemTitle>Notifications</span>
          </a>
          <a mat-list-item routerLink="/search" routerLinkActive="active">
            <mat-icon matListItemIcon>search</mat-icon>
            <span matListItemTitle>Search</span>
          </a>
        </mat-nav-list>
      </mat-sidenav>
      <mat-sidenav-content>
        <mat-toolbar color="primary">
          <button
            type="button"
            aria-label="Toggle sidenav"
            mat-icon-button
            (click)="drawer.toggle()">
            <mat-icon aria-label="Side nav toggle icon">menu</mat-icon>
          </button>
          <span>Friends</span>
          <span class="spacer"></span>
          <button mat-icon-button (click)="logout()" matTooltip="Logout">
            <mat-icon>logout</mat-icon>
          </button>
        </mat-toolbar>
        
        <div class="content">
          <div *ngIf="isLoading" class="loading-container">
            <mat-spinner></mat-spinner>
            <p>Loading friends...</p>
          </div>

          <div *ngIf="!isLoading" class="friends-container">
            <mat-tab-group>
              <!-- Friends Tab -->
              <mat-tab label="Friends">
                <div class="tab-content">
                  <div *ngIf="friends.length === 0" class="no-friends">
                    <mat-icon>people_outline</mat-icon>
                    <h3>No friends yet</h3>
                    <p>Start connecting with people by searching for users!</p>
                    <button mat-raised-button color="primary" routerLink="/search">
                      Find Friends
                    </button>
                  </div>

                  <div *ngIf="friends.length > 0" class="friends-grid">
                    <mat-card *ngFor="let friend of friends" class="friend-card">
                      <mat-card-header>
                        <div mat-card-avatar class="friend-avatar">
                          <img [src]="getFriendUser(friend)?.profileImage || '/assets/default-avatar.png'" 
                               [alt]="getFriendUser(friend)?.username" 
                               *ngIf="getFriendUser(friend)?.profileImage; else defaultAvatar">
                          <ng-template #defaultAvatar>
                            <mat-icon>person</mat-icon>
                          </ng-template>
                        </div>
                        <mat-card-title>{{ getFriendUser(friend)?.username }}</mat-card-title>
                        <mat-card-subtitle>{{ getFriendUser(friend)?.email }}</mat-card-subtitle>
                      </mat-card-header>
                      <mat-card-content>
                        <mat-chip [color]="getFriendUser(friend)?.role === 'Admin' ? 'accent' : 'primary'">
                          {{ getFriendUser(friend)?.role }}
                        </mat-chip>
                        <p class="friend-date">Friends since {{ formatDate(friend.createdAt) }}</p>
                      </mat-card-content>
                      <mat-card-actions>
                        <button mat-button color="primary" (click)="viewFriendProfile(friend)">
                          <mat-icon>visibility</mat-icon>
                          View Profile
                        </button>
                        <button mat-button color="warn" (click)="removeFriend(friend)">
                          <mat-icon>person_remove</mat-icon>
                          Remove
                        </button>
                      </mat-card-actions>
                    </mat-card>
                  </div>
                </div>
              </mat-tab>

              <!-- Pending Requests Tab -->
              <mat-tab label="Pending Requests">
                <div class="tab-content">
                  <div *ngIf="pendingRequests.length === 0" class="no-requests">
                    <mat-icon>person_add_disabled</mat-icon>
                    <h3>No pending requests</h3>
                    <p>You don't have any pending friend requests.</p>
                  </div>

                  <div *ngIf="pendingRequests.length > 0" class="requests-list">
                    <mat-card *ngFor="let request of pendingRequests" class="request-card">
                      <mat-card-header>
                        <div mat-card-avatar class="request-avatar">
                          <img [src]="request.user.profileImage || '/assets/default-avatar.png'" 
                               [alt]="request.user.username" 
                               *ngIf="request.user?.profileImage; else defaultAvatar">
                          <ng-template #defaultAvatar>
                            <mat-icon>person</mat-icon>
                          </ng-template>
                        </div>
                        <mat-card-title>{{ request.user.username }}</mat-card-title>
                        <mat-card-subtitle>{{ request.user.email }}</mat-card-subtitle>
                      </mat-card-header>
                      <mat-card-content>
                        <p>Wants to be your friend</p>
                        <span class="request-date">{{ formatDate(request.createdAt) }}</span>
                      </mat-card-content>
                      <mat-card-actions>
                        <button mat-raised-button color="primary" (click)="acceptRequest(request)">
                          <mat-icon>check</mat-icon>
                          Accept
                        </button>
                        <button mat-button color="warn" (click)="rejectRequest(request)">
                          <mat-icon>close</mat-icon>
                          Reject
                        </button>
                      </mat-card-actions>
                    </mat-card>
                  </div>
                </div>
              </mat-tab>

              <!-- Sent Requests Tab -->
              <mat-tab label="Sent Requests">
                <div class="tab-content">
                  <div *ngIf="sentRequests.length === 0" class="no-requests">
                    <mat-icon>send</mat-icon>
                    <h3>No sent requests</h3>
                    <p>You haven't sent any friend requests yet.</p>
                  </div>

                  <div *ngIf="sentRequests.length > 0" class="requests-list">
                    <mat-card *ngFor="let request of sentRequests" class="request-card">
                      <mat-card-header>
                        <div mat-card-avatar class="request-avatar">
                          <img [src]="request.friendUser.profileImage || '/assets/default-avatar.png'" 
                               [alt]="request.friendUser.username" 
                               *ngIf="request.friendUser?.profileImage; else defaultAvatar">
                          <ng-template #defaultAvatar>
                            <mat-icon>person</mat-icon>
                          </ng-template>
                        </div>
                        <mat-card-title>{{ request.friendUser.username }}</mat-card-title>
                        <mat-card-subtitle>{{ request.friendUser.email }}</mat-card-subtitle>
                      </mat-card-header>
                      <mat-card-content>
                        <p>Friend request sent</p>
                        <span class="request-date">{{ formatDate(request.createdAt) }}</span>
                      </mat-card-content>
                      <mat-card-actions>
                        <button mat-button color="warn" (click)="cancelRequest(request)">
                          <mat-icon>cancel</mat-icon>
                          Cancel
                        </button>
                      </mat-card-actions>
                    </mat-card>
                  </div>
                </div>
              </mat-tab>
            </mat-tab-group>
          </div>
        </div>
      </mat-sidenav-content>
    </mat-sidenav-container>
  `,
  styles: [`
    .sidenav-container {
      height: 100vh;
    }

    .sidenav {
      width: 250px;
    }

    .sidenav .mat-toolbar {
      background: inherit;
    }

    .mat-toolbar.mat-primary {
      position: sticky;
      top: 0;
      z-index: 1;
    }

    .spacer {
      flex: 1 1 auto;
    }

    .content {
      padding: 2rem;
    }

    .loading-container {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 4rem;
    }

    .friends-container {
      max-width: 1000px;
      margin: 0 auto;
    }

    .tab-content {
      padding: 2rem 0;
    }

    .no-friends, .no-requests {
      text-align: center;
      padding: 4rem;
      color: #666;
    }

    .no-friends mat-icon, .no-requests mat-icon {
      font-size: 4rem;
      width: 4rem;
      height: 4rem;
      margin-bottom: 1rem;
      color: #ccc;
    }

    .friends-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
      gap: 1rem;
    }

    .friend-card, .request-card {
      height: 100%;
    }

    .friend-avatar, .request-avatar {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      overflow: hidden;
    }

    .friend-avatar img, .request-avatar img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .friend-date, .request-date {
      font-size: 0.8rem;
      color: #666;
      margin-top: 0.5rem;
    }

    .requests-list {
      max-width: 600px;
      margin: 0 auto;
    }

    .request-card {
      margin-bottom: 1rem;
    }

    .active {
      background-color: rgba(25, 118, 210, 0.1);
    }

    @media (max-width: 768px) {
      .friends-grid {
        grid-template-columns: 1fr;
      }
    }
  `]
})
export class FriendsComponent implements OnInit {
  friends: Friend[] = [];
  pendingRequests: FriendRequest[] = [];
  sentRequests: FriendRequest[] = [];
  isLoading = true;
  currentUser: User | null = null;

  constructor(
    private authService: AuthService,
    private apiService: ApiService,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
    this.loadFriendsData();
  }

  loadFriendsData() {
    this.isLoading = true;
    Promise.all([
      this.apiService.getFriends().toPromise(),
      this.apiService.getPendingRequests().toPromise(),
      this.apiService.getSentRequests().toPromise()
    ]).then(([friends, pending, sent]) => {
      this.friends = friends || [];
      this.pendingRequests = pending || [];
      this.sentRequests = sent || [];
      this.isLoading = false;
    }).catch(() => {
      this.isLoading = false;
      this.snackBar.open('Failed to load friends data', 'Close', { duration: 3000 });
    });
  }

  getFriendUser(friend: Friend): User | undefined {
    return friend.userId === this.currentUser?.userId ? friend.friendUser : friend.user;
  }

  acceptRequest(request: FriendRequest) {
    this.apiService.acceptFriendRequest(request.friendId).subscribe({
      next: () => {
        this.snackBar.open('Friend request accepted', 'Close', { duration: 2000 });
        this.loadFriendsData();
      },
      error: () => {
        this.snackBar.open('Failed to accept friend request', 'Close', { duration: 3000 });
      }
    });
  }

  rejectRequest(request: FriendRequest) {
    this.apiService.rejectFriendRequest(request.friendId).subscribe({
      next: () => {
        this.snackBar.open('Friend request rejected', 'Close', { duration: 2000 });
        this.loadFriendsData();
      },
      error: () => {
        this.snackBar.open('Failed to reject friend request', 'Close', { duration: 3000 });
      }
    });
  }

  cancelRequest(request: FriendRequest) {
    this.apiService.rejectFriendRequest(request.friendId).subscribe({
      next: () => {
        this.snackBar.open('Friend request cancelled', 'Close', { duration: 2000 });
        this.loadFriendsData();
      },
      error: () => {
        this.snackBar.open('Failed to cancel friend request', 'Close', { duration: 3000 });
      }
    });
  }

  removeFriend(friend: Friend) {
    const friendUserId = friend.userId === this.currentUser?.userId ? friend.friendUserId : friend.userId;
    this.apiService.removeFriend(friendUserId).subscribe({
      next: () => {
        this.snackBar.open('Friend removed', 'Close', { duration: 2000 });
        this.loadFriendsData();
      },
      error: () => {
        this.snackBar.open('Failed to remove friend', 'Close', { duration: 3000 });
      }
    });
  }

  viewFriendProfile(friend: Friend) {
    const friendUser = this.getFriendUser(friend);
    this.snackBar.open(`Viewing profile of ${friendUser?.username}`, 'Close', { duration: 2000 });
  }

  formatDate(dateString: string): string {
    return new Date(dateString).toLocaleDateString();
  }

  logout() {
    this.authService.logout();
    this.snackBar.open('Logged out successfully', 'Close', { duration: 3000 });
  }
}

