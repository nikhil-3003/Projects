import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { FormsModule } from '@angular/forms';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatChipsModule } from '@angular/material/chips';
import { AuthService } from '../../services/auth.service';
import { ApiService } from '../../services/api.service';
import { User } from '../../models/user.model';
import { Post, CreatePostRequest } from '../../models/post.model';
import { CreatePostDialogComponent } from './create-post-dialog/create-post-dialog.component';

@Component({
  selector: 'app-posts',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatToolbarModule,
    MatSidenavModule,
    MatListModule,
    MatSnackBarModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatProgressSpinnerModule,
    FormsModule,
    MatTooltipModule,
    MatChipsModule
  ],
  template: `
    <mat-sidenav-container class="sidenav-container">
      <mat-sidenav #drawer class="sidenav" fixedInViewport
          [attr.role]="'navigation'"
          [mode]="'over'"
          [opened]="false">
        <mat-toolbar>ProfileBook</mat-toolbar>
        <mat-nav-list>
          <a mat-list-item routerLink="/dashboard" routerLinkActive="active">
            <mat-icon matListItemIcon>dashboard</mat-icon>
            <span matListItemTitle>Dashboard</span>
          </a>
          <a mat-list-item routerLink="/posts" routerLinkActive="active">
            <mat-icon matListItemIcon>article</mat-icon>
            <span matListItemTitle>Posts</span>
          </a>
          <a mat-list-item routerLink="/messages" routerLinkActive="active">
            <mat-icon matListItemIcon>message</mat-icon>
            <span matListItemTitle>Messages</span>
          </a>
          <a mat-list-item routerLink="/profile" routerLinkActive="active">
            <mat-icon matListItemIcon>person</mat-icon>
            <span matListItemTitle>Profile</span>
          </a>
        </mat-nav-list>
      </mat-sidenav>
      <mat-sidenav-content>
        <mat-toolbar color="primary">
          <button
            type="button"
            aria-label="Toggle sidenav"
            mat-icon-button
            (click)="drawer.toggle()">
            <mat-icon aria-label="Side nav toggle icon">menu</mat-icon>
          </button>
          <span>Posts</span>
          <span class="spacer"></span>
          <button mat-raised-button color="accent" (click)="openCreatePostDialog()">
            <mat-icon>add</mat-icon>
            Create Post
          </button>
          <button mat-icon-button (click)="logout()" matTooltip="Logout">
            <mat-icon>logout</mat-icon>
          </button>
        </mat-toolbar>
        
        <div class="content">
          <div *ngIf="isLoading" class="loading-container">
            <mat-spinner></mat-spinner>
            <p>Loading posts...</p>
          </div>

          <div *ngIf="!isLoading && posts.length === 0" class="no-posts">
            <mat-icon>article</mat-icon>
            <h3>No posts available</h3>
            <p>Be the first to create a post!</p>
            <button mat-raised-button color="primary" (click)="openCreatePostDialog()">
              Create Post
            </button>
          </div>

          <div *ngIf="!isLoading && posts.length > 0" class="posts-container">
            <mat-card *ngFor="let post of posts" class="post-card">
              <mat-card-header>
                <div mat-card-avatar class="post-avatar">
                  <img [src]="post.user?.profileImage || '/assets/default-avatar.png'" 
                       [alt]="post.user?.username" 
                       *ngIf="post.user?.profileImage; else defaultAvatar">
                  <ng-template #defaultAvatar>
                    <mat-icon>person</mat-icon>
                  </ng-template>
                </div>
                <mat-card-title>{{ post.user?.username }}</mat-card-title>
                <mat-card-subtitle>{{ formatDate(post.createdAt) }}</mat-card-subtitle>
                <div class="post-badges">
                  <span class="post-status" [ngClass]="post.status.toLowerCase()">
                    {{ post.status }}
                  </span>
                  <mat-chip *ngIf="isFromFriend(post)" color="accent" class="friend-badge">
                    <mat-icon>people</mat-icon>
                    Friend
                  </mat-chip>
                </div>
              </mat-card-header>
              
              <mat-card-content>
                <p class="post-content">{{ post.content }}</p>
                <img *ngIf="post.postImage" [src]="post.postImage" [alt]="'Post image'" class="post-image">
              </mat-card-content>
              
              <mat-card-actions>
                <button mat-icon-button (click)="toggleLike(post)" 
                        [color]="isLiked(post) ? 'warn' : ''">
                  <mat-icon>{{ isLiked(post) ? 'favorite' : 'favorite_border' }}</mat-icon>
                  <span>{{ post.likes.length || 0 }}</span>
                </button>
                
                <button mat-icon-button (click)="toggleComments(post)">
                  <mat-icon>comment</mat-icon>
                  <span>{{ post.comments.length || 0 }}</span>
                </button>
                
                <button mat-icon-button (click)="reportPost(post)" *ngIf="post.user?.userId !== currentUser?.userId">
                  <mat-icon>report</mat-icon>
                </button>
              </mat-card-actions>

              <div *ngIf="post.showComments" class="comments-section">
                <div *ngFor="let comment of post.comments" class="comment">
                  <div class="comment-header">
                    <strong>{{ comment.user?.username }}</strong>
                    <span class="comment-date">{{ formatDate(comment.createdAt) }}</span>
                  </div>
                  <p>{{ comment.content }}</p>
                </div>
                
                <div class="add-comment">
                  <mat-form-field appearance="outline" class="comment-input">
                    <mat-label>Add a comment...</mat-label>
                    <input matInput [(ngModel)]="newComment" placeholder="Write a comment">
                  </mat-form-field>
                  <button mat-raised-button color="primary" (click)="addComment(post)">
                    Post
                  </button>
                </div>
              </div>
            </mat-card>
          </div>
        </div>
      </mat-sidenav-content>
    </mat-sidenav-container>
  `,
  styles: [`
    .sidenav-container {
      height: 100vh;
    }

    .sidenav {
      width: 250px;
    }

    .sidenav .mat-toolbar {
      background: inherit;
    }

    .mat-toolbar.mat-primary {
      position: sticky;
      top: 0;
      z-index: 1;
    }

    .spacer {
      flex: 1 1 auto;
    }

    .content {
      padding: 2rem;
    }

    .loading-container {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 4rem;
    }

    .no-posts {
      text-align: center;
      padding: 4rem;
    }

    .no-posts mat-icon {
      font-size: 4rem;
      width: 4rem;
      height: 4rem;
      color: #ccc;
    }

    .posts-container {
      max-width: 800px;
      margin: 0 auto;
    }

    .post-card {
      margin-bottom: 2rem;
    }

    .post-avatar {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      overflow: hidden;
    }

    .post-avatar img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .post-badges {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      margin-left: auto;
    }

    .post-status {
      padding: 4px 8px;
      border-radius: 12px;
      font-size: 0.75rem;
      font-weight: 500;
    }

    .friend-badge {
      font-size: 0.7rem;
    }

    .post-status.approved {
      background-color: #e8f5e8;
      color: #2e7d32;
    }

    .post-status.pending {
      background-color: #fff3e0;
      color: #f57c00;
    }

    .post-status.rejected {
      background-color: #ffebee;
      color: #c62828;
    }

    .post-content {
      font-size: 1.1rem;
      line-height: 1.5;
      margin: 1rem 0;
    }

    .post-image {
      width: 100%;
      max-height: 400px;
      object-fit: cover;
      border-radius: 8px;
      margin-top: 1rem;
    }

    .comments-section {
      border-top: 1px solid #eee;
      padding-top: 1rem;
      margin-top: 1rem;
    }

    .comment {
      margin-bottom: 1rem;
      padding: 0.5rem;
      background-color: #f5f5f5;
      border-radius: 8px;
    }

    .comment-header {
      display: flex;
      justify-content: space-between;
      margin-bottom: 0.5rem;
    }

    .comment-date {
      font-size: 0.8rem;
      color: #666;
    }

    .add-comment {
      display: flex;
      gap: 1rem;
      align-items: center;
      margin-top: 1rem;
    }

    .comment-input {
      flex: 1;
    }

    .active {
      background-color: rgba(25, 118, 210, 0.1);
    }
  `]
})
export class PostsComponent implements OnInit {
  posts: Post[] = [];
  currentUser: User | null = null;
  isLoading = true;
  newComment = '';

  constructor(
    private authService: AuthService,
    private apiService: ApiService,
    private snackBar: MatSnackBar,
    private dialog: MatDialog
  ) {}

  ngOnInit() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
    
    this.loadPosts();
  }

  loadPosts() {
    this.isLoading = true;
    // Load posts and friends data in parallel for personalized feed
    Promise.all([
      this.apiService.getApprovedPosts().toPromise(),
      this.apiService.getFriends().toPromise()
    ]).then(([posts, friends]) => {
      const personalizedPosts = this.personalizeFeed(posts || [], friends || []);
      this.posts = personalizedPosts.map(post => ({ ...post, showComments: false }));
      this.isLoading = false;
    }).catch(() => {
      this.isLoading = false;
      this.snackBar.open('Failed to load posts', 'Close', { duration: 3000 });
    });
  }

  personalizeFeed(posts: Post[], friends: any[]): Post[] {
    if (!this.currentUser) return posts;

    const friendIds = friends.map(f => 
      f.userId === this.currentUser?.userId ? f.friendUserId : f.userId
    );

    // Separate posts into friends' posts and others
    const friendsPosts = posts.filter(post => friendIds.includes(post.userId));
    const otherPosts = posts.filter(post => !friendIds.includes(post.userId) && post.userId !== this.currentUser?.userId);

    // Sort friends' posts by engagement (likes + comments) and recency
    const sortedFriendsPosts = friendsPosts.sort((a, b) => {
      const aEngagement = (a.likes?.length || 0) + (a.comments?.length || 0);
      const bEngagement = (b.likes?.length || 0) + (b.comments?.length || 0);
      
      if (aEngagement !== bEngagement) {
        return bEngagement - aEngagement; // Higher engagement first
      }
      
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(); // Newer first
    });

    // Sort other posts by recency
    const sortedOtherPosts = otherPosts.sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );

    // Combine: friends' posts first, then other posts
    return [...sortedFriendsPosts, ...sortedOtherPosts];
  }

  openCreatePostDialog() {
    const dialogRef = this.dialog.open(CreatePostDialogComponent, {
      width: '500px'
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.loadPosts();
      }
    });
  }

  toggleLike(post: Post) {
    if (this.isLiked(post)) {
      this.apiService.unlikePost(post.postId).subscribe({
        next: () => {
          post.likes = post.likes?.filter(like => like.userId !== this.currentUser?.userId) || [];
        },
        error: () => {
          this.snackBar.open('Failed to unlike post', 'Close', { duration: 3000 });
        }
      });
    } else {
      this.apiService.likePost(post.postId).subscribe({
        next: () => {
          if (!post.likes) post.likes = [];
          post.likes.push({
            likeId: 0,
            postId: post.postId,
            userId: this.currentUser?.userId || 0,
            createdAt: new Date().toISOString(),
            user: this.currentUser || undefined
          });
        },
        error: () => {
          this.snackBar.open('Failed to like post', 'Close', { duration: 3000 });
        }
      });
    }
  }

  isLiked(post: Post): boolean {
    return post.likes?.some(like => like.userId === this.currentUser?.userId) || false;
  }

  toggleComments(post: Post) {
    post.showComments = !post.showComments;
    if (post.showComments && (!post.comments || post.comments.length === 0)) {
      this.loadComments(post);
    }
  }

  loadComments(post: Post) {
    this.apiService.getPostComments(post.postId).subscribe({
      next: (comments) => {
        post.comments = comments;
      },
      error: () => {
        this.snackBar.open('Failed to load comments', 'Close', { duration: 3000 });
      }
    });
  }

  addComment(post: Post) {
    if (!this.newComment.trim()) return;

    this.apiService.addComment(post.postId, { content: this.newComment }).subscribe({
      next: (comment) => {
        if (!post.comments) post.comments = [];
        post.comments.push(comment);
        this.newComment = '';
      },
      error: () => {
        this.snackBar.open('Failed to add comment', 'Close', { duration: 3000 });
      }
    });
  }

  reportPost(post: Post) {
    // Implement report functionality
    this.snackBar.open('Report functionality coming soon', 'Close', { duration: 3000 });
  }

  isFromFriend(post: Post): boolean {
    if (!this.currentUser) return false;
    // This would need to be implemented based on your friends data structure
    // For now, we'll return false as a placeholder
    return false;
  }

  formatDate(dateString: string): string {
    return new Date(dateString).toLocaleDateString();
  }

  logout() {
    this.authService.logout();
    this.snackBar.open('Logged out successfully', 'Close', { duration: 3000 });
  }
}

