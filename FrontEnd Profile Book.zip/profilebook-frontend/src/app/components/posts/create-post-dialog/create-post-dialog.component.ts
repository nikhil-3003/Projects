import { Component, Inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { ApiService } from '../../../services/api.service';

@Component({
  selector: 'app-create-post-dialog',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    MatSnackBarModule,
    MatTooltipModule
  ],
  template: `
    <h2 mat-dialog-title>Create New Post</h2>
    
    <mat-dialog-content>
      <form [formGroup]="postForm">
        <mat-form-field appearance="outline" class="full-width">
          <mat-label>What's on your mind?</mat-label>
          <textarea matInput formControlName="content" rows="4" 
                    placeholder="Share your thoughts..."></textarea>
          <mat-error *ngIf="postForm.get('content')?.hasError('required')">
            Content is required
          </mat-error>
        </mat-form-field>

        <div class="image-upload">
          <input type="file" #fileInput (change)="onFileSelected($event)" 
                 accept="image/*" style="display: none;">
          <button mat-raised-button type="button" (click)="fileInput.click()">
            <mat-icon>add_photo_alternate</mat-icon>
            Add Image
          </button>
          <span *ngIf="selectedFile" class="file-name">{{ selectedFile.name }}</span>
        </div>

        <div *ngIf="previewImage" class="image-preview">
          <img [src]="previewImage" [alt]="'Preview'" class="preview-img">
          <button mat-icon-button (click)="removeImage()" class="remove-btn">
            <mat-icon>close</mat-icon>
          </button>
        </div>
      </form>
    </mat-dialog-content>

    <mat-dialog-actions align="end">
      <button mat-button (click)="onCancel()">Cancel</button>
      <button mat-raised-button color="primary" 
              [disabled]="postForm.invalid || isSubmitting"
              (click)="onSubmit()">
        {{ isSubmitting ? 'Creating...' : 'Create Post' }}
      </button>
    </mat-dialog-actions>
  `,
  styles: [`
    .full-width {
      width: 100%;
      margin-bottom: 1rem;
    }

    .image-upload {
      margin-bottom: 1rem;
    }

    .file-name {
      margin-left: 1rem;
      color: #666;
    }

    .image-preview {
      position: relative;
      display: inline-block;
      margin-bottom: 1rem;
    }

    .preview-img {
      max-width: 200px;
      max-height: 200px;
      border-radius: 8px;
      border: 1px solid #ddd;
    }

    .remove-btn {
      position: absolute;
      top: -10px;
      right: -10px;
      background-color: #f44336;
      color: white;
    }

    mat-dialog-content {
      min-width: 400px;
    }
  `]
})
export class CreatePostDialogComponent {
  postForm: FormGroup;
  selectedFile: File | null = null;
  previewImage: string | null = null;
  isSubmitting = false;

  constructor(
    private fb: FormBuilder,
    private apiService: ApiService,
    private snackBar: MatSnackBar,
    private dialogRef: MatDialogRef<CreatePostDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.postForm = this.fb.group({
      content: ['', Validators.required]
    });
  }

  onFileSelected(event: any) {
    const file = event.target.files[0];
    if (file) {
      this.selectedFile = file;
      
      // Create preview
      const reader = new FileReader();
      reader.onload = (e) => {
        this.previewImage = e.target?.result as string;
      };
      reader.readAsDataURL(file);
    }
  }

  removeImage() {
    this.selectedFile = null;
    this.previewImage = null;
  }

  onSubmit() {
    if (this.postForm.valid) {
      this.isSubmitting = true;
      
      const postData: any = {
        content: this.postForm.value.content
      };

      if (this.selectedFile) {
        // Upload image first
        this.apiService.uploadPostImage(this.selectedFile).subscribe({
          next: (response) => {
            postData.postImage = response.filePath;
            this.createPost(postData);
          },
          error: () => {
            this.isSubmitting = false;
            this.snackBar.open('Failed to upload image', 'Close', { duration: 3000 });
          }
        });
      } else {
        this.createPost(postData);
      }
    }
  }

  private createPost(postData: any) {
    this.apiService.createPost(postData).subscribe({
      next: () => {
        this.isSubmitting = false;
        this.snackBar.open('Post created successfully! It will be reviewed by admin.', 'Close', { duration: 5000 });
        this.dialogRef.close(true);
      },
      error: () => {
        this.isSubmitting = false;
        this.snackBar.open('Failed to create post', 'Close', { duration: 3000 });
      }
    });
  }

  onCancel() {
    this.dialogRef.close(false);
  }
}

