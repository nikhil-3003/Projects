import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { AuthService } from '../../../services/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatSelectModule,
    MatSnackBarModule,
    MatTooltipModule,
    MatIconModule,
    MatProgressSpinnerModule,
    MatCheckboxModule
  ],
  template: `
    <div class="register-container">
      <!-- Background Elements -->
      <div class="background-elements">
        <div class="floating-shape shape-1"></div>
        <div class="floating-shape shape-2"></div>
        <div class="floating-shape shape-3"></div>
        <div class="floating-shape shape-4"></div>
      </div>

      <!-- Main Content -->
      <div class="register-content">
        <!-- Left Side - Branding -->
        <div class="branding-section">
          <div class="branding-content">
            <div class="logo-container">
              <mat-icon class="brand-logo">person_add</mat-icon>
              <h1 class="brand-title">Join ProfileBook</h1>
            </div>
            <h2 class="brand-subtitle">Start your journey today</h2>
            <p class="brand-description">
              Create your account and become part of our growing community. 
              Share your stories, connect with friends, and discover amazing content.
            </p>
            <div class="benefits-list">
              <div class="benefit-item">
                <mat-icon class="benefit-icon">verified_user</mat-icon>
                <span>Secure & Private</span>
              </div>
              <div class="benefit-item">
                <mat-icon class="benefit-icon">speed</mat-icon>
                <span>Fast & Easy Setup</span>
              </div>
              <div class="benefit-item">
                <mat-icon class="benefit-icon">support_agent</mat-icon>
                <span>24/7 Support</span>
              </div>
            </div>
          </div>
        </div>

        <!-- Right Side - Registration Form -->
        <div class="form-section">
          <mat-card class="register-card">
            <mat-card-header class="card-header">
              <div class="header-content">
                <mat-icon class="header-icon">person_add</mat-icon>
                <mat-card-title class="card-title">Create Account</mat-card-title>
                <mat-card-subtitle class="card-subtitle">Join our community today</mat-card-subtitle>
              </div>
            </mat-card-header>
            
            <mat-card-content class="card-content">
              <form [formGroup]="registerForm" (ngSubmit)="onSubmit()" class="register-form">
                <div class="form-row">
                  <mat-form-field appearance="outline" class="form-field">
                    <mat-label>Username</mat-label>
                    <input matInput 
                           formControlName="username" 
                           required
                           placeholder="Choose a username">
                    <mat-icon matSuffix>person</mat-icon>
                    <mat-error *ngIf="registerForm.get('username')?.hasError('required')">
                      Username is required
                    </mat-error>
                  </mat-form-field>

                  <mat-form-field appearance="outline" class="form-field">
                    <mat-label>Email</mat-label>
                    <input matInput 
                           type="email" 
                           formControlName="email" 
                           required
                           placeholder="Enter your email">
                    <mat-icon matSuffix>email</mat-icon>
                    <mat-error *ngIf="registerForm.get('email')?.hasError('required')">
                      Email is required
                    </mat-error>
                    <mat-error *ngIf="registerForm.get('email')?.hasError('email')">
                      Please enter a valid email
                    </mat-error>
                  </mat-form-field>
                </div>

                <div class="form-row">
                  <mat-form-field appearance="outline" class="form-field">
                    <mat-label>Password</mat-label>
                    <input matInput 
                           type="password" 
                           formControlName="password" 
                           required
                           placeholder="Create a password">
                    <mat-icon matSuffix>lock</mat-icon>
                    <mat-error *ngIf="registerForm.get('password')?.hasError('required')">
                      Password is required
                    </mat-error>
                    <mat-error *ngIf="registerForm.get('password')?.hasError('minlength')">
                      Password must be at least 6 characters
                    </mat-error>
                  </mat-form-field>

                  <mat-form-field appearance="outline" class="form-field">
                    <mat-label>Role</mat-label>
                    <mat-select formControlName="role">
                      <mat-option value="User">
                        <mat-icon class="role-icon">person</mat-icon>
                        User
                      </mat-option>
                      <mat-option value="Admin">
                        <mat-icon class="role-icon">admin_panel_settings</mat-icon>
                        Admin
                      </mat-option>
                    </mat-select>
                    <mat-icon matSuffix>work</mat-icon>
                  </mat-form-field>
                </div>

                <div class="form-options">
                  <mat-checkbox class="terms-checkbox">
                    I agree to the 
                    <a href="#" class="terms-link">Terms of Service</a> 
                    and 
                    <a href="#" class="terms-link">Privacy Policy</a>
                  </mat-checkbox>
                </div>

                <button mat-raised-button 
                        color="primary" 
                        type="submit" 
                        [disabled]="registerForm.invalid || isLoading" 
                        class="register-button">
                  <mat-spinner *ngIf="isLoading" diameter="20" class="button-spinner"></mat-spinner>
                  <mat-icon *ngIf="!isLoading" class="button-icon">person_add</mat-icon>
                  {{ isLoading ? 'Creating Account...' : 'Create Account' }}
                </button>
              </form>
            </mat-card-content>
            
            <mat-card-actions class="card-actions">
              <div class="divider">
                <span class="divider-text">or</span>
              </div>
              <p class="login-link">
                Already have an account? 
                <a routerLink="/login" class="login-anchor">
                  <mat-icon class="anchor-icon">login</mat-icon>
                  Sign in here
                </a>
              </p>
            </mat-card-actions>
          </mat-card>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .register-container {
      min-height: 100vh;
      background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
      position: relative;
      overflow: hidden;
    }

    .background-elements {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 1;
    }

    .floating-shape {
      position: absolute;
      border-radius: 50%;
      background: rgba(255, 255, 255, 0.1);
      animation: float 8s ease-in-out infinite;
    }

    .shape-1 {
      width: 100px;
      height: 100px;
      top: 15%;
      left: 15%;
      animation-delay: 0s;
    }

    .shape-2 {
      width: 60px;
      height: 60px;
      top: 40%;
      right: 20%;
      animation-delay: 2s;
    }

    .shape-3 {
      width: 80px;
      height: 80px;
      bottom: 30%;
      left: 25%;
      animation-delay: 4s;
    }

    .shape-4 {
      width: 120px;
      height: 120px;
      bottom: 10%;
      right: 10%;
      animation-delay: 6s;
    }

    @keyframes float {
      0%, 100% { transform: translateY(0px) rotate(0deg); }
      50% { transform: translateY(-25px) rotate(180deg); }
    }

    .register-content {
      display: flex;
      min-height: 100vh;
      position: relative;
      z-index: 2;
    }

    .branding-section {
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 2rem;
      background: rgba(255, 255, 255, 0.1);
      backdrop-filter: blur(10px);
    }

    .branding-content {
      max-width: 500px;
      text-align: center;
      color: white;
    }

    .logo-container {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 1rem;
      margin-bottom: 2rem;
    }

    .brand-logo {
      font-size: 4rem;
      width: 4rem;
      height: 4rem;
    }

    .brand-title {
      font-size: 3rem;
      font-weight: 700;
      margin: 0;
      text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
    }

    .brand-subtitle {
      font-size: 1.5rem;
      font-weight: 300;
      margin-bottom: 1.5rem;
      opacity: 0.9;
    }

    .brand-description {
      font-size: 1.1rem;
      line-height: 1.6;
      margin-bottom: 2rem;
      opacity: 0.8;
    }

    .benefits-list {
      display: flex;
      flex-direction: column;
      gap: 1rem;
    }

    .benefit-item {
      display: flex;
      align-items: center;
      gap: 1rem;
      font-size: 1rem;
    }

    .benefit-icon {
      font-size: 1.5rem;
      width: 1.5rem;
      height: 1.5rem;
    }

    .form-section {
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 2rem;
    }

    .register-card {
      width: 100%;
      max-width: 500px;
      border-radius: 20px;
      box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
      backdrop-filter: blur(10px);
      background: rgba(255, 255, 255, 0.95);
    }

    .card-header {
      text-align: center;
      padding: 2rem 2rem 1rem 2rem;
    }

    .header-content {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 0.5rem;
    }

    .header-icon {
      font-size: 3rem;
      width: 3rem;
      height: 3rem;
      color: #764ba2;
    }

    .card-title {
      font-size: 2rem;
      font-weight: 600;
      margin: 0;
      color: #333;
    }

    .card-subtitle {
      font-size: 1rem;
      color: #666;
      margin: 0;
    }

    .card-content {
      padding: 0 2rem 1rem 2rem;
    }

    .register-form {
      display: flex;
      flex-direction: column;
      gap: 1.5rem;
    }

    .form-row {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 1rem;
    }

    .form-field {
      width: 100%;
    }

    .form-field .mat-mdc-form-field {
      width: 100%;
    }

    .role-icon {
      font-size: 1rem;
      width: 1rem;
      height: 1rem;
      margin-right: 0.5rem;
    }

    .form-options {
      margin: 0.5rem 0;
    }

    .terms-checkbox {
      font-size: 0.9rem;
      line-height: 1.4;
    }

    .terms-link {
      color: #764ba2;
      text-decoration: none;
      font-weight: 500;
    }

    .terms-link:hover {
      text-decoration: underline;
    }

    .register-button {
      height: 50px;
      font-size: 1.1rem;
      font-weight: 600;
      border-radius: 25px;
      margin-top: 1rem;
      position: relative;
      overflow: hidden;
    }

    .button-spinner {
      margin-right: 0.5rem;
    }

    .button-icon {
      margin-right: 0.5rem;
    }

    .card-actions {
      padding: 1rem 2rem 2rem 2rem;
      text-align: center;
    }

    .divider {
      position: relative;
      margin: 1rem 0;
    }

    .divider::before {
      content: '';
      position: absolute;
      top: 50%;
      left: 0;
      right: 0;
      height: 1px;
      background: #e0e0e0;
    }

    .divider-text {
      background: rgba(255, 255, 255, 0.95);
      padding: 0 1rem;
      color: #666;
      font-size: 0.9rem;
    }

    .login-link {
      margin: 0;
      color: #666;
      font-size: 0.95rem;
    }

    .login-anchor {
      color: #764ba2;
      text-decoration: none;
      font-weight: 600;
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
      margin-left: 0.5rem;
    }

    .login-anchor:hover {
      text-decoration: underline;
    }

    .anchor-icon {
      font-size: 1rem;
      width: 1rem;
      height: 1rem;
    }

    /* Responsive Design */
    @media (max-width: 1024px) {
      .branding-section {
        padding: 1.5rem;
      }

      .brand-title {
        font-size: 2.5rem;
      }

      .brand-subtitle {
        font-size: 1.3rem;
      }

      .brand-description {
        font-size: 1rem;
      }
    }

    @media (max-width: 768px) {
      .register-content {
        flex-direction: column;
      }

      .branding-section {
        padding: 1rem;
        min-height: 40vh;
      }

      .branding-content {
        max-width: 100%;
      }

      .brand-title {
        font-size: 2rem;
      }

      .brand-subtitle {
        font-size: 1.2rem;
      }

      .brand-description {
        font-size: 0.95rem;
        margin-bottom: 1rem;
      }

      .benefits-list {
        display: none;
      }

      .form-section {
        padding: 1rem;
        min-height: 60vh;
      }

      .register-card {
        max-width: 100%;
        border-radius: 15px;
      }

      .card-header {
        padding: 1.5rem 1.5rem 0.5rem 1.5rem;
      }

      .card-content {
        padding: 0 1.5rem 0.5rem 1.5rem;
      }

      .card-actions {
        padding: 0.5rem 1.5rem 1.5rem 1.5rem;
      }

      .header-icon {
        font-size: 2.5rem;
        width: 2.5rem;
        height: 2.5rem;
      }

      .card-title {
        font-size: 1.5rem;
      }

      .form-row {
        grid-template-columns: 1fr;
        gap: 0.5rem;
      }
    }

    @media (max-width: 480px) {
      .branding-section {
        min-height: 35vh;
        padding: 0.5rem;
      }

      .brand-title {
        font-size: 1.8rem;
      }

      .brand-subtitle {
        font-size: 1.1rem;
      }

      .brand-description {
        font-size: 0.9rem;
      }

      .form-section {
        padding: 0.5rem;
        min-height: 65vh;
      }

      .register-card {
        border-radius: 10px;
      }

      .card-header {
        padding: 1rem 1rem 0.5rem 1rem;
      }

      .card-content {
        padding: 0 1rem 0.5rem 1rem;
      }

      .card-actions {
        padding: 0.5rem 1rem 1rem 1rem;
      }

      .register-form {
        gap: 1rem;
      }

      .register-button {
        height: 45px;
        font-size: 1rem;
      }

      .form-row {
        gap: 0.25rem;
      }
    }
  `]
})
export class RegisterComponent {
  registerForm: FormGroup;
  isLoading = false;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router,
    private snackBar: MatSnackBar
  ) {
    this.registerForm = this.fb.group({
      username: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      role: ['User']
    });
  }

  onSubmit() {
    if (this.registerForm.valid) {
      this.isLoading = true;
      const userData = this.registerForm.value;

      this.authService.register(userData).subscribe({
        next: (response) => {
          this.isLoading = false;
          this.snackBar.open('Registration successful!', 'Close', { duration: 3000 });
          
          // Redirect based on user role
          if (response.user.role === 'Admin') {
            this.router.navigate(['/admin']);
          } else {
            this.router.navigate(['/dashboard']);
          }
        },
        error: (error) => {
          this.isLoading = false;
          this.snackBar.open('Registration failed. Username or email may already exist.', 'Close', { duration: 5000 });
        }
      });
    }
  }
}

