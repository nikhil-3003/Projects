import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatBadgeModule } from '@angular/material/badge';
import { MatMenuModule } from '@angular/material/menu';
import { AuthService } from '../../services/auth.service';
import { ApiService } from '../../services/api.service';
import { User } from '../../models/user.model';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatToolbarModule,
    MatSidenavModule,
    MatListModule,
    MatSnackBarModule,
    MatTooltipModule,
    MatBadgeModule,
    MatMenuModule
  ],
  template: `
    <mat-sidenav-container class="sidenav-container">
      <mat-sidenav #drawer class="sidenav" fixedInViewport
          [attr.role]="'navigation'"
          [mode]="'over'"
          [opened]="false">
        <mat-toolbar class="sidenav-toolbar">
          <mat-icon class="logo-icon">account_circle</mat-icon>
          <span class="logo-text">ProfileBook</span>
        </mat-toolbar>
        <mat-nav-list class="nav-list">
          <!-- Main Navigation -->
          <div class="nav-section">
            <div class="nav-section-title">Main</div>
            <a mat-list-item routerLink="/dashboard" routerLinkActive="active">
              <mat-icon matListItemIcon>dashboard</mat-icon>
              <span matListItemTitle>Dashboard</span>
            </a>
            <a mat-list-item routerLink="/posts" routerLinkActive="active">
              <mat-icon matListItemIcon>article</mat-icon>
              <span matListItemTitle>Posts</span>
            </a>
            <a mat-list-item routerLink="/messages" routerLinkActive="active">
              <mat-icon matListItemIcon>chat</mat-icon>
              <span matListItemTitle>Messages</span>
            </a>
          </div>

          <!-- Social Features -->
          <div class="nav-section">
            <div class="nav-section-title">Social</div>
            <a mat-list-item routerLink="/friends" routerLinkActive="active">
              <mat-icon matListItemIcon>group</mat-icon>
              <span matListItemTitle>Friends</span>
            </a>
            <a mat-list-item routerLink="/search" routerLinkActive="active">
              <mat-icon matListItemIcon>search</mat-icon>
              <span matListItemTitle>Discover</span>
            </a>
          </div>

          <!-- Personal -->
          <div class="nav-section">
            <div class="nav-section-title">Personal</div>
            <a mat-list-item routerLink="/profile" routerLinkActive="active">
              <mat-icon matListItemIcon>person</mat-icon>
              <span matListItemTitle>My Profile</span>
            </a>
            <a mat-list-item routerLink="/notifications" routerLinkActive="active">
              <mat-icon matListItemIcon>notifications</mat-icon>
              <span matListItemTitle>Notifications</span>
              <mat-icon matListItemMeta *ngIf="unreadCount > 0" class="notification-badge">{{ unreadCount }}</mat-icon>
            </a>
          </div>

          <!-- Admin Section -->
          <div class="nav-section" *ngIf="currentUser?.role === 'Admin'">
            <div class="nav-section-title">Administration</div>
            <a mat-list-item routerLink="/admin" routerLinkActive="active">
              <mat-icon matListItemIcon>admin_panel_settings</mat-icon>
              <span matListItemTitle>Admin Panel</span>
            </a>
          </div>
        </mat-nav-list>
      </mat-sidenav>
      
      <mat-sidenav-content>
        <mat-toolbar color="primary" class="main-toolbar">
          <button
            type="button"
            aria-label="Toggle sidenav"
            mat-icon-button
            (click)="drawer.toggle()"
            class="menu-button">
            <mat-icon>menu</mat-icon>
          </button>
          
          <div class="toolbar-title">
            <mat-icon class="title-icon">account_circle</mat-icon>
            <span class="title-text">ProfileBook</span>
          </div>
          
          <span class="spacer"></span>
          
          <div class="toolbar-actions">
            <button mat-icon-button 
                    [matBadge]="unreadCount" 
                    [matBadgeHidden]="unreadCount === 0" 
                    matBadgeColor="warn" 
                    routerLink="/notifications" 
                    matTooltip="Notifications"
                    class="notification-button">
              <mat-icon>notifications</mat-icon>
            </button>
            
            <div class="user-info">
              <mat-icon class="user-icon">person</mat-icon>
              <span class="username">{{ currentUser?.username }}</span>
            </div>
            
            <button mat-icon-button 
                    (click)="logout()" 
                    matTooltip="Logout"
                    class="logout-button">
              <mat-icon>logout</mat-icon>
            </button>
          </div>
        </mat-toolbar>
        
        <div class="content">
          <!-- Welcome Section -->
          <div class="welcome-section">
            <div class="welcome-content">
              <h1 class="welcome-title">
                <mat-icon class="welcome-icon">waving_hand</mat-icon>
                Welcome back, {{ currentUser?.username }}!
              </h1>
              <p class="welcome-subtitle">Stay connected with your friends and discover amazing content</p>
            </div>
          </div>

          <!-- Quick Actions Grid -->
          <div class="quick-actions">
            <mat-card class="action-card primary-card" routerLink="/posts">
              <div class="card-icon">
                <mat-icon>article</mat-icon>
              </div>
              <mat-card-header>
                <mat-card-title>Latest Posts</mat-card-title>
                <mat-card-subtitle>Discover & Share</mat-card-subtitle>
              </mat-card-header>
              <mat-card-content>
                <p>See what your friends are sharing and discover new content from the community.</p>
              </mat-card-content>
              <mat-card-actions>
                <button mat-raised-button color="primary" class="action-button">
                  <mat-icon>visibility</mat-icon>
                  View Posts
                </button>
              </mat-card-actions>
            </mat-card>

            <mat-card class="action-card accent-card" routerLink="/messages">
              <div class="card-icon">
                <mat-icon>chat</mat-icon>
              </div>
              <mat-card-header>
                <mat-card-title>Messages</mat-card-title>
                <mat-card-subtitle>Stay Connected</mat-card-subtitle>
              </mat-card-header>
              <mat-card-content>
                <p>Chat with your friends and stay connected with real-time messaging.</p>
              </mat-card-content>
              <mat-card-actions>
                <button mat-raised-button color="accent" class="action-button">
                  <mat-icon>chat</mat-icon>
                  Open Messages
                </button>
              </mat-card-actions>
            </mat-card>

            <mat-card class="action-card warn-card" routerLink="/friends">
              <div class="card-icon">
                <mat-icon>group</mat-icon>
              </div>
              <mat-card-header>
                <mat-card-title>Friends</mat-card-title>
                <mat-card-subtitle>Build Connections</mat-card-subtitle>
              </mat-card-header>
              <mat-card-content>
                <p>Manage your friends list and discover new people to connect with.</p>
              </mat-card-content>
              <mat-card-actions>
                <button mat-raised-button color="warn" class="action-button">
                  <mat-icon>group_add</mat-icon>
                  Manage Friends
                </button>
              </mat-card-actions>
            </mat-card>

            <mat-card class="action-card success-card" routerLink="/profile">
              <div class="card-icon">
                <mat-icon>person</mat-icon>
              </div>
              <mat-card-header>
                <mat-card-title>My Profile</mat-card-title>
                <mat-card-subtitle>Personalize</mat-card-subtitle>
              </mat-card-header>
              <mat-card-content>
                <p>Update your profile information, settings, and showcase your personality.</p>
              </mat-card-content>
              <mat-card-actions>
                <button mat-raised-button class="action-button success-button">
                  <mat-icon>edit</mat-icon>
                  Edit Profile
                </button>
              </mat-card-actions>
            </mat-card>

            <mat-card class="action-card info-card" routerLink="/search">
              <div class="card-icon">
                <mat-icon>search</mat-icon>
              </div>
              <mat-card-header>
                <mat-card-title>Discover</mat-card-title>
                <mat-card-subtitle>Explore & Find</mat-card-subtitle>
              </mat-card-header>
              <mat-card-content>
                <p>Search for people, posts, and content to expand your social network.</p>
              </mat-card-content>
              <mat-card-actions>
                <button mat-raised-button class="action-button info-button">
                  <mat-icon>explore</mat-icon>
                  Start Exploring
                </button>
              </mat-card-actions>
            </mat-card>

            <mat-card class="action-card admin-card" routerLink="/admin" *ngIf="currentUser?.role === 'Admin'">
              <div class="card-icon">
                <mat-icon>admin_panel_settings</mat-icon>
              </div>
              <mat-card-header>
                <mat-card-title>Admin Panel</mat-card-title>
                <mat-card-subtitle>Manage Platform</mat-card-subtitle>
              </mat-card-header>
              <mat-card-content>
                <p>Manage users, moderate content, and handle platform administration tasks.</p>
              </mat-card-content>
              <mat-card-actions>
                <button mat-raised-button class="action-button admin-button">
                  <mat-icon>settings</mat-icon>
                  Admin Panel
                </button>
              </mat-card-actions>
            </mat-card>
          </div>
        </div>
      </mat-sidenav-content>
    </mat-sidenav-container>
  `,
  styles: [`
    /* Container Styles */
    .sidenav-container {
      height: 100vh;
      background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
    }

    .sidenav {
      width: 280px;
      background: #ffffff;
      box-shadow: 2px 0 8px rgba(0,0,0,0.1);
    }

    /* Sidenav Styles */
    .sidenav-toolbar {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      padding: 1rem;
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }

    .logo-icon {
      font-size: 2rem;
      width: 2rem;
      height: 2rem;
    }

    .logo-text {
      font-size: 1.5rem;
      font-weight: 600;
      letter-spacing: 0.5px;
    }

    .nav-list {
      padding: 0;
    }

    .nav-section {
      margin-bottom: 1.5rem;
    }

    .nav-section-title {
      padding: 1rem 1rem 0.5rem 1rem;
      font-size: 0.75rem;
      font-weight: 600;
      color: #666;
      text-transform: uppercase;
      letter-spacing: 1px;
    }

    .nav-section a {
      margin: 0.25rem 0.5rem;
      border-radius: 8px;
      transition: all 0.3s ease;
    }

    .nav-section a:hover {
      background-color: rgba(102, 126, 234, 0.1);
      transform: translateX(4px);
    }

    .nav-section a.active {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
    }

    .notification-badge {
      background: #ff4444;
      color: white;
      border-radius: 50%;
      width: 20px;
      height: 20px;
      font-size: 0.75rem;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    /* Main Toolbar */
    .main-toolbar {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
      padding: 0 1rem;
    }

    .menu-button {
      color: white;
    }

    .toolbar-title {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      margin-left: 1rem;
    }

    .title-icon {
      font-size: 1.5rem;
    }

    .title-text {
      font-size: 1.25rem;
      font-weight: 600;
    }

    .spacer {
      flex: 1 1 auto;
    }

    .toolbar-actions {
      display: flex;
      align-items: center;
      gap: 1rem;
    }

    .notification-button {
      color: white;
    }

    .user-info {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.5rem 1rem;
      background: rgba(255,255,255,0.1);
      border-radius: 20px;
      backdrop-filter: blur(10px);
    }

    .user-icon {
      font-size: 1.25rem;
    }

    .username {
      font-weight: 500;
    }

    .logout-button {
      color: white;
    }

    /* Content Styles */
    .content {
      padding: 2rem;
      max-width: 1400px;
      margin: 0 auto;
    }

    .welcome-section {
      text-align: center;
      margin-bottom: 3rem;
      padding: 3rem 0;
    }

    .welcome-content {
      background: white;
      border-radius: 20px;
      padding: 3rem 2rem;
      box-shadow: 0 8px 32px rgba(0,0,0,0.1);
      backdrop-filter: blur(10px);
    }

    .welcome-title {
      color: #333;
      margin-bottom: 1rem;
      font-size: 2.5rem;
      font-weight: 700;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 1rem;
    }

    .welcome-icon {
      font-size: 2.5rem;
      color: #667eea;
    }

    .welcome-subtitle {
      color: #666;
      font-size: 1.2rem;
      font-weight: 400;
      max-width: 600px;
      margin: 0 auto;
    }

    /* Quick Actions Grid */
    .quick-actions {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
      gap: 2rem;
    }

    .action-card {
      background: white;
      border-radius: 16px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.08);
      transition: all 0.3s ease;
      cursor: pointer;
      overflow: hidden;
      position: relative;
    }

    .action-card:hover {
      transform: translateY(-8px);
      box-shadow: 0 12px 40px rgba(0,0,0,0.15);
    }

    .action-card::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      height: 4px;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    }

    .primary-card::before { background: linear-gradient(135deg, #1976d2 0%, #1565c0 100%); }
    .accent-card::before { background: linear-gradient(135deg, #ff4081 0%, #e91e63 100%); }
    .warn-card::before { background: linear-gradient(135deg, #ff9800 0%, #f57c00 100%); }
    .success-card::before { background: linear-gradient(135deg, #4caf50 0%, #388e3c 100%); }
    .info-card::before { background: linear-gradient(135deg, #00bcd4 0%, #0097a7 100%); }
    .admin-card::before { background: linear-gradient(135deg, #9c27b0 0%, #7b1fa2 100%); }

    .card-icon {
      text-align: center;
      padding: 1.5rem 0 1rem 0;
    }

    .card-icon mat-icon {
      font-size: 3rem;
      width: 3rem;
      height: 3rem;
      color: #667eea;
    }

    .primary-card .card-icon mat-icon { color: #1976d2; }
    .accent-card .card-icon mat-icon { color: #ff4081; }
    .warn-card .card-icon mat-icon { color: #ff9800; }
    .success-card .card-icon mat-icon { color: #4caf50; }
    .info-card .card-icon mat-icon { color: #00bcd4; }
    .admin-card .card-icon mat-icon { color: #9c27b0; }

    .action-card mat-card-header {
      text-align: center;
      padding-bottom: 1rem;
    }

    .action-card mat-card-title {
      font-size: 1.5rem;
      font-weight: 600;
      color: #333;
      margin-bottom: 0.5rem;
    }

    .action-card mat-card-subtitle {
      color: #666;
      font-size: 0.9rem;
      font-weight: 500;
    }

    .action-card mat-card-content {
      padding: 0 1.5rem 1rem 1.5rem;
    }

    .action-card mat-card-content p {
      color: #666;
      line-height: 1.6;
      text-align: center;
    }

    .action-card mat-card-actions {
      padding: 1rem 1.5rem 1.5rem 1.5rem;
      display: flex;
      justify-content: center;
    }

    .action-button {
      width: 100%;
      padding: 0.75rem 1.5rem;
      font-size: 1rem;
      font-weight: 600;
      border-radius: 8px;
      transition: all 0.3s ease;
    }

    .action-button:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    }

    .success-button {
      background: linear-gradient(135deg, #4caf50 0%, #388e3c 100%);
      color: white;
    }

    .info-button {
      background: linear-gradient(135deg, #00bcd4 0%, #0097a7 100%);
      color: white;
    }

    .admin-button {
      background: linear-gradient(135deg, #9c27b0 0%, #7b1fa2 100%);
      color: white;
    }

    /* Responsive Design */
    @media (max-width: 1200px) {
      .quick-actions {
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      }
    }

    @media (max-width: 768px) {
      .content {
        padding: 1rem;
      }

      .welcome-content {
        padding: 2rem 1rem;
      }

      .welcome-title {
        font-size: 2rem;
        flex-direction: column;
        gap: 0.5rem;
      }

      .welcome-icon {
        font-size: 2rem;
      }

      .quick-actions {
        grid-template-columns: 1fr;
        gap: 1.5rem;
      }

      .toolbar-title {
        display: none;
      }

      .user-info .username {
        display: none;
      }

      .toolbar-actions {
        gap: 0.5rem;
      }
    }

    @media (max-width: 480px) {
      .sidenav {
        width: 100%;
      }

      .welcome-title {
        font-size: 1.5rem;
      }

      .welcome-subtitle {
        font-size: 1rem;
      }

      .action-card mat-card-title {
        font-size: 1.25rem;
      }

      .card-icon mat-icon {
        font-size: 2.5rem;
        width: 2.5rem;
        height: 2.5rem;
      }
    }

    /* Animation for smooth transitions */
    .action-card {
      animation: fadeInUp 0.6s ease-out;
    }

    @keyframes fadeInUp {
      from {
        opacity: 0;
        transform: translateY(30px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    /* Stagger animation for cards */
    .action-card:nth-child(1) { animation-delay: 0.1s; }
    .action-card:nth-child(2) { animation-delay: 0.2s; }
    .action-card:nth-child(3) { animation-delay: 0.3s; }
    .action-card:nth-child(4) { animation-delay: 0.4s; }
    .action-card:nth-child(5) { animation-delay: 0.5s; }
    .action-card:nth-child(6) { animation-delay: 0.6s; }
  `]
})
export class DashboardComponent implements OnInit {
  currentUser: User | null = null;
  unreadCount = 0;

  constructor(
    private authService: AuthService,
    private apiService: ApiService,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
      if (user) {
        this.loadUnreadCount();
      }
    });
  }

  loadUnreadCount() {
    this.apiService.getUnreadCount().subscribe({
      next: (response) => {
        this.unreadCount = response.count;
      },
      error: () => {
        // Silently fail for unread count
      }
    });
  }

  logout() {
    this.authService.logout();
    this.snackBar.open('Logged out successfully', 'Close', { duration: 3000 });
  }
}

