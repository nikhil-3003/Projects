import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatChipsModule } from '@angular/material/chips';
import { MatTooltipModule } from '@angular/material/tooltip';
import { AuthService } from '../../../services/auth.service';
import { ApiService } from '../../../services/api.service';
import { Post } from '../../../models/post.model';

@Component({
  selector: 'app-post-approval',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatToolbarModule,
    MatSidenavModule,
    MatListModule,
    MatSnackBarModule,
    MatProgressSpinnerModule,
    MatChipsModule,
    MatTooltipModule
  ],
  template: `
    <mat-sidenav-container class="sidenav-container">
      <mat-sidenav #drawer class="sidenav" fixedInViewport
          [attr.role]="'navigation'"
          [mode]="'over'"
          [opened]="false">
        <mat-toolbar>ProfileBook Admin</mat-toolbar>
        <mat-nav-list>
          <a mat-list-item routerLink="/admin" routerLinkActive="active">
            <mat-icon matListItemIcon>dashboard</mat-icon>
            <span matListItemTitle>Dashboard</span>
          </a>
          <a mat-list-item routerLink="/admin/users" routerLinkActive="active">
            <mat-icon matListItemIcon>people</mat-icon>
            <span matListItemTitle>User Management</span>
          </a>
          <a mat-list-item routerLink="/admin/posts" routerLinkActive="active">
            <mat-icon matListItemIcon>article</mat-icon>
            <span matListItemTitle>Post Approval</span>
          </a>
          <a mat-list-item routerLink="/admin/reports" routerLinkActive="active">
            <mat-icon matListItemIcon>report_problem</mat-icon>
            <span matListItemTitle>Reports</span>
          </a>
          <a mat-list-item routerLink="/admin/groups" routerLinkActive="active">
            <mat-icon matListItemIcon>group</mat-icon>
            <span matListItemTitle>Groups</span>
          </a>
        </mat-nav-list>
      </mat-sidenav>
      <mat-sidenav-content>
        <mat-toolbar color="primary">
          <button
            type="button"
            aria-label="Toggle sidenav"
            mat-icon-button
            (click)="drawer.toggle()">
            <mat-icon aria-label="Side nav toggle icon">menu</mat-icon>
          </button>
          <span>Post Approval</span>
          <span class="spacer"></span>
          <button mat-icon-button (click)="logout()" matTooltip="Logout">
            <mat-icon>logout</mat-icon>
          </button>
        </mat-toolbar>
        
        <div class="content">
          <div class="header-actions">
            <mat-chip-set>
              <mat-chip [color]="filterStatus === 'all' ? 'primary' : ''" 
                        (click)="setFilter('all')">All Posts</mat-chip>
              <mat-chip [color]="filterStatus === 'pending' ? 'primary' : ''" 
                        (click)="setFilter('pending')">Pending</mat-chip>
              <mat-chip [color]="filterStatus === 'approved' ? 'primary' : ''" 
                        (click)="setFilter('approved')">Approved</mat-chip>
              <mat-chip [color]="filterStatus === 'rejected' ? 'primary' : ''" 
                        (click)="setFilter('rejected')">Rejected</mat-chip>
            </mat-chip-set>
          </div>

          <div *ngIf="isLoading" class="loading-container">
            <mat-spinner></mat-spinner>
            <p>Loading posts...</p>
          </div>

          <div *ngIf="!isLoading && filteredPosts.length === 0" class="no-posts">
            <mat-icon>article</mat-icon>
            <h3>No posts found</h3>
            <p>No posts match the current filter.</p>
          </div>

          <div *ngIf="!isLoading && filteredPosts.length > 0" class="posts-container">
            <mat-card *ngFor="let post of filteredPosts" class="post-card">
              <mat-card-header>
                <div mat-card-avatar class="post-avatar">
                  <img [src]="post.user?.profileImage || '/assets/default-avatar.png'" 
                       [alt]="post.user?.username" 
                       *ngIf="post.user?.profileImage; else defaultAvatar">
                  <ng-template #defaultAvatar>
                    <mat-icon>person</mat-icon>
                  </ng-template>
                </div>
                <mat-card-title>{{ post.user?.username }}</mat-card-title>
                <mat-card-subtitle>{{ formatDate(post.createdAt) }}</mat-card-subtitle>
                <mat-chip [color]="getStatusColor(post.status)" class="status-chip">
                  {{ post.status }}
                </mat-chip>
              </mat-card-header>
              
              <mat-card-content>
                <p class="post-content">{{ post.content }}</p>
                <img *ngIf="post.postImage" [src]="post.postImage" [alt]="'Post image'" class="post-image">
              </mat-card-content>
              
              <mat-card-actions *ngIf="post.status === 'Pending'">
                <button mat-raised-button color="primary" (click)="approvePost(post)">
                  <mat-icon>check</mat-icon>
                  Approve
                </button>
                <button mat-raised-button color="warn" (click)="rejectPost(post)">
                  <mat-icon>close</mat-icon>
                  Reject
                </button>
              </mat-card-actions>

              <mat-card-actions *ngIf="post.status !== 'Pending'">
                <span class="action-info">
                  {{ post.status }} by admin on {{ formatDate(post.approvedAt || '') }}
                </span>
              </mat-card-actions>
            </mat-card>
          </div>
        </div>
      </mat-sidenav-content>
    </mat-sidenav-container>
  `,
  styles: [`
    .sidenav-container {
      height: 100vh;
    }

    .sidenav {
      width: 250px;
    }

    .sidenav .mat-toolbar {
      background: inherit;
    }

    .mat-toolbar.mat-primary {
      position: sticky;
      top: 0;
      z-index: 1;
    }

    .spacer {
      flex: 1 1 auto;
    }

    .content {
      padding: 2rem;
    }

    .header-actions {
      margin-bottom: 2rem;
    }

    .loading-container {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 4rem;
    }

    .no-posts {
      text-align: center;
      padding: 4rem;
    }

    .no-posts mat-icon {
      font-size: 4rem;
      width: 4rem;
      height: 4rem;
      color: #ccc;
      margin-bottom: 1rem;
    }

    .posts-container {
      max-width: 800px;
      margin: 0 auto;
    }

    .post-card {
      margin-bottom: 2rem;
    }

    .post-avatar {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      overflow: hidden;
    }

    .post-avatar img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .status-chip {
      margin-left: auto;
    }

    .post-content {
      font-size: 1.1rem;
      line-height: 1.5;
      margin: 1rem 0;
    }

    .post-image {
      width: 100%;
      max-height: 400px;
      object-fit: cover;
      border-radius: 8px;
      margin-top: 1rem;
    }

    .action-info {
      color: #666;
      font-size: 0.9rem;
    }

    .active {
      background-color: rgba(25, 118, 210, 0.1);
    }
  `]
})
export class PostApprovalComponent implements OnInit {
  posts: Post[] = [];
  filteredPosts: Post[] = [];
  filterStatus = 'all';
  isLoading = true;

  constructor(
    private authService: AuthService,
    private apiService: ApiService,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit() {
    this.loadPosts();
  }

  loadPosts() {
    this.isLoading = true;
    this.apiService.getPosts().subscribe({
      next: (posts) => {
        this.posts = posts;
        this.filteredPosts = posts;
        this.isLoading = false;
      },
      error: () => {
        this.isLoading = false;
        this.snackBar.open('Failed to load posts', 'Close', { duration: 3000 });
      }
    });
  }

  setFilter(status: string) {
    this.filterStatus = status;
    if (status === 'all') {
      this.filteredPosts = this.posts;
    } else {
      this.filteredPosts = this.posts.filter(post => post.status.toLowerCase() === status);
    }
  }

  getStatusColor(status: string): string {
    switch (status.toLowerCase()) {
      case 'approved': return 'primary';
      case 'pending': return 'accent';
      case 'rejected': return 'warn';
      default: return '';
    }
  }

  approvePost(post: Post) {
    if (confirm('Are you sure you want to approve this post?')) {
      this.apiService.approvePost(post.postId).subscribe({
        next: () => {
          post.status = 'Approved';
          post.approvedAt = new Date().toISOString();
          this.snackBar.open('Post approved successfully', 'Close', { duration: 3000 });
        },
        error: () => {
          this.snackBar.open('Failed to approve post', 'Close', { duration: 3000 });
        }
      });
    }
  }

  rejectPost(post: Post) {
    if (confirm('Are you sure you want to reject this post?')) {
      this.apiService.rejectPost(post.postId).subscribe({
        next: () => {
          post.status = 'Rejected';
          post.approvedAt = new Date().toISOString();
          this.snackBar.open('Post rejected successfully', 'Close', { duration: 3000 });
        },
        error: () => {
          this.snackBar.open('Failed to reject post', 'Close', { duration: 3000 });
        }
      });
    }
  }

  formatDate(dateString: string): string {
    return new Date(dateString).toLocaleDateString();
  }

  logout() {
    this.authService.logout();
    this.snackBar.open('Logged out successfully', 'Close', { duration: 3000 });
  }
}

