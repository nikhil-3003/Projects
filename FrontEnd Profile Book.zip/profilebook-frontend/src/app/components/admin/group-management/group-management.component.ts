import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDialogModule, MatDialog } from '@angular/material/dialog';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTabsModule } from '@angular/material/tabs';
import { MatChipsModule } from '@angular/material/chips';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatTooltipModule } from '@angular/material/tooltip';
import { ApiService } from '../../../services/api.service';
import { Group } from '../../../models/group.model';
import { User } from '../../../models/user.model';

@Component({
  selector: 'app-group-management',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatTableModule,
    MatButtonModule,
    MatIconModule,
    MatDialogModule,
    MatSnackBarModule,
    MatTabsModule,
    MatChipsModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    FormsModule,
    ReactiveFormsModule,
    MatTooltipModule
  ],
  template: `
    <div class="group-management-container">
      <mat-card>
        <mat-card-header>
          <mat-card-title>Group Management</mat-card-title>
          <button mat-raised-button color="primary" (click)="openCreateGroupDialog()">
            <mat-icon>add</mat-icon>
            Create Group
          </button>
        </mat-card-header>
        <mat-card-content>
          <mat-tab-group>
            <mat-tab label="All Groups">
              <div class="table-container">
                <table mat-table [dataSource]="groups" class="groups-table">
                  <ng-container matColumnDef="groupId">
                    <th mat-header-cell *matHeaderCellDef>ID</th>
                    <td mat-cell *matCellDef="let group">{{ group.groupId }}</td>
                  </ng-container>

                  <ng-container matColumnDef="groupName">
                    <th mat-header-cell *matHeaderCellDef>Group Name</th>
                    <td mat-cell *matCellDef="let group">{{ group.groupName }}</td>
                  </ng-container>

                  <ng-container matColumnDef="description">
                    <th mat-header-cell *matHeaderCellDef>Description</th>
                    <td mat-cell *matCellDef="let group">{{ group.description || 'No description' }}</td>
                  </ng-container>

                  <ng-container matColumnDef="memberCount">
                    <th mat-header-cell *matHeaderCellDef>Members</th>
                    <td mat-cell *matCellDef="let group">{{ group.groupMembers?.length || 0 }}</td>
                  </ng-container>

                  <ng-container matColumnDef="createdAt">
                    <th mat-header-cell *matHeaderCellDef>Created</th>
                    <td mat-cell *matCellDef="let group">{{ group.createdAt | date:'short' }}</td>
                  </ng-container>

                  <ng-container matColumnDef="isActive">
                    <th mat-header-cell *matHeaderCellDef>Status</th>
                    <td mat-cell *matCellDef="let group">
                      <mat-chip [color]="group.isActive ? 'primary' : 'warn'" selected>
                        {{ group.isActive ? 'Active' : 'Inactive' }}
                      </mat-chip>
                    </td>
                  </ng-container>

                  <ng-container matColumnDef="actions">
                    <th mat-header-cell *matHeaderCellDef>Actions</th>
                    <td mat-cell *matCellDef="let group">
                      <button mat-icon-button (click)="viewGroup(group)" matTooltip="View Details">
                        <mat-icon>visibility</mat-icon>
                      </button>
                      <button mat-icon-button (click)="editGroup(group)" matTooltip="Edit">
                        <mat-icon>edit</mat-icon>
                      </button>
                      <button mat-icon-button (click)="deleteGroup(group)" matTooltip="Delete">
                        <mat-icon>delete</mat-icon>
                      </button>
                    </td>
                  </ng-container>

                  <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
                  <tr mat-row *matRowDef="let row; columns: displayedColumns;"></tr>
                </table>
              </div>
            </mat-tab>

            <mat-tab label="Group Members">
              <div class="members-section">
                <mat-form-field appearance="outline">
                  <mat-label>Select Group</mat-label>
                  <mat-select [(value)]="selectedGroupId" (selectionChange)="loadGroupMembers()">
                    <mat-option *ngFor="let group of groups" [value]="group.groupId">
                      {{ group.groupName }}
                    </mat-option>
                  </mat-select>
                </mat-form-field>

                <div *ngIf="selectedGroupMembers.length > 0" class="members-table">
                  <table mat-table [dataSource]="selectedGroupMembers" class="members-table">
                    <ng-container matColumnDef="userId">
                      <th mat-header-cell *matHeaderCellDef>User ID</th>
                      <td mat-cell *matCellDef="let member">{{ member.userId }}</td>
                    </ng-container>

                    <ng-container matColumnDef="username">
                      <th mat-header-cell *matHeaderCellDef>Username</th>
                      <td mat-cell *matCellDef="let member">{{ member.user?.username }}</td>
                    </ng-container>

                    <ng-container matColumnDef="joinedAt">
                      <th mat-header-cell *matHeaderCellDef>Joined</th>
                      <td mat-cell *matCellDef="let member">{{ member.joinedAt | date:'short' }}</td>
                    </ng-container>

                    <ng-container matColumnDef="actions">
                      <th mat-header-cell *matHeaderCellDef>Actions</th>
                      <td mat-cell *matCellDef="let member">
                        <button mat-icon-button (click)="removeMember(member)" matTooltip="Remove Member">
                          <mat-icon>remove_circle</mat-icon>
                        </button>
                      </td>
                    </ng-container>

                    <tr mat-header-row *matHeaderRowDef="memberColumns"></tr>
                    <tr mat-row *matRowDef="let row; columns: memberColumns;"></tr>
                  </table>
                </div>
              </div>
            </mat-tab>
          </mat-tab-group>
        </mat-card-content>
      </mat-card>

      <!-- Create/Edit Group Dialog -->
      <div *ngIf="showGroupDialog" class="group-dialog">
        <mat-card>
          <mat-card-header>
            <mat-card-title>{{ isEditing ? 'Edit Group' : 'Create Group' }}</mat-card-title>
            <button mat-icon-button (click)="closeGroupDialog()">
              <mat-icon>close</mat-icon>
            </button>
          </mat-card-header>
          <mat-card-content>
            <form [formGroup]="groupForm" (ngSubmit)="saveGroup()">
              <mat-form-field appearance="outline" class="full-width">
                <mat-label>Group Name</mat-label>
                <input matInput formControlName="groupName" required>
                <mat-error *ngIf="groupForm.get('groupName')?.hasError('required')">
                  Group name is required
                </mat-error>
              </mat-form-field>

              <mat-form-field appearance="outline" class="full-width">
                <mat-label>Description</mat-label>
                <textarea matInput formControlName="description" rows="3"></textarea>
              </mat-form-field>

              <div class="dialog-actions">
                <button mat-button type="button" (click)="closeGroupDialog()">Cancel</button>
                <button mat-raised-button color="primary" type="submit" [disabled]="groupForm.invalid">
                  {{ isEditing ? 'Update' : 'Create' }}
                </button>
              </div>
            </form>
          </mat-card-content>
        </mat-card>
      </div>

      <!-- Group Details Dialog -->
      <div *ngIf="selectedGroup" class="group-details-dialog">
        <mat-card>
          <mat-card-header>
            <mat-card-title>Group Details</mat-card-title>
            <button mat-icon-button (click)="closeGroupDetails()">
              <mat-icon>close</mat-icon>
            </button>
          </mat-card-header>
          <mat-card-content>
            <div class="group-details">
              <p><strong>Group ID:</strong> {{ selectedGroup.groupId }}</p>
              <p><strong>Group Name:</strong> {{ selectedGroup.groupName }}</p>
              <p><strong>Description:</strong> {{ selectedGroup.description || 'No description' }}</p>
              <p><strong>Created:</strong> {{ selectedGroup.createdAt | date:'medium' }}</p>
              <p><strong>Status:</strong> {{ selectedGroup.isActive ? 'Active' : 'Inactive' }}</p>
              <p><strong>Members:</strong> {{ selectedGroup.groupMembers.length || 0 }}</p>
            </div>
            <div class="group-actions">
              <button mat-raised-button color="primary" (click)="editGroup(selectedGroup)">
                Edit Group
              </button>
              <button mat-raised-button color="warn" (click)="deleteGroup(selectedGroup)">
                Delete Group
              </button>
            </div>
          </mat-card-content>
        </mat-card>
      </div>
    </div>
  `,
  styles: [`
    .group-management-container {
      padding: 20px;
    }

    .table-container {
      overflow-x: auto;
    }

    .groups-table, .members-table {
      width: 100%;
    }

    .members-section {
      padding: 20px 0;
    }

    .group-dialog, .group-details-dialog {
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      z-index: 1000;
      background: white;
      border-radius: 8px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      max-width: 500px;
      width: 90%;
    }

    .group-details {
      margin-bottom: 20px;
    }

    .group-details p {
      margin: 10px 0;
    }

    .group-actions, .dialog-actions {
      display: flex;
      gap: 10px;
      justify-content: flex-end;
    }

    .full-width {
      width: 100%;
      margin-bottom: 1rem;
    }

    mat-card-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
  `]
})
export class GroupManagementComponent implements OnInit {
  groups: Group[] = [];
  selectedGroupMembers: any[] = [];
  selectedGroup: Group | null = null;
  selectedGroupId: number | null = null;
  showGroupDialog = false;
  isEditing = false;
  groupForm: FormGroup;
  displayedColumns: string[] = ['groupId', 'groupName', 'description', 'memberCount', 'createdAt', 'isActive', 'actions'];
  memberColumns: string[] = ['userId', 'username', 'joinedAt', 'actions'];

  constructor(
    private apiService: ApiService,
    private snackBar: MatSnackBar,
    private fb: FormBuilder
  ) {
    this.groupForm = this.fb.group({
      groupName: ['', Validators.required],
      description: ['']
    });
  }

  ngOnInit() {
    this.loadGroups();
  }

  loadGroups() {
    this.apiService.getGroups().subscribe({
      next: (groups) => {
        this.groups = groups;
      },
      error: (error) => {
        this.snackBar.open('Error loading groups', 'Close', { duration: 3000 });
      }
    });
  }

  loadGroupMembers() {
    if (this.selectedGroupId) {
      this.apiService.getGroupMembers(this.selectedGroupId).subscribe({
        next: (members) => {
          this.selectedGroupMembers = members;
        },
        error: (error) => {
          this.snackBar.open('Error loading group members', 'Close', { duration: 3000 });
        }
      });
    }
  }

  openCreateGroupDialog() {
    this.isEditing = false;
    this.groupForm.reset();
    this.showGroupDialog = true;
  }

  editGroup(group: Group) {
    this.isEditing = true;
    this.groupForm.patchValue({
      groupName: group.groupName,
      description: group.description
    });
    this.showGroupDialog = true;
  }

  closeGroupDialog() {
    this.showGroupDialog = false;
    this.groupForm.reset();
  }

  saveGroup() {
    if (this.groupForm.valid) {
      const groupData = this.groupForm.value;
      
      if (this.isEditing) {
        // Update existing group
        this.apiService.updateGroup(this.selectedGroup!.groupId, groupData).subscribe({
          next: () => {
            this.snackBar.open('Group updated successfully', 'Close', { duration: 3000 });
            this.loadGroups();
            this.closeGroupDialog();
          },
          error: (error) => {
            this.snackBar.open('Error updating group', 'Close', { duration: 3000 });
          }
        });
      } else {
        // Create new group
        this.apiService.createGroup(groupData).subscribe({
          next: () => {
            this.snackBar.open('Group created successfully', 'Close', { duration: 3000 });
            this.loadGroups();
            this.closeGroupDialog();
          },
          error: (error) => {
            this.snackBar.open('Error creating group', 'Close', { duration: 3000 });
          }
        });
      }
    }
  }

  viewGroup(group: Group) {
    this.selectedGroup = group;
  }

  closeGroupDetails() {
    this.selectedGroup = null;
  }

  deleteGroup(group: Group) {
    if (confirm(`Are you sure you want to delete the group "${group.groupName}"?`)) {
      this.apiService.deleteGroup(group.groupId).subscribe({
        next: () => {
          this.snackBar.open('Group deleted successfully', 'Close', { duration: 3000 });
          this.loadGroups();
          this.closeGroupDetails();
        },
        error: (error) => {
          this.snackBar.open('Error deleting group', 'Close', { duration: 3000 });
        }
      });
    }
  }

  removeMember(member: any) {
    if (confirm(`Are you sure you want to remove this member from the group?`)) {
      this.apiService.removeUserFromGroup(this.selectedGroupId!, member.userId).subscribe({
        next: () => {
          this.snackBar.open('Member removed successfully', 'Close', { duration: 3000 });
          this.loadGroupMembers();
        },
        error: (error) => {
          this.snackBar.open('Error removing member', 'Close', { duration: 3000 });
        }
      });
    }
  }
}
