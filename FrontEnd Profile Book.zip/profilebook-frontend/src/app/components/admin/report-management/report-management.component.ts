import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDialogModule, MatDialog } from '@angular/material/dialog';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTabsModule } from '@angular/material/tabs';
import { MatChipsModule } from '@angular/material/chips';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { FormsModule } from '@angular/forms';
import { MatTooltipModule } from '@angular/material/tooltip';
import { ApiService } from '../../../services/api.service';
import { Report } from '../../../models/report.model';

@Component({
  selector: 'app-report-management',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatTableModule,
    MatButtonModule,
    MatIconModule,
    MatDialogModule,
    MatSnackBarModule,
    MatTabsModule,
    MatChipsModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    FormsModule,
    MatTooltipModule
  ],
  template: `
    <div class="report-management-container">
      <mat-card>
        <mat-card-header>
          <mat-card-title>Report Management</mat-card-title>
        </mat-card-header>
        <mat-card-content>
          <mat-tab-group>
            <mat-tab label="All Reports">
              <div class="table-container">
                <table mat-table [dataSource]="allReports" class="reports-table">
                  <ng-container matColumnDef="reportId">
                    <th mat-header-cell *matHeaderCellDef>ID</th>
                    <td mat-cell *matCellDef="let report">{{ report.reportId }}</td>
                  </ng-container>

                  <ng-container matColumnDef="reportedUser">
                    <th mat-header-cell *matHeaderCellDef>Reported User</th>
                    <td mat-cell *matCellDef="let report">{{ report.reportedUser?.username }}</td>
                  </ng-container>

                  <ng-container matColumnDef="reportingUser">
                    <th mat-header-cell *matHeaderCellDef>Reporting User</th>
                    <td mat-cell *matCellDef="let report">{{ report.reportingUser?.username }}</td>
                  </ng-container>

                  <ng-container matColumnDef="reason">
                    <th mat-header-cell *matHeaderCellDef>Reason</th>
                    <td mat-cell *matCellDef="let report">{{ report.reason }}</td>
                  </ng-container>

                  <ng-container matColumnDef="status">
                    <th mat-header-cell *matHeaderCellDef>Status</th>
                    <td mat-cell *matCellDef="let report">
                      <mat-chip [color]="getStatusColor(report.status)" selected>
                        {{ report.status }}
                      </mat-chip>
                    </td>
                  </ng-container>

                  <ng-container matColumnDef="timestamp">
                    <th mat-header-cell *matHeaderCellDef>Date</th>
                    <td mat-cell *matCellDef="let report">{{ report.timeStamp | date:'short' }}</td>
                  </ng-container>

                  <ng-container matColumnDef="actions">
                    <th mat-header-cell *matHeaderCellDef>Actions</th>
                    <td mat-cell *matCellDef="let report">
                      <button mat-icon-button (click)="viewReport(report)" matTooltip="View Details">
                        <mat-icon>visibility</mat-icon>
                      </button>
                      <button mat-icon-button (click)="updateReportStatus(report, 'Reviewed')" 
                              *ngIf="report.status === 'Pending'" matTooltip="Mark as Reviewed">
                        <mat-icon>check</mat-icon>
                      </button>
                      <button mat-icon-button (click)="updateReportStatus(report, 'Dismissed')" 
                              *ngIf="report.status === 'Pending'" matTooltip="Dismiss">
                        <mat-icon>close</mat-icon>
                      </button>
                    </td>
                  </ng-container>

                  <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
                  <tr mat-row *matRowDef="let row; columns: displayedColumns;"></tr>
                </table>
              </div>
            </mat-tab>

            <mat-tab label="Pending Reports">
              <div class="table-container">
                <table mat-table [dataSource]="pendingReports" class="reports-table">
                  <ng-container matColumnDef="reportId">
                    <th mat-header-cell *matHeaderCellDef>ID</th>
                    <td mat-cell *matCellDef="let report">{{ report.reportId }}</td>
                  </ng-container>

                  <ng-container matColumnDef="reportedUser">
                    <th mat-header-cell *matHeaderCellDef>Reported User</th>
                    <td mat-cell *matCellDef="let report">{{ report.reportedUser?.username }}</td>
                  </ng-container>

                  <ng-container matColumnDef="reportingUser">
                    <th mat-header-cell *matHeaderCellDef>Reporting User</th>
                    <td mat-cell *matCellDef="let report">{{ report.reportingUser?.username }}</td>
                  </ng-container>

                  <ng-container matColumnDef="reason">
                    <th mat-header-cell *matHeaderCellDef>Reason</th>
                    <td mat-cell *matCellDef="let report">{{ report.reason }}</td>
                  </ng-container>

                  <ng-container matColumnDef="timestamp">
                    <th mat-header-cell *matHeaderCellDef>Date</th>
                    <td mat-cell *matCellDef="let report">{{ report.timeStamp | date:'short' }}</td>
                  </ng-container>

                  <ng-container matColumnDef="actions">
                    <th mat-header-cell *matHeaderCellDef>Actions</th>
                    <td mat-cell *matCellDef="let report">
                      <button mat-icon-button (click)="viewReport(report)" matTooltip="View Details">
                        <mat-icon>visibility</mat-icon>
                      </button>
                      <button mat-icon-button (click)="updateReportStatus(report, 'Reviewed')" matTooltip="Mark as Reviewed">
                        <mat-icon>check</mat-icon>
                      </button>
                      <button mat-icon-button (click)="updateReportStatus(report, 'Dismissed')" matTooltip="Dismiss">
                        <mat-icon>close</mat-icon>
                      </button>
                    </td>
                  </ng-container>

                  <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
                  <tr mat-row *matRowDef="let row; columns: displayedColumns;"></tr>
                </table>
              </div>
            </mat-tab>
          </mat-tab-group>
        </mat-card-content>
      </mat-card>

      <!-- Report Details Dialog -->
      <div *ngIf="selectedReport" class="report-details-dialog">
        <mat-card>
          <mat-card-header>
            <mat-card-title>Report Details</mat-card-title>
            <button mat-icon-button (click)="closeReportDetails()">
              <mat-icon>close</mat-icon>
            </button>
          </mat-card-header>
          <mat-card-content>
            <div class="report-details">
              <p><strong>Report ID:</strong> {{ selectedReport.reportId }}</p>
              <p><strong>Reported User:</strong> {{ selectedReport.reportedUser?.username }}</p>
              <p><strong>Reporting User:</strong> {{ selectedReport.reportingUser?.username }}</p>
              <p><strong>Reason:</strong> {{ selectedReport.reason }}</p>
              <p><strong>Status:</strong> {{ selectedReport.status }}</p>
              <p><strong>Date:</strong> {{ selectedReport.timeStamp | date:'medium' }}</p>
              <p><strong>Admin Notes:</strong> {{ selectedReport.adminNotes || 'None' }}</p>
            </div>
            <div class="report-actions" *ngIf="selectedReport.status === 'Pending'">
              <button mat-raised-button color="primary" (click)="updateReportStatus(selectedReport, 'Reviewed')">
                Mark as Reviewed
              </button>
              <button mat-raised-button color="warn" (click)="updateReportStatus(selectedReport, 'Dismissed')">
                Dismiss
              </button>
            </div>
          </mat-card-content>
        </mat-card>
      </div>
    </div>
  `,
  styles: [`
    .report-management-container {
      padding: 20px;
    }

    .table-container {
      overflow-x: auto;
    }

    .reports-table {
      width: 100%;
    }

    .report-details-dialog {
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      z-index: 1000;
      background: white;
      border-radius: 8px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      max-width: 500px;
      width: 90%;
    }

    .report-details {
      margin-bottom: 20px;
    }

    .report-details p {
      margin: 10px 0;
    }

    .report-actions {
      display: flex;
      gap: 10px;
      justify-content: flex-end;
    }

    mat-card-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
  `]
})
export class ReportManagementComponent implements OnInit {
  allReports: Report[] = [];
  pendingReports: Report[] = [];
  selectedReport: Report | null = null;
  displayedColumns: string[] = ['reportId', 'reportedUser', 'reportingUser', 'reason', 'status', 'timestamp', 'actions'];

  constructor(
    private apiService: ApiService,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit() {
    this.loadReports();
  }

  loadReports() {
    this.apiService.getReports().subscribe({
      next: (reports) => {
        this.allReports = reports;
        this.pendingReports = reports.filter(r => r.status === 'Pending');
      },
      error: (error) => {
        this.snackBar.open('Error loading reports', 'Close', { duration: 3000 });
      }
    });
  }

  viewReport(report: Report) {
    this.selectedReport = report;
  }

  closeReportDetails() {
    this.selectedReport = null;
  }

  updateReportStatus(report: Report, status: string) {
    this.apiService.updateReportStatus(report.reportId, status).subscribe({
      next: () => {
        this.snackBar.open(`Report ${status.toLowerCase()} successfully`, 'Close', { duration: 3000 });
        this.loadReports();
        this.closeReportDetails();
      },
      error: (error) => {
        this.snackBar.open('Error updating report status', 'Close', { duration: 3000 });
      }
    });
  }

  getStatusColor(status: string): 'primary' | 'accent' | 'warn' {
    switch (status) {
      case 'Pending': return 'warn';
      case 'Reviewed': return 'primary';
      case 'Dismissed': return 'accent';
      default: return 'primary';
    }
  }
}
