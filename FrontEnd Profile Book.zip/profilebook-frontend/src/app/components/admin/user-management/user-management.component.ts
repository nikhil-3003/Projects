import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTableModule } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatMenuModule } from '@angular/material/menu';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatChipsModule } from '@angular/material/chips';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../../services/auth.service';
import { ApiService } from '../../../services/api.service';
import { User } from '../../../models/user.model';

@Component({
  selector: 'app-user-management',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatToolbarModule,
    MatSidenavModule,
    MatListModule,
    MatSnackBarModule,
    MatTableModule,
    MatFormFieldModule,
    MatInputModule,
    MatProgressSpinnerModule,
    MatDialogModule,
    MatMenuModule,
    MatTooltipModule,
    MatChipsModule,
    FormsModule
  ],
  template: `
    <mat-sidenav-container class="sidenav-container">
      <mat-sidenav #drawer class="sidenav" fixedInViewport
          [attr.role]="'navigation'"
          [mode]="'over'"
          [opened]="false">
        <mat-toolbar>ProfileBook Admin</mat-toolbar>
        <mat-nav-list>
          <a mat-list-item routerLink="/admin" routerLinkActive="active">
            <mat-icon matListItemIcon>dashboard</mat-icon>
            <span matListItemTitle>Dashboard</span>
          </a>
          <a mat-list-item routerLink="/admin/users" routerLinkActive="active">
            <mat-icon matListItemIcon>people</mat-icon>
            <span matListItemTitle>User Management</span>
          </a>
          <a mat-list-item routerLink="/admin/posts" routerLinkActive="active">
            <mat-icon matListItemIcon>article</mat-icon>
            <span matListItemTitle>Post Approval</span>
          </a>
          <a mat-list-item routerLink="/admin/reports" routerLinkActive="active">
            <mat-icon matListItemIcon>report_problem</mat-icon>
            <span matListItemTitle>Reports</span>
          </a>
          <a mat-list-item routerLink="/admin/groups" routerLinkActive="active">
            <mat-icon matListItemIcon>group</mat-icon>
            <span matListItemTitle>Groups</span>
          </a>
        </mat-nav-list>
      </mat-sidenav>
      <mat-sidenav-content>
        <mat-toolbar color="primary">
          <button
            type="button"
            aria-label="Toggle sidenav"
            mat-icon-button
            (click)="drawer.toggle()">
            <mat-icon aria-label="Side nav toggle icon">menu</mat-icon>
          </button>
          <span>User Management</span>
          <span class="spacer"></span>
          <button mat-icon-button (click)="logout()" matTooltip="Logout">
            <mat-icon>logout</mat-icon>
          </button>
        </mat-toolbar>
        
        <div class="content">
          <div class="header-actions">
            <mat-form-field appearance="outline" class="search-field">
              <mat-label>Search users</mat-label>
              <input matInput [(ngModel)]="searchTerm" (input)="searchUsers()" placeholder="Search by username or email">
              <mat-icon matSuffix>search</mat-icon>
            </mat-form-field>
          </div>

          <div *ngIf="isLoading" class="loading-container">
            <mat-spinner></mat-spinner>
            <p>Loading users...</p>
          </div>

          <div *ngIf="!isLoading" class="users-container">
            <mat-card *ngFor="let user of filteredUsers" class="user-card">
              <mat-card-header>
                <div mat-card-avatar class="user-avatar">
                  <img [src]="user.profileImage || '/assets/default-avatar.png'" 
                       [alt]="user.username" 
                       *ngIf="user.profileImage; else defaultAvatar">
                  <ng-template #defaultAvatar>
                    <mat-icon>person</mat-icon>
                  </ng-template>
                </div>
                <mat-card-title>{{ user.username }}</mat-card-title>
                <mat-card-subtitle>{{ user.email }}</mat-card-subtitle>
                <mat-chip [color]="user.role === 'Admin' ? 'accent' : 'primary'">
                  {{ user.role }}
                </mat-chip>
              </mat-card-header>
              
              <mat-card-content>
                <p><strong>Joined:</strong> {{ formatDate(user.createdAt) }}</p>
                <p><strong>Status:</strong> {{ user.isActive ? 'Active' : 'Inactive' }}</p>
              </mat-card-content>
              
              <mat-card-actions>
                <button mat-icon-button [matMenuTriggerFor]="userMenu" [matMenuTriggerData]="{user: user}">
                  <mat-icon>more_vert</mat-icon>
                </button>
              </mat-card-actions>
            </mat-card>
          </div>
        </div>
      </mat-sidenav-content>
    </mat-sidenav-container>

    <mat-menu #userMenu="matMenu">
      <ng-template matMenuContent let-user="user">
        <button mat-menu-item (click)="viewUser(user)">
          <mat-icon>visibility</mat-icon>
          <span>View Details</span>
        </button>
        <button mat-menu-item (click)="editUser(user)">
          <mat-icon>edit</mat-icon>
          <span>Edit User</span>
        </button>
        <button mat-menu-item (click)="toggleUserStatus(user)">
          <mat-icon>{{ user.isActive ? 'block' : 'check_circle' }}</mat-icon>
          <span>{{ user.isActive ? 'Deactivate' : 'Activate' }}</span>
        </button>
        <button mat-menu-item (click)="deleteUser(user)" class="delete-action">
          <mat-icon>delete</mat-icon>
          <span>Delete User</span>
        </button>
      </ng-template>
    </mat-menu>
  `,
  styles: [`
    .sidenav-container {
      height: 100vh;
    }

    .sidenav {
      width: 250px;
    }

    .sidenav .mat-toolbar {
      background: inherit;
    }

    .mat-toolbar.mat-primary {
      position: sticky;
      top: 0;
      z-index: 1;
    }

    .spacer {
      flex: 1 1 auto;
    }

    .content {
      padding: 2rem;
    }

    .header-actions {
      margin-bottom: 2rem;
    }

    .search-field {
      width: 300px;
    }

    .loading-container {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 4rem;
    }

    .users-container {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
      gap: 1rem;
    }

    .user-card {
      height: 100%;
    }

    .user-avatar {
      width: 50px;
      height: 50px;
      border-radius: 50%;
      overflow: hidden;
    }

    .user-avatar img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .user-avatar mat-icon {
      font-size: 2rem;
      width: 2rem;
      height: 2rem;
      color: #ccc;
    }

    .delete-action {
      color: #f44336;
    }

    .active {
      background-color: rgba(25, 118, 210, 0.1);
    }

    @media (max-width: 768px) {
      .users-container {
        grid-template-columns: 1fr;
      }
    }
  `]
})
export class UserManagementComponent implements OnInit {
  users: User[] = [];
  filteredUsers: User[] = [];
  searchTerm = '';
  isLoading = true;

  constructor(
    private authService: AuthService,
    private apiService: ApiService,
    private snackBar: MatSnackBar,
    private dialog: MatDialog
  ) {}

  ngOnInit() {
    this.loadUsers();
  }

  loadUsers() {
    this.isLoading = true;
    this.apiService.getUsers().subscribe({
      next: (users) => {
        this.users = users;
        this.filteredUsers = users;
        this.isLoading = false;
      },
      error: () => {
        this.isLoading = false;
        this.snackBar.open('Failed to load users', 'Close', { duration: 3000 });
      }
    });
  }

  searchUsers() {
    if (!this.searchTerm.trim()) {
      this.filteredUsers = this.users;
      return;
    }

    this.apiService.searchUsers(this.searchTerm).subscribe({
      next: (users) => {
        this.filteredUsers = users;
      },
      error: () => {
        this.snackBar.open('Search failed', 'Close', { duration: 3000 });
      }
    });
  }

  viewUser(user: User) {
    this.snackBar.open(`Viewing user: ${user.username}`, 'Close', { duration: 3000 });
  }

  editUser(user: User) {
    this.snackBar.open(`Edit user: ${user.username}`, 'Close', { duration: 3000 });
  }

  toggleUserStatus(user: User) {
    const action = user.isActive ? 'deactivate' : 'activate';
    if (confirm(`Are you sure you want to ${action} this user?`)) {
      this.snackBar.open(`User ${action}d successfully`, 'Close', { duration: 3000 });
      user.isActive = !user.isActive;
    }
  }

  deleteUser(user: User) {
    if (confirm(`Are you sure you want to delete user: ${user.username}?`)) {
      this.apiService.deleteUser(user.userId).subscribe({
        next: () => {
          this.users = this.users.filter(u => u.userId !== user.userId);
          this.filteredUsers = this.filteredUsers.filter(u => u.userId !== user.userId);
          this.snackBar.open('User deleted successfully', 'Close', { duration: 3000 });
        },
        error: () => {
          this.snackBar.open('Failed to delete user', 'Close', { duration: 3000 });
        }
      });
    }
  }

  formatDate(dateString: string): string {
    return new Date(dateString).toLocaleDateString();
  }

  logout() {
    this.authService.logout();
    this.snackBar.open('Logged out successfully', 'Close', { duration: 3000 });
  }
}

