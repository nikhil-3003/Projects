import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTooltipModule } from '@angular/material/tooltip';
import { AuthService } from '../../../services/auth.service';
import { ApiService } from '../../../services/api.service';
import { User } from '../../../models/user.model';
import { Post } from '../../../models/post.model';
import { Report } from '../../../models/report.model';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatToolbarModule,
    MatSidenavModule,
    MatListModule,
    MatSnackBarModule,
    MatProgressSpinnerModule,
    MatTooltipModule
  ],
  template: `
    <mat-sidenav-container class="sidenav-container">
      <mat-sidenav #drawer class="sidenav" fixedInViewport
          [attr.role]="'navigation'"
          [mode]="'over'"
          [opened]="false">
        <mat-toolbar class="sidenav-toolbar">
          <mat-icon class="admin-logo-icon">admin_panel_settings</mat-icon>
          <span class="admin-logo-text">Admin Panel</span>
        </mat-toolbar>
        <mat-nav-list class="nav-list">
          <!-- Dashboard Section -->
          <div class="nav-section">
            <div class="nav-section-title">Overview</div>
            <a mat-list-item routerLink="/admin" routerLinkActive="active">
              <mat-icon matListItemIcon>dashboard</mat-icon>
              <span matListItemTitle>Dashboard</span>
            </a>
          </div>

          <!-- Management Section -->
          <div class="nav-section">
            <div class="nav-section-title">Management</div>
            <a mat-list-item routerLink="/admin/users" routerLinkActive="active">
              <mat-icon matListItemIcon>people</mat-icon>
              <span matListItemTitle>Users</span>
            </a>
            <a mat-list-item routerLink="/admin/posts" routerLinkActive="active">
              <mat-icon matListItemIcon>article</mat-icon>
              <span matListItemTitle>Posts</span>
            </a>
            <a mat-list-item routerLink="/admin/groups" routerLinkActive="active">
              <mat-icon matListItemIcon>group</mat-icon>
              <span matListItemTitle>Groups</span>
            </a>
          </div>

          <!-- Moderation Section -->
          <div class="nav-section">
            <div class="nav-section-title">Moderation</div>
            <a mat-list-item routerLink="/admin/reports" routerLinkActive="active">
              <mat-icon matListItemIcon>report_problem</mat-icon>
              <span matListItemTitle>Reports</span>
            </a>
          </div>

          <!-- Navigation Section -->
          <div class="nav-section">
            <div class="nav-section-title">Navigation</div>
            <a mat-list-item routerLink="/dashboard">
              <mat-icon matListItemIcon>home</mat-icon>
              <span matListItemTitle>Back to App</span>
            </a>
          </div>
        </mat-nav-list>
      </mat-sidenav>
      
      <mat-sidenav-content>
        <mat-toolbar color="primary" class="main-toolbar">
          <button
            type="button"
            aria-label="Toggle sidenav"
            mat-icon-button
            (click)="drawer.toggle()"
            class="menu-button">
            <mat-icon>menu</mat-icon>
          </button>
          
          <div class="toolbar-title">
            <mat-icon class="title-icon">admin_panel_settings</mat-icon>
            <span class="title-text">Admin Dashboard</span>
          </div>
          
          <span class="spacer"></span>
          
          <div class="toolbar-actions">
            <div class="admin-badge">
              <mat-icon class="admin-icon">verified_user</mat-icon>
              <span class="admin-text">Administrator</span>
            </div>
            
            <div class="user-info">
              <mat-icon class="user-icon">person</mat-icon>
              <span class="username">{{ currentUser?.username }}</span>
            </div>
            
            <button mat-icon-button 
                    (click)="logout()" 
                    matTooltip="Logout"
                    class="logout-button">
              <mat-icon>logout</mat-icon>
            </button>
          </div>
        </mat-toolbar>
        
        <div class="content">
          <!-- Loading State -->
          <div *ngIf="isLoading" class="loading-container">
            <div class="loading-content">
              <mat-spinner diameter="60"></mat-spinner>
              <h3>Loading Admin Dashboard</h3>
              <p>Gathering system statistics and recent activity...</p>
            </div>
          </div>

          <!-- Dashboard Content -->
          <div *ngIf="!isLoading" class="dashboard-content">
            <!-- Header Section -->
            <div class="dashboard-header">
              <div class="header-content">
                <h1 class="dashboard-title">
                  <mat-icon class="dashboard-icon">admin_panel_settings</mat-icon>
                  Admin Dashboard
                </h1>
                <p class="dashboard-subtitle">Monitor platform activity and manage system operations</p>
              </div>
            </div>

            <!-- Statistics Overview -->
            <div class="stats-section">
              <h2 class="section-title">Platform Statistics</h2>
              <div class="stats-grid">
                <mat-card class="stat-card users-card">
                  <div class="stat-icon">
                    <mat-icon>people</mat-icon>
                  </div>
                  <mat-card-content>
                    <div class="stat-number">{{ stats.totalUsers }}</div>
                    <div class="stat-label">Total Users</div>
                    <div class="stat-trend">
                      <mat-icon class="trend-icon">trending_up</mat-icon>
                      <span class="trend-text">+12% this month</span>
                    </div>
                  </mat-card-content>
                </mat-card>

                <mat-card class="stat-card posts-card">
                  <div class="stat-icon">
                    <mat-icon>article</mat-icon>
                  </div>
                  <mat-card-content>
                    <div class="stat-number">{{ stats.pendingPosts }}</div>
                    <div class="stat-label">Pending Posts</div>
                    <div class="stat-trend">
                      <mat-icon class="trend-icon">schedule</mat-icon>
                      <span class="trend-text">Awaiting review</span>
                    </div>
                  </mat-card-content>
                </mat-card>

                <mat-card class="stat-card reports-card">
                  <div class="stat-icon">
                    <mat-icon>report_problem</mat-icon>
                  </div>
                  <mat-card-content>
                    <div class="stat-number">{{ stats.pendingReports }}</div>
                    <div class="stat-label">Pending Reports</div>
                    <div class="stat-trend">
                      <mat-icon class="trend-icon">priority_high</mat-icon>
                      <span class="trend-text">Requires attention</span>
                    </div>
                  </mat-card-content>
                </mat-card>

                <mat-card class="stat-card groups-card">
                  <div class="stat-icon">
                    <mat-icon>group</mat-icon>
                  </div>
                  <mat-card-content>
                    <div class="stat-number">{{ stats.totalGroups }}</div>
                    <div class="stat-label">Active Groups</div>
                    <div class="stat-trend">
                      <mat-icon class="trend-icon">group_add</mat-icon>
                      <span class="trend-text">+3 this week</span>
                    </div>
                  </mat-card-content>
                </mat-card>
              </div>
            </div>

            <!-- Quick Actions -->
            <div class="actions-section">
              <h2 class="section-title">Quick Actions</h2>
              <div class="actions-grid">
                <mat-card class="action-card users-action" routerLink="/admin/users">
                  <div class="card-icon">
                    <mat-icon>people</mat-icon>
                  </div>
                  <mat-card-header>
                    <mat-card-title>User Management</mat-card-title>
                    <mat-card-subtitle>Manage & Monitor</mat-card-subtitle>
                  </mat-card-header>
                  <mat-card-content>
                    <p>View user profiles, manage permissions, and handle user-related issues across the platform.</p>
                  </mat-card-content>
                  <mat-card-actions>
                    <button mat-raised-button color="primary" class="action-button">
                      <mat-icon>manage_accounts</mat-icon>
                      Manage Users
                    </button>
                  </mat-card-actions>
                </mat-card>

                <mat-card class="action-card posts-action" routerLink="/admin/posts">
                  <div class="card-icon">
                    <mat-icon>article</mat-icon>
                  </div>
                  <mat-card-header>
                    <mat-card-title>Content Moderation</mat-card-title>
                    <mat-card-subtitle>Review & Approve</mat-card-subtitle>
                  </mat-card-header>
                  <mat-card-content>
                    <p>Review and approve user-generated content, moderate posts, and ensure platform guidelines.</p>
                  </mat-card-content>
                  <mat-card-actions>
                    <button mat-raised-button color="accent" class="action-button">
                      <mat-icon>rate_review</mat-icon>
                      Review Posts
                    </button>
                  </mat-card-actions>
                </mat-card>

                <mat-card class="action-card reports-action" routerLink="/admin/reports">
                  <div class="card-icon">
                    <mat-icon>report_problem</mat-icon>
                  </div>
                  <mat-card-header>
                    <mat-card-title>Report Center</mat-card-title>
                    <mat-card-subtitle>Investigate & Resolve</mat-card-subtitle>
                  </mat-card-header>
                  <mat-card-content>
                    <p>Handle user reports, investigate violations, and take appropriate moderation actions.</p>
                  </mat-card-content>
                  <mat-card-actions>
                    <button mat-raised-button color="warn" class="action-button">
                      <mat-icon>gavel</mat-icon>
                      Handle Reports
                    </button>
                  </mat-card-actions>
                </mat-card>

                <mat-card class="action-card groups-action" routerLink="/admin/groups">
                  <div class="card-icon">
                    <mat-icon>group</mat-icon>
                  </div>
                  <mat-card-header>
                    <mat-card-title>Group Administration</mat-card-title>
                    <mat-card-subtitle>Create & Manage</mat-card-subtitle>
                  </mat-card-header>
                  <mat-card-content>
                    <p>Create and manage user groups, set permissions, and oversee group activities.</p>
                  </mat-card-content>
                  <mat-card-actions>
                    <button mat-raised-button class="action-button groups-button">
                      <mat-icon>group_add</mat-icon>
                      Manage Groups
                    </button>
                  </mat-card-actions>
                </mat-card>
              </div>
            </div>

            <!-- Recent Activity -->
            <div class="activity-section">
              <h2 class="section-title">Recent Activity</h2>
              <mat-card class="activity-card">
                <mat-card-header>
                  <mat-card-title>
                    <mat-icon>history</mat-icon>
                    System Activity Log
                  </mat-card-title>
                </mat-card-header>
                <mat-card-content>
                  <div *ngIf="recentActivity.length === 0" class="no-activity">
                    <mat-icon class="no-activity-icon">inbox</mat-icon>
                    <h3>No Recent Activity</h3>
                    <p>System activity will appear here as events occur.</p>
                  </div>
                  <div *ngFor="let activity of recentActivity; let i = index" 
                       class="activity-item" 
                       [class]="'activity-item-' + i">
                    <div class="activity-icon">
                      <mat-icon>{{ activity.icon }}</mat-icon>
                    </div>
                    <div class="activity-content">
                      <p class="activity-message">{{ activity.message }}</p>
                      <span class="activity-time">{{ activity.time }}</span>
                    </div>
                    <div class="activity-status">
                      <mat-icon class="status-icon">fiber_manual_record</mat-icon>
                    </div>
                  </div>
                </mat-card-content>
              </mat-card>
            </div>
          </div>
        </div>
      </mat-sidenav-content>
    </mat-sidenav-container>
  `,
  styles: [`
    .sidenav-container {
      height: 100vh;
      background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
    }

    .sidenav {
      width: 280px;
      background: linear-gradient(180deg, #2c3e50 0%, #34495e 100%);
      box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
    }

    .sidenav-toolbar {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      padding: 1rem;
      display: flex;
      align-items: center;
      gap: 1rem;
    }

    .admin-logo-icon {
      font-size: 2rem;
      width: 2rem;
      height: 2rem;
    }

    .admin-logo-text {
      font-size: 1.2rem;
      font-weight: 600;
    }

    .nav-list {
      padding: 1rem 0;
    }

    .nav-section {
      margin-bottom: 1.5rem;
    }

    .nav-section-title {
      color: #bdc3c7;
      font-size: 0.8rem;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 1px;
      padding: 0.5rem 1rem;
      margin-bottom: 0.5rem;
    }

    .nav-list .mat-mdc-list-item {
      color: #ecf0f1;
      margin: 0.25rem 0.5rem;
      border-radius: 8px;
      transition: all 0.3s ease;
    }

    .nav-list .mat-mdc-list-item:hover {
      background: rgba(255, 255, 255, 0.1);
      transform: translateX(5px);
    }

    .nav-list .mat-mdc-list-item.active {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      box-shadow: 0 2px 8px rgba(102, 126, 234, 0.3);
    }

    .nav-list .mat-icon {
      color: #bdc3c7;
    }

    .nav-list .mat-mdc-list-item.active .mat-icon {
      color: white;
    }

    .main-toolbar {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      position: sticky;
      top: 0;
      z-index: 1000;
    }

    .menu-button {
      color: white;
    }

    .toolbar-title {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      margin-left: 1rem;
    }

    .title-icon {
      font-size: 1.5rem;
      width: 1.5rem;
      height: 1.5rem;
    }

    .title-text {
      font-size: 1.3rem;
      font-weight: 600;
    }

    .spacer {
      flex: 1 1 auto;
    }

    .toolbar-actions {
      display: flex;
      align-items: center;
      gap: 1rem;
    }

    .admin-badge {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      background: rgba(255, 255, 255, 0.1);
      padding: 0.5rem 1rem;
      border-radius: 20px;
      font-size: 0.9rem;
    }

    .admin-icon {
      font-size: 1rem;
      width: 1rem;
      height: 1rem;
    }

    .user-info {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      font-size: 0.9rem;
    }

    .user-icon {
      font-size: 1rem;
      width: 1rem;
      height: 1rem;
    }

    .logout-button {
      color: white;
    }

    .content {
      padding: 2rem;
      background: transparent;
    }

    .loading-container {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 4rem;
      background: white;
      border-radius: 15px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    }

    .loading-content {
      text-align: center;
    }

    .loading-content h3 {
      color: #667eea;
      margin: 1rem 0 0.5rem 0;
    }

    .loading-content p {
      color: #666;
      margin: 0;
    }

    .dashboard-header {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      border-radius: 15px;
      padding: 2rem;
      margin-bottom: 2rem;
      color: white;
      box-shadow: 0 10px 30px rgba(102, 126, 234, 0.3);
    }

    .header-content {
      text-align: center;
    }

    .dashboard-title {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 1rem;
      font-size: 2.5rem;
      font-weight: 700;
      margin: 0 0 1rem 0;
      text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
    }

    .dashboard-icon {
      font-size: 3rem;
      width: 3rem;
      height: 3rem;
    }

    .dashboard-subtitle {
      font-size: 1.2rem;
      opacity: 0.9;
      margin: 0;
    }

    .stats-section {
      margin-bottom: 3rem;
    }

    .section-title {
      color: #2c3e50;
      font-size: 1.8rem;
      font-weight: 600;
      margin-bottom: 1.5rem;
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }

    .section-title::before {
      content: '';
      width: 4px;
      height: 1.8rem;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      border-radius: 2px;
    }

    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 1.5rem;
      margin-bottom: 2rem;
    }

    .stat-card {
      background: white;
      border-radius: 15px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
      transition: all 0.3s ease;
      position: relative;
      overflow: hidden;
    }

    .stat-card::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      height: 4px;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    }

    .stat-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 15px 40px rgba(0, 0, 0, 0.15);
    }

    .stat-card.users-card::before {
      background: linear-gradient(135deg, #4CAF50 0%, #45a049 100%);
    }

    .stat-card.posts-card::before {
      background: linear-gradient(135deg, #FF9800 0%, #F57C00 100%);
    }

    .stat-card.reports-card::before {
      background: linear-gradient(135deg, #F44336 0%, #D32F2F 100%);
    }

    .stat-card.groups-card::before {
      background: linear-gradient(135deg, #9C27B0 0%, #7B1FA2 100%);
    }

    .stat-icon {
      position: absolute;
      top: 1rem;
      right: 1rem;
      font-size: 2.5rem;
      width: 2.5rem;
      height: 2.5rem;
      opacity: 0.1;
    }

    .stat-card.users-card .stat-icon {
      color: #4CAF50;
    }

    .stat-card.posts-card .stat-icon {
      color: #FF9800;
    }

    .stat-card.reports-card .stat-icon {
      color: #F44336;
    }

    .stat-card.groups-card .stat-icon {
      color: #9C27B0;
    }

    .stat-card mat-card-content {
      padding: 1.5rem;
      position: relative;
    }

    .stat-number {
      font-size: 2.5rem;
      font-weight: 700;
      color: #2c3e50;
      margin-bottom: 0.5rem;
    }

    .stat-label {
      font-size: 1rem;
      color: #666;
      margin-bottom: 1rem;
    }

    .stat-trend {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      font-size: 0.9rem;
      color: #666;
    }

    .trend-icon {
      font-size: 1rem;
      width: 1rem;
      height: 1rem;
    }

    .actions-section {
      margin-bottom: 3rem;
    }

    .actions-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 1.5rem;
    }

    .action-card {
      background: white;
      border-radius: 15px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
      transition: all 0.3s ease;
      cursor: pointer;
      position: relative;
      overflow: hidden;
    }

    .action-card::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      height: 4px;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    }

    .action-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 15px 40px rgba(0, 0, 0, 0.15);
    }

    .action-card.users-action::before {
      background: linear-gradient(135deg, #2196F3 0%, #1976D2 100%);
    }

    .action-card.posts-action::before {
      background: linear-gradient(135deg, #FF9800 0%, #F57C00 100%);
    }

    .action-card.reports-action::before {
      background: linear-gradient(135deg, #F44336 0%, #D32F2F 100%);
    }

    .action-card.groups-action::before {
      background: linear-gradient(135deg, #4CAF50 0%, #388E3C 100%);
    }

    .card-icon {
      position: absolute;
      top: 1rem;
      right: 1rem;
      font-size: 2rem;
      width: 2rem;
      height: 2rem;
      opacity: 0.1;
    }

    .action-card.users-action .card-icon {
      color: #2196F3;
    }

    .action-card.posts-action .card-icon {
      color: #FF9800;
    }

    .action-card.reports-action .card-icon {
      color: #F44336;
    }

    .action-card.groups-action .card-icon {
      color: #4CAF50;
    }

    .action-card mat-card-header {
      padding: 1.5rem 1.5rem 0.5rem 1.5rem;
    }

    .action-card mat-card-title {
      color: #2c3e50;
      font-size: 1.3rem;
      font-weight: 600;
    }

    .action-card mat-card-subtitle {
      color: #666;
      font-size: 0.9rem;
    }

    .action-card mat-card-content {
      padding: 0 1.5rem 1rem 1.5rem;
    }

    .action-card mat-card-content p {
      color: #666;
      line-height: 1.5;
      margin: 0;
    }

    .action-card mat-card-actions {
      padding: 0 1.5rem 1.5rem 1.5rem;
    }

    .action-button {
      width: 100%;
      height: 45px;
      font-weight: 600;
      border-radius: 25px;
    }

    .groups-button {
      background: linear-gradient(135deg, #4CAF50 0%, #388E3C 100%);
      color: white;
    }

    .activity-section {
      margin-bottom: 2rem;
    }

    .activity-card {
      background: white;
      border-radius: 15px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    }

    .activity-card mat-card-header {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      border-radius: 15px 15px 0 0;
      padding: 1rem 1.5rem;
    }

    .activity-card mat-card-title {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      margin: 0;
      font-size: 1.2rem;
      font-weight: 600;
    }

    .activity-card mat-card-content {
      padding: 1.5rem;
    }

    .no-activity {
      text-align: center;
      padding: 3rem 2rem;
      color: #666;
    }

    .no-activity-icon {
      font-size: 4rem;
      width: 4rem;
      height: 4rem;
      color: #bdc3c7;
      margin-bottom: 1rem;
    }

    .no-activity h3 {
      color: #2c3e50;
      margin: 0 0 0.5rem 0;
    }

    .no-activity p {
      margin: 0;
    }

    .activity-item {
      display: flex;
      align-items: center;
      gap: 1rem;
      padding: 1rem 0;
      border-bottom: 1px solid #f0f0f0;
      transition: all 0.3s ease;
    }

    .activity-item:last-child {
      border-bottom: none;
    }

    .activity-item:hover {
      background: #f8f9fa;
      border-radius: 8px;
      padding: 1rem;
      margin: 0 -1rem;
    }

    .activity-icon {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      border-radius: 50%;
      padding: 0.5rem;
      font-size: 1.2rem;
      width: 2.5rem;
      height: 2.5rem;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .activity-content {
      flex: 1;
    }

    .activity-message {
      margin: 0 0 0.25rem 0;
      font-weight: 500;
      color: #2c3e50;
    }

    .activity-time {
      font-size: 0.8rem;
      color: #666;
    }

    .activity-status {
      color: #4CAF50;
    }

    .status-icon {
      font-size: 0.8rem;
      width: 0.8rem;
      height: 0.8rem;
    }

    /* Responsive Design */
    @media (max-width: 1200px) {
      .stats-grid {
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      }

      .actions-grid {
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      }
    }

    @media (max-width: 768px) {
      .sidenav {
        width: 250px;
      }

      .content {
        padding: 1rem;
      }

      .dashboard-header {
        padding: 1.5rem;
        margin-bottom: 1.5rem;
      }

      .dashboard-title {
        font-size: 2rem;
        flex-direction: column;
        gap: 0.5rem;
      }

      .dashboard-icon {
        font-size: 2.5rem;
        width: 2.5rem;
        height: 2.5rem;
      }

      .dashboard-subtitle {
        font-size: 1rem;
      }

      .section-title {
        font-size: 1.5rem;
      }

      .stats-grid {
        grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
        gap: 1rem;
      }

      .stat-card mat-card-content {
        padding: 1rem;
      }

      .stat-number {
        font-size: 2rem;
      }

      .actions-grid {
        grid-template-columns: 1fr;
        gap: 1rem;
      }

      .toolbar-actions {
        gap: 0.5rem;
      }

      .admin-badge {
        display: none;
      }

      .user-info {
        font-size: 0.8rem;
      }
    }

    @media (max-width: 480px) {
      .sidenav {
        width: 100%;
      }

      .content {
        padding: 0.5rem;
      }

      .dashboard-header {
        padding: 1rem;
        margin-bottom: 1rem;
      }

      .dashboard-title {
        font-size: 1.5rem;
      }

      .dashboard-icon {
        font-size: 2rem;
        width: 2rem;
        height: 2rem;
      }

      .dashboard-subtitle {
        font-size: 0.9rem;
      }

      .section-title {
        font-size: 1.3rem;
      }

      .stats-grid {
        grid-template-columns: 1fr 1fr;
        gap: 0.5rem;
      }

      .stat-card mat-card-content {
        padding: 0.75rem;
      }

      .stat-number {
        font-size: 1.5rem;
      }

      .stat-label {
        font-size: 0.8rem;
      }

      .actions-grid {
        gap: 0.5rem;
      }

      .action-card mat-card-header {
        padding: 1rem 1rem 0.25rem 1rem;
      }

      .action-card mat-card-content {
        padding: 0 1rem 0.5rem 1rem;
      }

      .action-card mat-card-actions {
        padding: 0 1rem 1rem 1rem;
      }

      .action-card mat-card-title {
        font-size: 1.1rem;
      }

      .action-card mat-card-subtitle {
        font-size: 0.8rem;
      }

      .action-button {
        height: 40px;
        font-size: 0.9rem;
      }

      .activity-card mat-card-content {
        padding: 1rem;
      }

      .activity-item {
        padding: 0.75rem 0;
      }

      .activity-icon {
        width: 2rem;
        height: 2rem;
        font-size: 1rem;
      }

      .activity-message {
        font-size: 0.9rem;
      }

      .activity-time {
        font-size: 0.7rem;
      }
    }
  `]
})
export class AdminDashboardComponent implements OnInit {
  currentUser: User | null = null;
  isLoading = true;
  stats = {
    totalUsers: 0,
    pendingPosts: 0,
    pendingReports: 0,
    totalGroups: 0
  };
  recentActivity: any[] = [];

  constructor(
    private authService: AuthService,
    private apiService: ApiService,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
    
    this.loadDashboardData();
  }

  loadDashboardData() {
    this.isLoading = true;
    
    // Load users
    this.apiService.getUsers().subscribe({
      next: (users) => {
        this.stats.totalUsers = users.length;
      },
      error: () => {
        this.snackBar.open('Failed to load users', 'Close', { duration: 3000 });
      }
    });

    // Load pending posts
    this.apiService.getPendingPosts().subscribe({
      next: (posts) => {
        this.stats.pendingPosts = posts.length;
      },
      error: () => {
        this.snackBar.open('Failed to load pending posts', 'Close', { duration: 3000 });
      }
    });

    // Load pending reports
    this.apiService.getPendingReports().subscribe({
      next: (reports) => {
        this.stats.pendingReports = reports.length;
      },
      error: () => {
        this.snackBar.open('Failed to load pending reports', 'Close', { duration: 3000 });
      }
    });

    // Load groups
    this.apiService.getGroups().subscribe({
      next: (groups) => {
        this.stats.totalGroups = groups.length;
        this.isLoading = false;
      },
      error: () => {
        this.snackBar.open('Failed to load groups', 'Close', { duration: 3000 });
        this.isLoading = false;
      }
    });

    // Mock recent activity
    this.recentActivity = [
      {
        icon: 'person_add',
        message: 'New user registered: john_doe',
        time: '2 hours ago'
      },
      {
        icon: 'article',
        message: 'Post approved: "My vacation photos"',
        time: '4 hours ago'
      },
      {
        icon: 'report_problem',
        message: 'New report submitted against user: spam_user',
        time: '6 hours ago'
      }
    ];
  }

  logout() {
    this.authService.logout();
    this.snackBar.open('Logged out successfully', 'Close', { duration: 3000 });
  }
}

