import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatChipsModule } from '@angular/material/chips';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatMenuModule } from '@angular/material/menu';
import { MatBadgeModule } from '@angular/material/badge';
import { AuthService } from '../../services/auth.service';
import { ApiService } from '../../services/api.service';
import { Notification } from '../../models/notification.model';
import { User } from '../../models/user.model';

@Component({
  selector: 'app-notifications',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatToolbarModule,
    MatSidenavModule,
    MatListModule,
    MatSnackBarModule,
    MatProgressSpinnerModule,
    MatChipsModule,
    MatTooltipModule,
    MatMenuModule,
    MatBadgeModule
  ],
  template: `
    <mat-sidenav-container class="sidenav-container">
      <mat-sidenav #drawer class="sidenav" fixedInViewport
          [attr.role]="'navigation'"
          [mode]="'over'"
          [opened]="false">
        <mat-toolbar>ProfileBook</mat-toolbar>
        <mat-nav-list>
          <a mat-list-item routerLink="/dashboard" routerLinkActive="active">
            <mat-icon matListItemIcon>dashboard</mat-icon>
            <span matListItemTitle>Dashboard</span>
          </a>
          <a mat-list-item routerLink="/posts" routerLinkActive="active">
            <mat-icon matListItemIcon>article</mat-icon>
            <span matListItemTitle>Posts</span>
          </a>
          <a mat-list-item routerLink="/messages" routerLinkActive="active">
            <mat-icon matListItemIcon>message</mat-icon>
            <span matListItemTitle>Messages</span>
          </a>
          <a mat-list-item routerLink="/profile" routerLinkActive="active">
            <mat-icon matListItemIcon>person</mat-icon>
            <span matListItemTitle>Profile</span>
          </a>
        </mat-nav-list>
      </mat-sidenav>
      <mat-sidenav-content>
        <mat-toolbar color="primary">
          <button
            type="button"
            aria-label="Toggle sidenav"
            mat-icon-button
            (click)="drawer.toggle()">
            <mat-icon aria-label="Side nav toggle icon">menu</mat-icon>
          </button>
          <span>Notifications</span>
          <span class="spacer"></span>
          <button mat-icon-button (click)="markAllAsRead()" 
                  [disabled]="unreadCount === 0" matTooltip="Mark all as read">
            <mat-icon>done_all</mat-icon>
          </button>
          <button mat-icon-button (click)="logout()" matTooltip="Logout">
            <mat-icon>logout</mat-icon>
          </button>
        </mat-toolbar>
        
        <div class="content">
          <div *ngIf="isLoading" class="loading-container">
            <mat-spinner></mat-spinner>
            <p>Loading notifications...</p>
          </div>

          <div *ngIf="!isLoading" class="notifications-container">
            <!-- Header -->
            <div class="notifications-header">
              <h1>Notifications</h1>
              <div class="header-actions">
                <span class="unread-count" *ngIf="unreadCount > 0">
                  {{ unreadCount }} unread
                </span>
                <button mat-button (click)="markAllAsRead()" [disabled]="unreadCount === 0">
                  Mark all as read
                </button>
              </div>
            </div>

            <!-- Notifications List -->
            <div *ngIf="notifications.length === 0" class="no-notifications">
              <mat-icon>notifications_none</mat-icon>
              <h3>No notifications</h3>
              <p>You're all caught up! Check back later for updates.</p>
            </div>

            <mat-list *ngIf="notifications.length > 0" class="notifications-list">
              <mat-list-item *ngFor="let notification of notifications" 
                             [class.unread]="!notification.isRead"
                             class="notification-item">
                <div mat-list-avatar class="notification-icon">
                  <mat-icon [ngClass]="getNotificationIcon(notification.type)">
                    {{ getNotificationIcon(notification.type) }}
                  </mat-icon>
                </div>
                <div mat-line class="notification-content">
                  <div class="notification-header">
                    <h4>{{ notification.title }}</h4>
                    <span class="notification-time">{{ formatDate(notification.createdAt) }}</span>
                  </div>
                  <p class="notification-message">{{ notification.message }}</p>
                </div>
                <div mat-line class="notification-actions">
                  <button mat-icon-button (click)="markAsRead(notification)" 
                          *ngIf="!notification.isRead" matTooltip="Mark as read">
                    <mat-icon>done</mat-icon>
                  </button>
                  <button mat-icon-button (click)="deleteNotification(notification)" 
                          matTooltip="Delete">
                    <mat-icon>delete</mat-icon>
                  </button>
                </div>
              </mat-list-item>
            </mat-list>
          </div>
        </div>
      </mat-sidenav-content>
    </mat-sidenav-container>
  `,
  styles: [`
    .sidenav-container {
      height: 100vh;
    }

    .sidenav {
      width: 250px;
    }

    .sidenav .mat-toolbar {
      background: inherit;
    }

    .mat-toolbar.mat-primary {
      position: sticky;
      top: 0;
      z-index: 1;
    }

    .spacer {
      flex: 1 1 auto;
    }

    .content {
      padding: 2rem;
    }

    .loading-container {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 4rem;
    }

    .notifications-container {
      max-width: 800px;
      margin: 0 auto;
    }

    .notifications-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 2rem;
    }

    .notifications-header h1 {
      color: #1976d2;
      margin: 0;
    }

    .header-actions {
      display: flex;
      align-items: center;
      gap: 1rem;
    }

    .unread-count {
      background-color: #f44336;
      color: white;
      padding: 4px 8px;
      border-radius: 12px;
      font-size: 0.8rem;
      font-weight: 500;
    }

    .no-notifications {
      text-align: center;
      padding: 4rem;
      color: #666;
    }

    .no-notifications mat-icon {
      font-size: 4rem;
      width: 4rem;
      height: 4rem;
      margin-bottom: 1rem;
      color: #ccc;
    }

    .notifications-list {
      background: white;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    .notification-item {
      border-bottom: 1px solid #eee;
      padding: 1rem;
    }

    .notification-item:last-child {
      border-bottom: none;
    }

    .notification-item.unread {
      background-color: #f8f9fa;
      border-left: 4px solid #1976d2;
    }

    .notification-icon {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      background-color: #e3f2fd;
    }

    .notification-icon mat-icon {
      color: #1976d2;
    }

    .notification-content {
      flex: 1;
      margin-left: 1rem;
    }

    .notification-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 0.5rem;
    }

    .notification-header h4 {
      margin: 0;
      font-size: 1rem;
      font-weight: 500;
    }

    .notification-time {
      font-size: 0.8rem;
      color: #666;
    }

    .notification-message {
      margin: 0;
      color: #666;
      line-height: 1.4;
    }

    .notification-actions {
      display: flex;
      gap: 0.5rem;
    }

    .active {
      background-color: rgba(25, 118, 210, 0.1);
    }

    @media (max-width: 768px) {
      .notifications-header {
        flex-direction: column;
        align-items: flex-start;
        gap: 1rem;
      }

      .header-actions {
        width: 100%;
        justify-content: space-between;
      }
    }
  `]
})
export class NotificationsComponent implements OnInit {
  notifications: Notification[] = [];
  unreadCount = 0;
  isLoading = true;
  currentUser: User | null = null;

  constructor(
    private authService: AuthService,
    private apiService: ApiService,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
    this.loadNotifications();
  }

  loadNotifications() {
    this.isLoading = true;
    this.apiService.getNotifications().subscribe({
      next: (notifications) => {
        this.notifications = notifications;
        this.unreadCount = notifications.filter(n => !n.isRead).length;
        this.isLoading = false;
      },
      error: () => {
        this.isLoading = false;
        this.snackBar.open('Failed to load notifications', 'Close', { duration: 3000 });
      }
    });
  }

  markAsRead(notification: Notification) {
    this.apiService.markAsRead(notification.notificationId).subscribe({
      next: () => {
        notification.isRead = true;
        this.unreadCount = this.notifications.filter(n => !n.isRead).length;
        this.snackBar.open('Notification marked as read', 'Close', { duration: 2000 });
      },
      error: () => {
        this.snackBar.open('Failed to mark notification as read', 'Close', { duration: 3000 });
      }
    });
  }

  markAllAsRead() {
    this.apiService.markAllAsRead().subscribe({
      next: () => {
        this.notifications.forEach(n => n.isRead = true);
        this.unreadCount = 0;
        this.snackBar.open('All notifications marked as read', 'Close', { duration: 2000 });
      },
      error: () => {
        this.snackBar.open('Failed to mark all notifications as read', 'Close', { duration: 3000 });
      }
    });
  }

  deleteNotification(notification: Notification) {
    this.apiService.deleteNotification(notification.notificationId).subscribe({
      next: () => {
        this.notifications = this.notifications.filter(n => n.notificationId !== notification.notificationId);
        this.unreadCount = this.notifications.filter(n => !n.isRead).length;
        this.snackBar.open('Notification deleted', 'Close', { duration: 2000 });
      },
      error: () => {
        this.snackBar.open('Failed to delete notification', 'Close', { duration: 3000 });
      }
    });
  }

  getNotificationIcon(type: string): string {
    switch (type.toLowerCase()) {
      case 'like': return 'favorite';
      case 'comment': return 'comment';
      case 'message': return 'message';
      case 'postapproval': return 'check_circle';
      case 'friend': return 'person_add';
      default: return 'notifications';
    }
  }

  formatDate(dateString: string): string {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60);

    if (diffInHours < 1) {
      return 'Just now';
    } else if (diffInHours < 24) {
      return `${Math.floor(diffInHours)}h ago`;
    } else if (diffInHours < 168) {
      return `${Math.floor(diffInHours / 24)}d ago`;
    } else {
      return date.toLocaleDateString();
    }
  }

  logout() {
    this.authService.logout();
    this.snackBar.open('Logged out successfully', 'Close', { duration: 3000 });
  }
}

