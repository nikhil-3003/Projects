import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatChipsModule } from '@angular/material/chips';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatTabsModule } from '@angular/material/tabs';
import { AuthService } from '../../services/auth.service';
import { ApiService } from '../../services/api.service';
import { User } from '../../models/user.model';
import { Post } from '../../models/post.model';

@Component({
  selector: 'app-search',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    ReactiveFormsModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatToolbarModule,
    MatSidenavModule,
    MatListModule,
    MatSnackBarModule,
    MatProgressSpinnerModule,
    MatChipsModule,
    MatTooltipModule,
    MatFormFieldModule,
    MatInputModule,
    MatTabsModule
  ],
  template: `
    <mat-sidenav-container class="sidenav-container">
      <mat-sidenav #drawer class="sidenav" fixedInViewport
          [attr.role]="'navigation'"
          [mode]="'over'"
          [opened]="false">
        <mat-toolbar>ProfileBook</mat-toolbar>
        <mat-nav-list>
          <a mat-list-item routerLink="/dashboard" routerLinkActive="active">
            <mat-icon matListItemIcon>dashboard</mat-icon>
            <span matListItemTitle>Dashboard</span>
          </a>
          <a mat-list-item routerLink="/posts" routerLinkActive="active">
            <mat-icon matListItemIcon>article</mat-icon>
            <span matListItemTitle>Posts</span>
          </a>
          <a mat-list-item routerLink="/messages" routerLinkActive="active">
            <mat-icon matListItemIcon>message</mat-icon>
            <span matListItemTitle>Messages</span>
          </a>
          <a mat-list-item routerLink="/profile" routerLinkActive="active">
            <mat-icon matListItemIcon>person</mat-icon>
            <span matListItemTitle>Profile</span>
          </a>
          <a mat-list-item routerLink="/notifications" routerLinkActive="active">
            <mat-icon matListItemIcon>notifications</mat-icon>
            <span matListItemTitle>Notifications</span>
          </a>
        </mat-nav-list>
      </mat-sidenav>
      <mat-sidenav-content>
        <mat-toolbar color="primary">
          <button
            type="button"
            aria-label="Toggle sidenav"
            mat-icon-button
            (click)="drawer.toggle()">
            <mat-icon aria-label="Side nav toggle icon">menu</mat-icon>
          </button>
          <span>Search</span>
          <span class="spacer"></span>
          <button mat-icon-button (click)="logout()" matTooltip="Logout">
            <mat-icon>logout</mat-icon>
          </button>
        </mat-toolbar>
        
        <div class="content">
          <!-- Search Form -->
          <div class="search-section">
            <mat-card class="search-card">
              <mat-card-content>
                <form [formGroup]="searchForm" (ngSubmit)="performSearch()">
                  <mat-form-field appearance="outline" class="search-field">
                    <mat-label>Search for users or posts...</mat-label>
                    <input matInput formControlName="query" placeholder="Enter search term">
                    <mat-icon matSuffix>search</mat-icon>
                  </mat-form-field>
                  <button mat-raised-button color="primary" type="submit" 
                          [disabled]="searchForm.get('query')?.value?.trim() === ''">
                    Search
                  </button>
                </form>
              </mat-card-content>
            </mat-card>
          </div>

          <!-- Search Results -->
          <div *ngIf="hasSearched" class="results-section">
            <mat-tab-group>
              <!-- Users Tab -->
               <mat-tab label="Users">
                <div class="tab-content">
                  <div *ngIf="isLoading" class="loading">
                    <mat-spinner diameter="30"></mat-spinner>
                    <p>Searching users...</p>
                  </div>
                  
                  <div *ngIf="!isLoading && userResults.length === 0" class="no-results">
                    <mat-icon>person_search</mat-icon>
                    <h3>No users found</h3>
                    <p>Try adjusting your search terms</p>
                  </div>

                  <div *ngIf="!isLoading && userResults.length > 0" class="users-grid">
                    <mat-card *ngFor="let user of userResults" class="user-card">
                      <mat-card-header>
                        <div mat-card-avatar class="user-avatar">
                          <img [src]="user.profileImage || '/assets/default-avatar.png'" 
                               [alt]="user.username" 
                               *ngIf="user.profileImage; else defaultAvatar">
                          <ng-template #defaultAvatar>
                            <mat-icon>person</mat-icon>
                          </ng-template>
                        </div>
                        <mat-card-title>{{ user.username }}</mat-card-title>
                        <mat-card-subtitle>{{ user.email }}</mat-card-subtitle>
                      </mat-card-header>
                      <mat-card-content>
                        <mat-chip [color]="user.role === 'Admin' ? 'accent' : 'primary'">
                          {{ user.role }}
                        </mat-chip>
                        <p class="join-date">Joined {{ formatDate(user.createdAt) }}</p>
                      </mat-card-content>
                      <mat-card-actions>
                        <button mat-button color="primary" (click)="viewUserProfile(user)">
                          <mat-icon>visibility</mat-icon>
                          View Profile
                        </button>
                        <button mat-button color="accent" (click)="sendFriendRequest(user)" 
                                *ngIf="user.userId !== currentUser?.userId">
                          <mat-icon>person_add</mat-icon>
                          Add Friend
                        </button>
                      </mat-card-actions>
                    </mat-card>
                  </div>
                </div>
              </mat-tab>

              <!-- Posts Tab -->
               <mat-tab label="Posts">
                <div class="tab-content">
                  <div *ngIf="isLoading" class="loading">
                    <mat-spinner diameter="30"></mat-spinner>
                    <p>Searching posts...</p>
                  </div>
                  
                  <div *ngIf="!isLoading && postResults.length === 0" class="no-results">
                    <mat-icon>article</mat-icon>
                    <h3>No posts found</h3>
                    <p>Try adjusting your search terms</p>
                  </div>

                  <div *ngIf="!isLoading && postResults.length > 0" class="posts-container">
                    <mat-card *ngFor="let post of postResults" class="post-card">
                      <mat-card-header>
                        <div mat-card-avatar class="post-avatar">
                          <img [src]="post.user?.profileImage || '/assets/default-avatar.png'" 
                               [alt]="post.user?.username" 
                               *ngIf="post.user?.profileImage; else defaultAvatar">
                          <ng-template #defaultAvatar>
                            <mat-icon>person</mat-icon>
                          </ng-template>
                        </div>
                        <mat-card-title>{{ post.user?.username }}</mat-card-title>
                        <mat-card-subtitle>{{ formatDate(post.createdAt) }}</mat-card-subtitle>
                        <span class="post-status" [ngClass]="post.status.toLowerCase()">
                          {{ post.status }}
                        </span>
                      </mat-card-header>
                      
                      <mat-card-content>
                        <p class="post-content">{{ post.content }}</p>
                        <img *ngIf="post.postImage" [src]="post.postImage" [alt]="'Post image'" class="post-image">
                      </mat-card-content>
                      
                      <mat-card-actions>
                        <button mat-icon-button (click)="likePost(post)" 
                                [color]="isLiked(post) ? 'warn' : ''">
                          <mat-icon>{{ isLiked(post) ? 'favorite' : 'favorite_border' }}</mat-icon>
                           <span>{{ post.likes.length || 0 }}</span>
                        </button>
                        
                        <button mat-icon-button (click)="toggleComments(post)">
                          <mat-icon>comment</mat-icon>
                          <span>{{ post.comments.length || 0 }}</span>
                        </button>
                      </mat-card-actions>

                      <div *ngIf="post.showComments" class="comments-section">
                        <div *ngFor="let comment of post.comments" class="comment">
                          <div class="comment-header">
                            <strong>{{ comment.user?.username }}</strong>
                            <span class="comment-date">{{ formatDate(comment.createdAt) }}</span>
                          </div>
                          <p>{{ comment.content }}</p>
                        </div>
                      </div>
                    </mat-card>
                  </div>
                </div>
              </mat-tab>
            </mat-tab-group>
          </div>
        </div>
      </mat-sidenav-content>
    </mat-sidenav-container>
  `,
  styles: [`
    .sidenav-container {
      height: 100vh;
    }

    .sidenav {
      width: 250px;
    }

    .sidenav .mat-toolbar {
      background: inherit;
    }

    .mat-toolbar.mat-primary {
      position: sticky;
      top: 0;
      z-index: 1;
    }

    .spacer {
      flex: 1 1 auto;
    }

    .content {
      padding: 2rem;
    }

    .search-section {
      margin-bottom: 2rem;
    }

    .search-card {
      max-width: 600px;
      margin: 0 auto;
    }

    .search-field {
      width: 100%;
      margin-right: 1rem;
    }

    .search-card form {
      display: flex;
      align-items: center;
      gap: 1rem;
    }

    .results-section {
      max-width: 1000px;
      margin: 0 auto;
    }

    .tab-content {
      padding: 2rem 0;
    }

    .loading {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 4rem;
    }

    .no-results {
      text-align: center;
      padding: 4rem;
      color: #666;
    }

    .no-results mat-icon {
      font-size: 4rem;
      width: 4rem;
      height: 4rem;
      margin-bottom: 1rem;
      color: #ccc;
    }

    .users-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
      gap: 1rem;
    }

    .user-card {
      height: 100%;
    }

    .user-avatar {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      overflow: hidden;
    }

    .user-avatar img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .join-date {
      font-size: 0.8rem;
      color: #666;
      margin-top: 0.5rem;
    }

    .posts-container {
      max-width: 800px;
      margin: 0 auto;
    }

    .post-card {
      margin-bottom: 2rem;
    }

    .post-avatar {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      overflow: hidden;
    }

    .post-avatar img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .post-status {
      padding: 4px 8px;
      border-radius: 12px;
      font-size: 0.75rem;
      font-weight: 500;
      margin-left: auto;
    }

    .post-status.approved {
      background-color: #e8f5e8;
      color: #2e7d32;
    }

    .post-status.pending {
      background-color: #fff3e0;
      color: #f57c00;
    }

    .post-status.rejected {
      background-color: #ffebee;
      color: #c62828;
    }

    .post-content {
      font-size: 1.1rem;
      line-height: 1.5;
      margin: 1rem 0;
    }

    .post-image {
      width: 100%;
      max-height: 400px;
      object-fit: cover;
      border-radius: 8px;
      margin-top: 1rem;
    }

    .comments-section {
      border-top: 1px solid #eee;
      padding-top: 1rem;
      margin-top: 1rem;
    }

    .comment {
      margin-bottom: 1rem;
      padding: 0.5rem;
      background-color: #f5f5f5;
      border-radius: 8px;
    }

    .comment-header {
      display: flex;
      justify-content: space-between;
      margin-bottom: 0.5rem;
    }

    .comment-date {
      font-size: 0.8rem;
      color: #666;
    }

    .active {
      background-color: rgba(25, 118, 210, 0.1);
    }

    @media (max-width: 768px) {
      .search-card form {
        flex-direction: column;
        align-items: stretch;
      }

      .search-field {
        margin-right: 0;
        margin-bottom: 1rem;
      }

      .users-grid {
        grid-template-columns: 1fr;
      }
    }
  `]
})
export class SearchComponent implements OnInit {
  searchForm: FormGroup;
  userResults: User[] = [];
  postResults: Post[] = [];
  isLoading = false;
  hasSearched = false;
  currentUser: User | null = null;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private apiService: ApiService,
    private snackBar: MatSnackBar
  ) {
    this.searchForm = this.fb.group({
      query: ['']
    });
  }

  ngOnInit() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });
  }

  performSearch() {
    const query = this.searchForm.get('query')?.value?.trim();
    if (!query) return;

    this.hasSearched = true;
    this.isLoading = true;

    // Search users and posts in parallel
    Promise.all([
      this.apiService.searchUsers(query).toPromise(),
      this.apiService.searchPosts(query).toPromise()
    ]).then(([users, posts]) => {
      this.userResults = users || [];
      this.postResults = posts || [];
      this.isLoading = false;
    }).catch(() => {
      this.isLoading = false;
      this.snackBar.open('Search failed', 'Close', { duration: 3000 });
    });
  }

  viewUserProfile(user: User) {
    // Navigate to user profile or show user details
    this.snackBar.open(`Viewing profile of ${user.username}`, 'Close', { duration: 2000 });
  }

  sendFriendRequest(user: User) {
    this.apiService.sendFriendRequest(user.userId).subscribe({
      next: () => {
        this.snackBar.open(`Friend request sent to ${user.username}`, 'Close', { duration: 2000 });
      },
      error: () => {
        this.snackBar.open('Failed to send friend request', 'Close', { duration: 3000 });
      }
    });
  }

  likePost(post: Post) {
    // Implement like functionality
    this.snackBar.open('Like functionality coming soon', 'Close', { duration: 2000 });
  }

  isLiked(post: Post): boolean {
    // Check if current user has liked this post
    return post.likes?.some(like => like.userId === this.currentUser?.userId) || false;
  }

  toggleComments(post: Post) {
    post.showComments = !post.showComments;
  }

  formatDate(dateString: string): string {
    return new Date(dateString).toLocaleDateString();
  }

  logout() {
    this.authService.logout();
    this.snackBar.open('Logged out successfully', 'Close', { duration: 3000 });
  }
}
