import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTabsModule } from '@angular/material/tabs';
import { MatChipsModule } from '@angular/material/chips';
import { AuthService } from '../../services/auth.service';
import { ApiService } from '../../services/api.service';
import { User } from '../../models/user.model';
import { Post } from '../../models/post.model';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    ReactiveFormsModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatToolbarModule,
    MatSidenavModule,
    MatListModule,
    MatSnackBarModule,
    MatFormFieldModule,
    MatInputModule,
    MatProgressSpinnerModule,
    MatTabsModule,
    MatChipsModule
  ],
  template: `
    <mat-sidenav-container class="sidenav-container">
      <mat-sidenav #drawer class="sidenav" fixedInViewport
          [attr.role]="'navigation'"
          [mode]="'over'"
          [opened]="false">
        <mat-toolbar>ProfileBook</mat-toolbar>
        <mat-nav-list>
          <a mat-list-item routerLink="/dashboard" routerLinkActive="active">
            <mat-icon matListItemIcon>dashboard</mat-icon>
            <span matListItemTitle>Dashboard</span>
          </a>
          <a mat-list-item routerLink="/posts" routerLinkActive="active">
            <mat-icon matListItemIcon>article</mat-icon>
            <span matListItemTitle>Posts</span>
          </a>
          <a mat-list-item routerLink="/messages" routerLinkActive="active">
            <mat-icon matListItemIcon>message</mat-icon>
            <span matListItemTitle>Messages</span>
          </a>
          <a mat-list-item routerLink="/profile" routerLinkActive="active">
            <mat-icon matListItemIcon>person</mat-icon>
            <span matListItemTitle>Profile</span>
          </a>
        </mat-nav-list>
      </mat-sidenav>
      <mat-sidenav-content>
        <mat-toolbar color="primary">
          <button
            type="button"
            aria-label="Toggle sidenav"
            mat-icon-button
            (click)="drawer.toggle()">
            <mat-icon aria-label="Side nav toggle icon">menu</mat-icon>
          </button>
          <span>Profile</span>
          <span class="spacer"></span>
          <button mat-icon-button (click)="logout()" matTooltip="Logout">
            <mat-icon>logout</mat-icon>
          </button>
        </mat-toolbar>
        
        <div class="content">
          <div *ngIf="isLoading" class="loading-container">
            <mat-spinner></mat-spinner>
            <p>Loading profile...</p>
          </div>

          <div *ngIf="!isLoading" class="profile-container">
            <!-- Profile Header -->
            <mat-card class="profile-header">
              <div class="profile-info">
                <div class="profile-avatar">
                  <img [src]="currentUser?.profileImage || '/assets/default-avatar.png'" 
                       [alt]="currentUser?.username" 
                       *ngIf="currentUser?.profileImage; else defaultAvatar">
                  <ng-template #defaultAvatar>
                    <mat-icon>person</mat-icon>
                  </ng-template>
                  <button mat-fab color="primary" class="edit-avatar-btn" (click)="fileInput.click()">
                    <mat-icon>camera_alt</mat-icon>
                  </button>
                  <input type="file" #fileInput (change)="onFileSelected($event)" 
                         accept="image/*" style="display: none;">
                </div>
                <div class="profile-details">
                  <h1>{{ currentUser?.username }}</h1>
                  <p>{{ currentUser?.email }}</p>
                  <mat-chip [color]="currentUser?.role === 'Admin' ? 'accent' : 'primary'">
                    {{ currentUser?.role }}
                  </mat-chip>
                </div>
              </div>
            </mat-card>

            <!-- Profile Tabs -->
            <mat-tab-group>
              <!-- Edit Profile Tab -->
              <mat-tab label="Edit Profile">
                <div class="tab-content">
                  <mat-card>
                    <mat-card-header>
                      <mat-card-title>Update Profile Information</mat-card-title>
                    </mat-card-header>
                    <mat-card-content>
                      <form [formGroup]="profileForm" (ngSubmit)="updateProfile()">
                        <mat-form-field appearance="outline" class="full-width">
                          <mat-label>Username</mat-label>
                          <input matInput formControlName="username" required>
                          <mat-error *ngIf="profileForm.get('username')?.hasError('required')">
                            Username is required
                          </mat-error>
                        </mat-form-field>

                        <mat-form-field appearance="outline" class="full-width">
                          <mat-label>Email</mat-label>
                          <input matInput type="email" formControlName="email" required>
                          <mat-error *ngIf="profileForm.get('email')?.hasError('required')">
                            Email is required
                          </mat-error>
                          <mat-error *ngIf="profileForm.get('email')?.hasError('email')">
                            Please enter a valid email
                          </mat-error>
                        </mat-form-field>

                        <div class="form-actions">
                          <button mat-raised-button color="primary" type="submit" 
                                  [disabled]="profileForm.invalid || isUpdating">
                            {{ isUpdating ? 'Updating...' : 'Update Profile' }}
                          </button>
                          <button mat-button type="button" (click)="resetForm()">
                            Reset
                          </button>
                        </div>
                      </form>
                    </mat-card-content>
                  </mat-card>
                </div>
              </mat-tab>

              <!-- My Posts Tab -->
              <mat-tab label="My Posts">
                <div class="tab-content">
                  <div *ngIf="isLoadingPosts" class="loading">
                    <mat-spinner diameter="30"></mat-spinner>
                  </div>
                  
                  <div *ngIf="!isLoadingPosts && userPosts.length === 0" class="no-posts">
                    <mat-icon>article</mat-icon>
                    <h3>No posts yet</h3>
                    <p>You haven't created any posts yet.</p>
                    <button mat-raised-button color="primary" routerLink="/posts">
                      Create Your First Post
                    </button>
                  </div>

                  <div *ngIf="!isLoadingPosts && userPosts.length > 0" class="posts-grid">
                    <mat-card *ngFor="let post of userPosts" class="post-card">
                      <mat-card-header>
                        <mat-card-title>{{ post.content.substring(0, 50) }}{{ post.content.length > 50 ? '...' : '' }}</mat-card-title>
                        <mat-card-subtitle>{{ formatDate(post.createdAt) }}</mat-card-subtitle>
                        <span class="post-status" [ngClass]="post.status.toLowerCase()">
                          {{ post.status }}
                        </span>
                      </mat-card-header>
                      
                      <mat-card-content>
                        <p>{{ post.content }}</p>
                        <img *ngIf="post.postImage" [src]="post.postImage" [alt]="'Post image'" class="post-image">
                      </mat-card-content>
                      
                      <mat-card-actions>
                        <button mat-icon-button (click)="editPost(post)">
                          <mat-icon>edit</mat-icon>
                        </button>
                        <button mat-icon-button (click)="deletePost(post)" color="warn">
                          <mat-icon>delete</mat-icon>
                        </button>
                      </mat-card-actions>
                    </mat-card>
                  </div>
                </div>
              </mat-tab>
            </mat-tab-group>
          </div>
        </div>
      </mat-sidenav-content>
    </mat-sidenav-container>
  `,
  styles: [`
    .sidenav-container {
      height: 100vh;
    }

    .sidenav {
      width: 250px;
    }

    .sidenav .mat-toolbar {
      background: inherit;
    }

    .mat-toolbar.mat-primary {
      position: sticky;
      top: 0;
      z-index: 1;
    }

    .spacer {
      flex: 1 1 auto;
    }

    .content {
      padding: 2rem;
    }

    .loading-container {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 4rem;
    }

    .profile-container {
      max-width: 1000px;
      margin: 0 auto;
    }

    .profile-header {
      margin-bottom: 2rem;
    }

    .profile-info {
      display: flex;
      align-items: center;
      gap: 2rem;
    }

    .profile-avatar {
      position: relative;
      width: 120px;
      height: 120px;
    }

    .profile-avatar img {
      width: 100%;
      height: 100%;
      border-radius: 50%;
      object-fit: cover;
    }

    .profile-avatar mat-icon {
      font-size: 4rem;
      width: 4rem;
      height: 4rem;
      color: #ccc;
    }

    .edit-avatar-btn {
      position: absolute;
      bottom: 0;
      right: 0;
      width: 40px;
      height: 40px;
    }

    .profile-details h1 {
      margin: 0 0 0.5rem 0;
      font-size: 2rem;
    }

    .profile-details p {
      margin: 0 0 1rem 0;
      color: #666;
      font-size: 1.1rem;
    }

    .tab-content {
      padding: 2rem 0;
    }

    .full-width {
      width: 100%;
      margin-bottom: 1rem;
    }

    .form-actions {
      display: flex;
      gap: 1rem;
      margin-top: 1rem;
    }

    .loading {
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 2rem;
    }

    .no-posts {
      text-align: center;
      padding: 4rem;
    }

    .no-posts mat-icon {
      font-size: 4rem;
      width: 4rem;
      height: 4rem;
      color: #ccc;
      margin-bottom: 1rem;
    }

    .posts-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
      gap: 1rem;
    }

    .post-card {
      height: 100%;
    }

    .post-status {
      padding: 4px 8px;
      border-radius: 12px;
      font-size: 0.75rem;
      font-weight: 500;
      margin-left: auto;
    }

    .post-status.approved {
      background-color: #e8f5e8;
      color: #2e7d32;
    }

    .post-status.pending {
      background-color: #fff3e0;
      color: #f57c00;
    }

    .post-status.rejected {
      background-color: #ffebee;
      color: #c62828;
    }

    .post-image {
      width: 100%;
      max-height: 200px;
      object-fit: cover;
      border-radius: 8px;
      margin-top: 1rem;
    }

    .active {
      background-color: rgba(25, 118, 210, 0.1);
    }

    @media (max-width: 768px) {
      .profile-info {
        flex-direction: column;
        text-align: center;
      }

      .posts-grid {
        grid-template-columns: 1fr;
      }
    }
  `]
})
export class ProfileComponent implements OnInit {
  currentUser: User | null = null;
  userPosts: Post[] = [];
  profileForm: FormGroup;
  isLoading = true;
  isLoadingPosts = false;
  isUpdating = false;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private apiService: ApiService,
    private snackBar: MatSnackBar
  ) {
    this.profileForm = this.fb.group({
      username: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]]
    });
  }

  ngOnInit() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
      if (user) {
        this.profileForm.patchValue({
          username: user.username,
          email: user.email
        });
        this.loadUserPosts();
      }
      this.isLoading = false;
    });
  }

  loadUserPosts() {
    if (!this.currentUser) return;

    this.isLoadingPosts = true;
    this.apiService.getUserPosts(this.currentUser.userId).subscribe({
      next: (posts) => {
        this.userPosts = posts;
        this.isLoadingPosts = false;
      },
      error: () => {
        this.isLoadingPosts = false;
        this.snackBar.open('Failed to load posts', 'Close', { duration: 3000 });
      }
    });
  }

  onFileSelected(event: any) {
    const file = event.target.files[0];
    if (file) {
      this.apiService.uploadProfileImage(file).subscribe({
        next: (response) => {
          this.apiService.updateProfile(this.currentUser?.userId || 0, response.filePath).subscribe({
            next: () => {
              this.snackBar.open('Profile image updated successfully', 'Close', { duration: 3000 });
              // Update current user
              if (this.currentUser) {
                this.currentUser.profileImage = response.filePath;
                // Note: currentUser$ is an Observable, not a Subject
                // The auth service should handle updating the current user
              }
            },
            error: () => {
              this.snackBar.open('Failed to update profile image', 'Close', { duration: 3000 });
            }
          });
        },
        error: () => {
          this.snackBar.open('Failed to upload image', 'Close', { duration: 3000 });
        }
      });
    }
  }

  updateProfile() {
    if (this.profileForm.valid && this.currentUser) {
      this.isUpdating = true;
      const updatedUser = { ...this.currentUser, ...this.profileForm.value };

      this.apiService.updateUser(this.currentUser.userId, updatedUser).subscribe({
        next: (user) => {
          this.isUpdating = false;
          this.currentUser = user;
          // Note: currentUser$ is an Observable, not a Subject
          // The auth service should handle updating the current user
          this.snackBar.open('Profile updated successfully', 'Close', { duration: 3000 });
        },
        error: () => {
          this.isUpdating = false;
          this.snackBar.open('Failed to update profile', 'Close', { duration: 3000 });
        }
      });
    }
  }

  resetForm() {
    if (this.currentUser) {
      this.profileForm.patchValue({
        username: this.currentUser.username,
        email: this.currentUser.email
      });
    }
  }

  editPost(post: Post) {
    // Implement edit post functionality
    this.snackBar.open('Edit post functionality coming soon', 'Close', { duration: 3000 });
  }

  deletePost(post: Post) {
    if (confirm('Are you sure you want to delete this post?')) {
      this.apiService.deletePost(post.postId).subscribe({
        next: () => {
          this.userPosts = this.userPosts.filter(p => p.postId !== post.postId);
          this.snackBar.open('Post deleted successfully', 'Close', { duration: 3000 });
        },
        error: () => {
          this.snackBar.open('Failed to delete post', 'Close', { duration: 3000 });
        }
      });
    }
  }

  formatDate(dateString: string): string {
    return new Date(dateString).toLocaleDateString();
  }

  logout() {
    this.authService.logout();
    this.snackBar.open('Logged out successfully', 'Close', { duration: 3000 });
  }
}

