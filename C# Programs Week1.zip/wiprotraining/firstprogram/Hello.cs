
using System;

class Hello
{

    static void Main(string[] args)
    {

        var i = 10;  // when we don't know the data type of a variable
        var name = "Niti";

        Console.WriteLine(i + " " + name);
     //   Console.WriteLine(sizeof(name));
    }


}