using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace LibraryManagementSystem.Models
{
    public class Genre
    {
        [Key]
        public int GenreID { get; set; }
        [Required]
        public string? Name { get; set; }

        // Navigation property
        public ICollection<BookGenre> BookGenres { get; set; } = new List<BookGenre>();

    }
}
