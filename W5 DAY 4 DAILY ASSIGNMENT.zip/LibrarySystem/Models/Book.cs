using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LibraryManagementSystem.Models
{
    public class Book
    {
        [Key]
        public int BookID { get; set; }
        [Required]
        public string? Title { get; set; }

        [ForeignKey("Author")]
        public int AuthorID { get; set; }
        public Author? Author { get; set; }

        // Navigation property for many-to-many
        public ICollection<BookGenre> BookGenres { get; set; } = new List<BookGenre>();

    }
}
